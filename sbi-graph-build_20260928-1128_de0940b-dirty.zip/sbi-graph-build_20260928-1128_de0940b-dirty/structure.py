# -*- coding: utf-8 -*-
"""
graph_build/structure.py

**조각 색인** — Qdrant 의 조각(parent) 하나가 노드 하나다.

왜 조문이 아니라 조각인가:
  조각과 조문은 **1:1 이 아니다.** 인덱싱 스크립트(`parse_law_structure`)가
  헤더에서 조를 못 찾으면 본문의 `- 제n조` 불릿을 전부 긁어 `article_no` 를
  **리스트**로 만든다. 즉 조각 하나가 장 전체일 수 있다.
  반대로 한 조문이 길면 조각 여러 개로 쪼개진다 (내부 실측 2,898건).

  조문을 노드로 잡으면 양쪽에서 어긋난다 (2026-09-23 내부 실측):
    · 조각에 조문 여럿  → 앞 조문에 전부 몰아주고 나머지는 막다른 노드
    · 조문이 조각 여럿  → 조각 하나만 남기고 버림 → **검색 결과 13.4% 가 확장 불가**

  조각을 노드로 잡으면 검색·반환·본문이 전부 같은 단위가 되어 변환이 사라진다.

조번호는 **이름표**다. 한 조각이 이름표를 여러 개 가질 수 있고(조각=장),
한 이름표를 조각 여럿이 가질 수도 있다(조문=조각 여럿). 둘 다 자연스럽게 처리된다.

**별표·부칙 안의 조 번호는 문서 전체 이름표가 아니다.** 별표 조각은 본문 불릿의
`- 제449조` 를 긁어 `article_no` 를 갖고, 부칙은 개정마다 `제1조(시행일)` 이 있다.
이걸 문서 이름표로 쓰면 본칙 `제1조` 인용이 부칙 수십 개에 붙는다. 그래서 그런 조각은
`별표009`·`부칙` 이름표 하나만 갖는다.

순수 모듈이다. Qdrant 클라이언트를 import 하지 않는다 — 행(dict)을 받는다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from clause_ref import (
    NormalizationError, article_target, heading_key, heading_text_key, pad3,
)

#: `article_no` 값 해석 — **모양이 뜻을 가른다.**
#:   `3`·`"006"`                  → 본조
#:   `"3-2"`·`"003-002"` (맨 숫자쌍) → **가지조문 제3조의2**. 인덱서의 인코딩이다
#:       (`parse_law_structure.normalize_article_no`: `제3조의2` → `"3-2"`)
#:   `"제7-2조"`·`"7-2조"` (`조` 가 붙음) → **하이픈 조문** (감독규정식 장-조 번호). 가지조문이 아니다
_BARE_NO_RE = re.compile(r"^\s*(\d+)\s*$")
_BARE_BRANCH_RE = re.compile(r"^\s*(\d+)\s*-\s*(\d+)\s*$")
_ARTICLE_TEXT_RE = re.compile(
    r"^\s*제?\s*(?:(?P<pre>\d+)\s*-\s*)?(?P<no>\d+)\s*조(?:\s*의\s*(?P<sub>\d+))?\s*$")
#: 헤더 조각 **맨 앞의** 조 표기. `제7-2조 (지급여력…` · `제4-4조(업무위탁의` · `제3조의2(…)`.
#: 인덱서는 `제7-2조` 를 못 읽어 `article_no=None` 을 준다 (2026-09-28 실측).
_ARTICLE_HEAD_RE = re.compile(
    r"^\s*[#>*\-•·]*\s*제\s*(?:(?P<pre>\d+)\s*-\s*)?(?P<no>\d+)\s*조(?:\s*의\s*(?P<sub>\d+))?")
#: 별표·서식 표기(값 안 아무 데나). `normalize_article_no("별표 3")` 하위호환용.
_APPENDIX_RE = re.compile(r"(별표|별첨|서식)\s*제?\s*(\d+(?:\s*-\s*\d+)?)")
#: 별표·서식 **머리**. `chapter_no="별표9"` (인덱서가 `[별표 9]` 헤더를 **장 칸에** 넣는다),
#: 헤더 조각 `[별표 4의1] …`·`<별표6> …`·`[별지 제3호 서식]`.
_APPENDIX_HEAD_RE = re.compile(
    r"^\s*[\[<(【〈《]?\s*"
    r"(?:(?P<kind>별표|서식|별첨)\s*(?P<no>\d+(?:\s*-\s*\d+)?)(?:\s*의\s*(?P<sub>\d+))?"
    r"|별지\s*제?\s*(?P<form>\d+)\s*호\s*서식)")
#: 부칙 머리. `부칙 <제36341호,2026. 5. 19.>` · `부칙(2020. 1. 1.)` · `부 칙`
_ADDENDUM_HEAD_RE = re.compile(r"^\s*[\[<(【]?\s*부\s*칙(?![가-힣])")
#: 장·절 번호. **숫자만** 받는다.
_CHAPTER_NO_RE = re.compile(r"^\s*제?\s*(\d+)\s*(?:장|절)?\s*$")
#: 헤더 조각 머리의 편·장·절. 인덱서는 편을 안 읽고, 법령 JSON 경로는 장·절을 문자열로만 준다.
_PART_HEAD_RE = re.compile(r"^\s*제\s*(\d+)\s*편(?![가-힣])")
_CHAPTER_HEAD_RE = re.compile(r"^\s*제\s*(\d+)\s*장(?![가-힣])")
_SECTION_HEAD_RE = re.compile(r"^\s*제\s*(\d+)\s*절(?![가-힣])")
#: 조 이름표 모양 (`003조`·`003조의002`·`007-002조`).
_ARTICLE_LABEL_RE = re.compile(r"^(?:\d{3,}-)?\d{3,}조(?:의\d{3,})?$")
#: 법제처 제목줄의 공식 약칭. `대부업 등의 … 법률 시행령 (약칭: 대부업법 시행령)`.
_OFFICIAL_ABBR_RE = re.compile(r"[(（]\s*약칭\s*[:：]\s*(?P<abbr>[^)）\n]{1,40}?)\s*[)）]")


def normalize_article_no(raw) -> Tuple[str, ...]:
    """
    `article_no` 를 `clause_ref.target` 과 **같은 형식**으로 맞춘다.

    >>> normalize_article_no("006")
    ('006조',)
    >>> normalize_article_no("3-2")
    ('003조의002',)
    >>> normalize_article_no("제7-2조")
    ('007-002조',)
    >>> normalize_article_no([11, 12])
    ('011조', '012조')
    >>> normalize_article_no(None)
    ()
    """
    if raw is None or raw == "" or isinstance(raw, bool):
        return ()
    if isinstance(raw, (list, tuple, set)):
        out: List[str] = []
        for item in raw:
            out.extend(normalize_article_no(item))
        return tuple(dict.fromkeys(out))

    text = str(raw)
    m = _BARE_NO_RE.match(text)
    if m:
        return (article_target(int(m.group(1))),)
    m = _BARE_BRANCH_RE.match(text)
    if m:                                    # 인덱서 인코딩 — 가지조문
        return (article_target(int(m.group(1)), int(m.group(2))),)
    m = _ARTICLE_TEXT_RE.match(text)
    if m:
        pre = int(m.group("pre")) if m.group("pre") else None
        sub = int(m.group("sub")) if m.group("sub") else None
        return (article_target(int(m.group("no")), sub, pre),)

    m = _APPENDIX_RE.search(text)
    if m:
        parts = [pad3(int(p)) for p in re.sub(r"\s+", "", m.group(2)).split("-")]
        return (f"{m.group(1)}{'-'.join(parts)}",)
    return ()


def normalize_chapter_no(raw, unit: str) -> Tuple[str, ...]:
    """
    `chapter_no="002"`·`2` → `('002장',)`. 장·절은 **조와 다른 이름표**다.

    **숫자가 아니면 빈 값이다.** 인덱서는 `[별표 9]` 헤더를 `chapter_no="별표9"` 로 넣는데,
    숫자만 뽑으면 **별표 9 가 제9장**이 된다 (2026-09-28 내부 실측). 별표는 `appendix_label`.
    """
    if raw is None or raw == "" or isinstance(raw, bool):
        return ()
    m = _CHAPTER_NO_RE.match(str(raw))
    return (f"{pad3(int(m.group(1)))}{unit}",) if m else ()


def appendix_label(raw) -> str:
    """
    별표·서식 머리 → 이름표. 아니면 빈 문자열. `clause_ref` 의 target 과 같은 형식이다.

    >>> appendix_label("별표9"), appendix_label("[별표 4의1] 외"), appendix_label("[별지 제3호 서식]")
    ('별표009', '별표004의001', '별지003호서식')
    """
    if raw is None or isinstance(raw, (bool, int, float)):
        return ""
    m = _APPENDIX_HEAD_RE.match(str(raw))
    if not m:
        return ""
    if m.group("form"):
        return f"별지{pad3(int(m.group('form')))}호서식"
    parts = [pad3(int(p)) for p in re.sub(r"\s+", "", m.group("no")).split("-")]
    sub = f"의{pad3(int(m.group('sub')))}" if m.group("sub") else ""
    return f"{m.group('kind')}{'-'.join(parts)}{sub}"


def struct_label(part: Optional[int], chapter: Optional[int], section: Optional[int] = None) -> str:
    """
    편·장·절 **계층** 이름표. 색인과 해소가 이 함수 하나로 같은 형식을 만든다.

      (None, 2, None) → `002장`   ·  (None, 2, 1) → `002장001절`   ·  (3, 2, 1) → `003편002장001절`

    **절 번호는 장마다, 장 번호는 편마다 1부터 다시 센다** (자본시장법 `제2편 제3장` 과 `제3편 제3장`).
    사고 이력 (2026-09-28 Reviewer 2차 F1): 절을 `001절` 로 문서 전체에 풀어 `제2장 제1절` 이
    1장·2장·3장의 1절 **전부**와 2장 전체로 연결됐다 (적대적 표본 오연결 21건 중 6건).
    """
    out = f"{pad3(part)}편" if part is not None else ""
    out += f"{pad3(chapter)}장" if chapter is not None else ""
    return out + (f"{pad3(section)}절" if section is not None else "")


def _scope_of(payload: Mapping, segments: Sequence[str]) -> Tuple[Optional[int], Optional[int], Optional[int]]:
    """조각이 놓인 `(편, 장, 절)`. payload 숫자 칸이 우선, 없으면 **가장 깊은** 헤더 조각에서."""
    def from_heads(rx) -> Optional[int]:
        for seg in reversed(segments):
            m = rx.match(seg)
            if m:
                return int(m.group(1))
        return None

    def from_field(raw, rx) -> Optional[int]:
        m = _CHAPTER_NO_RE.match(str(raw)) if raw not in (None, "") and not isinstance(raw, bool) else None
        return int(m.group(1)) if m else from_heads(rx)

    return (from_heads(_PART_HEAD_RE),
            from_field(payload.get("chapter_no"), _CHAPTER_HEAD_RE),
            from_field(payload.get("section_no"), _SECTION_HEAD_RE))


def header_segments(header_path) -> List[str]:
    """`'H1 / H2 / H3'` → 조각 목록. 인덱서의 `get_leaf_header` 와 같은 분리(`\\s*/\\s*`)."""
    if header_path is None:
        return []
    if isinstance(header_path, (list, tuple)):
        return [str(s).strip() for s in header_path if str(s).strip()]
    return [p.strip() for p in re.split(r"\s*/\s*", str(header_path)) if p.strip()]


def leaf_header(header_path) -> str:
    """
    가장 깊은 헤더. 인덱서가 **본문 첫 줄에 붙인 그 헤더**다 (`text = leaf + "\\n" + 본문`).
    추출기가 이 줄의 맨 앞 위치 토큰을 인용으로 세지 않게 넘긴다.
    """
    segs = header_segments(header_path)
    return segs[-1] if segs else ""


def _article_from_header(segments: Sequence[str]) -> Tuple[str, ...]:
    """가장 깊은 **조 머리** 헤더에서 조 번호. `제7-2조 (…` → `('007-002조',)`."""
    for seg in reversed(segments):
        m = _ARTICLE_HEAD_RE.match(seg)
        if m:
            pre = int(m.group("pre")) if m.group("pre") else None
            sub = int(m.group("sub")) if m.group("sub") else None
            return (article_target(int(m.group("no")), sub, pre),)
    return ()


@dataclass(frozen=True)
class DocNode:
    """조각 하나. Qdrant parent 하나에 대응한다."""

    node_id: str                        # = parent_id
    doc_title: str
    parent_id: str
    labels: Tuple[str, ...] = ()        # 이 조각을 가리킬 수 있는 이름표
    article_labels: Tuple[str, ...] = ()  # 그중 조 번호만 (전조 해소용)
    scope: Tuple[Optional[int], Optional[int], Optional[int]] = (None, None, None)  # (편, 장, 절)
    title: str = ""
    chunk_ids: Tuple[str, ...] = ()
    category_id: str = ""
    main_category: str = ""
    audience_keys: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.doc_title:
            raise ValueError("DocNode.doc_title 이 비어 있다 — 어느 문서인지 모르면 참조를 못 푼다")
        if not self.parent_id:
            raise ValueError("DocNode.parent_id 가 비어 있다 — 확장 손잡이가 없는 노드는 쓸모없다")

    @property
    def scoped(self) -> bool:
        """
        별표·부칙 조각인가. 그 안의 `제N조` 는 **문서의 조 번호가 아니다** (부칙은 1조부터 다시 센다).
        그래서 이 조각 안에서는 본문 머리글을 `전조` 기준으로 쓰지 않는다 (Reviewer 3차 G1).
        """
        return any(label == "부칙" or label.startswith(("별표", "서식", "별첨", "별지"))
                   for label in self.labels)


@dataclass
class IndexStats:
    """색인 결과. **버린 행을 반드시 센다** — 0 이면 의심해야 한다."""

    rows: int = 0
    nodes: int = 0
    skipped_no_doc: int = 0
    skipped_no_parent: int = 0
    duplicate_parents: int = 0          # 같은 parent_id 가 두 번 온 경우
    nodes_without_label: int = 0        # 가리킬 수 없는 조각 (서문 등) — 버리지 않는다
    multi_article_nodes: int = 0        # 조각 하나에 조문 여럿 (장 단위 조각)
    max_articles_in_node: int = 0
    appendix_nodes: int = 0             # 별표·서식 조각 (이름표 = `별표009` 하나)
    addendum_nodes: int = 0             # 부칙 조각 (이름표 = `부칙` 하나)
    scoped_articles_dropped: int = 0    # 별표·부칙 조각이 들고 온 조 번호를 **안 쓴** 수
    articles_from_header: int = 0       # `article_no` 가 없어 헤더에서 읽은 조각 (`제7-2조` 등)
    hyphen_article_nodes: int = 0       # 하이픈 조문 이름표가 붙은 조각
    unparsed_chapter_no: int = 0        # 숫자도 별표도 아닌 `chapter_no` — 0 이 아니면 모양을 봐야 한다
    unparsed_chapter_examples: List[str] = field(default_factory=list)

    def as_dict(self) -> Dict[str, object]:
        return {
            "rows": self.rows, "nodes": self.nodes,
            "skipped_no_doc": self.skipped_no_doc,
            "skipped_no_parent": self.skipped_no_parent,
            "duplicate_parents": self.duplicate_parents,
            "nodes_without_label": self.nodes_without_label,
            "multi_article_nodes": self.multi_article_nodes,
            "max_articles_in_node": self.max_articles_in_node,
            "appendix_nodes": self.appendix_nodes,
            "addendum_nodes": self.addendum_nodes,
            "scoped_articles_dropped": self.scoped_articles_dropped,
            "articles_from_header": self.articles_from_header,
            "hyphen_article_nodes": self.hyphen_article_nodes,
            "unparsed_chapter_no": self.unparsed_chapter_no,
            "unparsed_chapter_examples": list(self.unparsed_chapter_examples),
        }


class StructureIndex:
    """
    조각 색인.

    `(문서명, 이름표)` → **노드 목록**이다. 하나가 아니다 —
    한 조문이 조각 여럿에 걸쳐 있으면 그 이름표가 조각 여럿을 가리킨다.
    """

    def __init__(self) -> None:
        self._by_node: Dict[str, DocNode] = {}
        self._by_label: Dict[Tuple[str, str], List[str]] = {}
        self._articles: Dict[str, List[str]] = {}       # 문서 → 조 번호 정렬 목록
        self._doc_display: Dict[str, str] = {}
        self.stats = IndexStats()

    @staticmethod
    def _squeeze(text: str) -> str:
        return re.sub(r"\s+", "", text or "")

    # ── 조회 ────────────────────────────────────────────────────────────
    def has_doc(self, doc_title: str) -> bool:
        return self._squeeze(doc_title) in self._articles

    def find(self, doc_title: str, label: str) -> List[DocNode]:
        """`(문서, 이름표)` 로 조각들을 찾는다. **목록이다.**"""
        ids = self._by_label.get((self._squeeze(doc_title), label), ())
        return [self._by_node[i] for i in ids]

    def node(self, node_id: str) -> Optional[DocNode]:
        return self._by_node.get(node_id)

    def all_nodes(self) -> List[DocNode]:
        return list(self._by_node.values())

    def display_title(self, doc_title: str) -> str:
        return self._doc_display.get(self._squeeze(doc_title), doc_title)

    def article_labels_of(self, doc_title: str) -> Tuple[str, ...]:
        """문서의 조 번호 목록. **정렬돼 있다** — `전조` 해소가 이 순서를 쓴다."""
        return tuple(self._articles.get(self._squeeze(doc_title), ()))

    def previous_article(self, doc_title: str, label: str) -> Optional[str]:
        order = self.article_labels_of(doc_title)
        try:
            i = order.index(label)
        except ValueError:
            return None
        return order[i - 1] if i > 0 else None

    @property
    def doc_titles(self) -> Tuple[str, ...]:
        return tuple(self._doc_display[k] for k in sorted(self._articles))

    def __len__(self) -> int:
        return len(self._by_node)

    # ── 구성 ────────────────────────────────────────────────────────────
    def add(self, node: DocNode) -> None:
        if node.node_id in self._by_node:
            self.stats.duplicate_parents += 1
            return                                   # 같은 조각이 두 번 — 먼저 것 유지
        self._by_node[node.node_id] = node
        doc_key = self._squeeze(node.doc_title)
        self._doc_display.setdefault(doc_key, node.doc_title)
        self._articles.setdefault(doc_key, [])
        for label in node.labels:
            self._by_label.setdefault((doc_key, label), []).append(node.node_id)
        for label in node.article_labels:
            if label not in self._articles[doc_key]:
                self._articles[doc_key].append(label)
        self.stats.nodes += 1
        if len(node.article_labels) > 1:
            self.stats.multi_article_nodes += 1
        self.stats.max_articles_in_node = max(
            self.stats.max_articles_in_node, len(node.article_labels))

    def finalize(self) -> "StructureIndex":
        for labels in self._articles.values():
            labels.sort()
        self.stats.nodes_without_label = sum(
            1 for n in self._by_node.values() if not n.labels)
        return self


def _payload_of(row: Mapping) -> Dict:
    """`metadata` 하위에 든 필드도 위로 올린다 (인덱서 버전마다 다르다)."""
    payload = dict(row)
    nested = payload.get("metadata")
    if isinstance(nested, Mapping):
        payload = {**nested, **{k: v for k, v in payload.items() if k != "metadata"}}
    return payload


@dataclass
class AbbreviationTable:
    """문서가 **스스로 선언한** 공식 약칭 → 정식 문서명. 두 문서가 같은 약칭을 선언하면 뺀다."""

    table: Dict[str, str] = field(default_factory=dict)        # 공백 뺀 약칭 → 문서명
    conflicts: List[str] = field(default_factory=list)


def official_abbreviations(rows: Iterable[Mapping]) -> AbbreviationTable:
    """
    제목줄(`header_path` 첫 조각)의 `(약칭: X)` 을 모은다.

    법제처 본문은 제목줄에 공식 약칭을 적는다 — `신용정보의 이용 및 보호에 관한 법률 (약칭: 신용정보법)`.
    **문서가 스스로 선언한** 이름이라 추측이 아니다. 문서 **사이** 줄임말 인용
    (`신용정보법 제32조`)을 이걸로 푼다 (2026-09-28 내부 5회차: 미보유 목록의
    `신용정보법` 162·`특정금융정보법` 88 은 보유 문서의 약칭일 수 있다).
    """
    found: Dict[str, Dict[str, str]] = {}
    for row in rows:
        payload = _payload_of(row)
        doc = _doc_title_of(payload)
        segs = header_segments(payload.get("header_path"))
        if not doc or not segs:
            continue
        m = _OFFICIAL_ABBR_RE.search(segs[0])
        if not m:
            continue
        abbr = re.sub(r"\s+", "", m.group("abbr"))
        if abbr and abbr != re.sub(r"\s+", "", doc):
            found.setdefault(abbr, {})[re.sub(r"\s+", "", doc)] = doc
    out = AbbreviationTable()
    for abbr, docs in sorted(found.items()):
        if len(docs) == 1:
            out.table[abbr] = next(iter(docs.values()))
        else:
            out.conflicts.append(abbr)
    return out


@dataclass
class HeadingIndex:
    """문서별 **진짜 제목 목록** — 포인트 전체의 `header_path` 조각에서."""

    by_doc: Dict[str, Dict[str, List[str]]] = field(default_factory=dict)  # 문서 → 토큰 키 → 제목 대조 키
    headings: int = 0
    skipped: int = 0            # 정규화 실패로 못 읽은 헤더 — 0 이 아니면 그 제목은 대조가 안 된다


def heading_index(rows: Iterable[Mapping]) -> HeadingIndex:
    """
    문서마다 실제 제목 목록을 만든다. 본문의 줄이 이 목록의 제목과 **글자 그대로** 같으면
    추측 없이 제목이다 (목차가 대표적). `clause_ref.extract_refs(known_headings=…)` 로 넘긴다.

    위치 토큰(`제N조`·`제N장`·`[별표 N]`·`부칙`)으로 시작하는 헤더만 담는다 — 그것만 인용과 헷갈린다.
    """
    found: Dict[str, Dict[str, set]] = {}
    out = HeadingIndex()
    for row in rows:
        payload = _payload_of(row)
        doc = _doc_title_of(payload)
        if not doc:
            continue
        for seg in header_segments(payload.get("header_path")):
            try:
                key = heading_key(seg)
                text_key = heading_text_key(seg) if key else ""
            except NormalizationError:
                out.skipped += 1
                continue
            if key and text_key:
                found.setdefault(doc, {}).setdefault(key, set()).add(text_key)
    out.by_doc = {d: {k: sorted(v) for k, v in m.items()} for d, m in found.items()}
    out.headings = sum(len(v) for m in out.by_doc.values() for v in m.values())
    return out


def _doc_title_of(row: Mapping) -> str:
    raw = row.get("source_file") or row.get("doc_title") or ""
    return re.sub(r"\.(md|markdown|json|txt|hwp|hwpx|pdf)$", "", str(raw).strip(), flags=re.I)


def _labels_of(payload: Mapping, stats: IndexStats,
               ) -> Tuple[Tuple[str, ...], Tuple[str, ...], Tuple[Optional[int], Optional[int], Optional[int]]]:
    """
    조각의 `(이름표, 조 이름표, (편, 장, 절))`.

    · 별표·서식 조각 → `(별표009,)` 하나. 조 번호는 **안 쓴다** (본문 불릿에서 긁힌 것이다)
    · 부칙 조각     → `(부칙,)` 하나. 조 번호는 **안 쓴다** (본칙 조 번호와 겹친다)
    · 그 외         → 조 + 장(`002장`) + 절(`002장001절`). 장·절은 **계층** 이름표다 (`struct_label`).
                     `article_no` 가 없으면 **헤더에서** 조를 읽는다
    """
    chapter_raw = payload.get("chapter_no")
    segments = header_segments(payload.get("header_path"))
    scope = _scope_of(payload, segments)

    articles = normalize_article_no(payload.get("article_no")) \
        or normalize_article_no(payload.get("article"))
    from_header = False
    if not articles:
        articles = _article_from_header(segments) or normalize_article_no(payload.get("article_title"))
        from_header = bool(articles)
    stray = tuple(a for a in articles if not _ARTICLE_LABEL_RE.match(a))   # `article_no="별표3"` 류
    articles = tuple(a for a in articles if _ARTICLE_LABEL_RE.match(a))

    # 헤더의 별표가 더 깊고 구체적이다 — `chapter_no='별표9'` 인데 헤더가 `[별표 9의1]` 이면 뒤가 맞다
    appendix = next((lab for lab in (appendix_label(s) for s in reversed(segments)) if lab), "") \
        or appendix_label(chapter_raw) or (stray[0] if stray else "")
    in_addendum = not appendix and any(_ADDENDUM_HEAD_RE.match(s) for s in segments)

    if chapter_raw not in (None, "") and not appendix_label(chapter_raw) \
            and not normalize_chapter_no(chapter_raw, "장"):
        stats.unparsed_chapter_no += 1
        if len(stats.unparsed_chapter_examples) < 5:
            stats.unparsed_chapter_examples.append(str(chapter_raw)[:20])

    if appendix or in_addendum:
        if appendix:
            stats.appendix_nodes += 1
        else:
            stats.addendum_nodes += 1
        if articles:
            stats.scoped_articles_dropped += 1
        return ((appendix or "부칙"),), (), (None, None, None)

    if from_header:
        stats.articles_from_header += 1
    if any("-" in a for a in articles):
        stats.hyphen_article_nodes += 1
    part, chapter, section = scope
    labels = list(articles)
    if chapter is not None:
        labels.append(struct_label(part, chapter))
    if section is not None:
        labels.append(struct_label(part, chapter, section))
    return tuple(labels), articles, scope


def build_index(rows: Iterable[Mapping]) -> StructureIndex:
    """
    Qdrant 행(payload dict)으로 조각 색인을 만든다.

    `parent_id` 가 노드 id 다. `article_no`·`chapter_no`·`section_no` 는 **이름표**가 된다.
    `chapter_no` 는 장 번호 **또는 별표 번호**다 — 인덱서가 `[별표 9]` 를 거기 넣는다.
    """
    index = StructureIndex()
    for row in rows:
        index.stats.rows += 1
        payload = _payload_of(row)

        doc_title = _doc_title_of(payload)
        if not doc_title:
            index.stats.skipped_no_doc += 1
            continue
        parent_id = str(payload.get("parent_id") or "")
        if not parent_id:
            index.stats.skipped_no_parent += 1
            continue

        labels, articles, scope = _labels_of(payload, index.stats)

        audience = payload.get("audience_keys") or ()
        if isinstance(audience, str):
            audience = (audience,)
        chunk = str(payload.get("chunk_id") or "")

        index.add(DocNode(
            node_id=parent_id, doc_title=doc_title, parent_id=parent_id,
            labels=tuple(labels), article_labels=tuple(articles), scope=scope,
            title=str(payload.get("article_title") or "").strip(),
            chunk_ids=(chunk,) if chunk else (),
            category_id=str(payload.get("category_id") or ""),
            main_category=str(payload.get("main_category") or ""),
            audience_keys=tuple(audience),
        ))
    return index.finalize()
