# -*- coding: utf-8 -*-
"""
graph_build/clause_ref.py

규정 본문에서 **조문 참조 후보**를 뽑는다. LLM 을 쓰지 않는다.

이 모듈은 **후보만** 만든다. 연결 여부는 여기서 정하지 않는다 —
"그 문서를 우리가 갖고 있는가 / 그 조문이 실제로 있는가" 는 해소 단계(2단계)의 질문이다.
여기서 판정하려다 실패한 이력이 아래 금지사항에 있다.

파이프라인에서 이 모듈의 자리:

    ① 정규식이 후보를 뽑는다        ← 이 파일
    ② 존재 대조                     색인에 그 조문이 있나?
    ③ LLM 이 판정한다               "이거 조문 참조 맞아?" 객관식만. 새 참조 생성 불가
    ④ 셋 다 통과한 것만 엣지가 된다

정규식을 쓰는 이유:
  조문 인용은 **형식이 정해져 있다** (`제N조 제M항`). 사람이 정한 문법이 있는 걸
  LLM 에 추측시킬 이유가 없다. 그리고 정규식은 틀리면 **항상 같은 방식으로** 틀리므로
  한 줄 고치면 그 유형이 통째로 고쳐지고 테스트로 못 박힌다.
  LLM 은 매번 다르게 틀려서 그 루프가 안 돈다.

세 가지 계약:
  1. **판정하지 않는다.** 문서명을 기록할 뿐, 사내/외부/보유 여부를 여기서 정하지 않는다.
  2. **못 뽑은 것을 버리지 않는다.** `ExtractResult.rejected` 에 사유와 함께 남는다.
  3. **모든 후보가 원문 오프셋을 들고 다닌다.** 증거 없는 후보는 만들어지지 않는다.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

# ── 문서명 ──────────────────────────────────────────────────────────────────

#: 가운뎃점 변이. 전부 `·`(U+00B7) 로 모은다. **모두 1글자라 오프셋이 보존된다.**
MIDDLE_DOTS = "ㆍ‧•・"
_DOT_TABLE = {ord(c): "·" for c in MIDDLE_DOTS}

#: 문서명 접미사를 계열별로 나눈다. 대용표현(`같은 법`)이 **같은 계열**만
#: 물어오게 하려면 계열 정보가 필요하다.
SUFFIX_FAMILY: Dict[str, Tuple[str, ...]] = {
    "법":   ("법률", "법", "시행령", "시행규칙", "고시", "예규", "훈령", "조례"),
    "규정": ("규정", "내규", "정관", "준칙", "기준", "방침"),
    "규칙": ("규칙", "세칙", "요령"),
    "지침": ("지침", "매뉴얼", "절차서", "가이드"),
    "기타": ("규약", "협약", "약관"),
}
#: 긴 접미사가 먼저 와야 `시행령` 이 `령`·`법` 에 밀리지 않는다.
ALL_SUFFIXES = sorted(
    {s for fam in SUFFIX_FAMILY.values() for s in fam}, key=len, reverse=True
)
DOC_SUFFIX = "(?:" + "|".join(ALL_SUFFIXES) + ")"

#: 접미사 → 계열 역색인
_SUFFIX_TO_FAMILY = {s: fam for fam, ss in SUFFIX_FAMILY.items() for s in ss}

#: 앞 문서명을 물려받는 대용표현. `같은 법 시행규칙` 처럼 꼬리가 붙는다.
#: `(?<![가-힣])` 가 **필수**다. 없으면 `교육기본법` 의 `본`, `안전규정` 의 `전`,
#: `담당규정` 의 `당` 이 단어 안쪽에서 잡혀 **남의 법령이 자기 문서가 된다**
#: (2026-09-23 Reviewer 2차 실검출).
#: `동법`·`동 규정`·`동법 시행령` 도 대용표현이다 (2026-09-28 내부 5회차: 미보유 문서 목록에
#: `동법 시행령` 103건 — 문서명으로 오인돼 못 이었다).
ANAPHOR_HEAD = r"(?<![가-힣])(?:같은|동일한|전|동)"
#: 자기 문서를 가리키는 표현. **대용표현이 아니다** — 앞을 뒤지면 남의 규정이 붙는다.
SELF_HEAD = r"(?<![가-힣])(?:이|본|해당|당)"

_TITLE_GAP = r"[\s의에]{0,3}$"

ANAPHOR_TAIL_RE = re.compile(
    rf"({ANAPHOR_HEAD}\s*(?P<anchor>{DOC_SUFFIX})"
    rf"(?:\s*(?P<tail>{DOC_SUFFIX}))?){_TITLE_GAP}"
)
#: `이 영` 은 시행령이 자기를 부르는 말이다. `영` 은 접미사 목록에 없어서(`운영`·`경영` 이 걸린다)
#: 자기 지시 앵커에만 따로 넣는다.
SELF_TAIL_RE = re.compile(
    rf"({SELF_HEAD}\s*(?P<anchor>{DOC_SUFFIX}|영)"
    rf"(?:\s*(?P<tail>{DOC_SUFFIX}))?){_TITLE_GAP}"
)
BRACKET_TAIL_RE = re.compile(rf"[「『]([^」』\n]{{1,40}})[」』]{_TITLE_GAP}")

#: 맨 문서명. 공백이 든 이름(`근로기준법 시행규칙`)을 위해 앞 조각을 **8개까지** 끌어온다.
#: 조사로 끝나는 조각은 `_trim_particles` 가 잘라낸다.
#: 마지막 조각이 접미사 단독일 수 있다 — `금융소비자보호에 관한 법률`.
#: 단 그때는 앞 조각이 **반드시** 있어야 한다 (`법률` 홀로는 이름이 아니다).
#: 조각 사이는 **줄바꿈이 아닌 공백**만 — 문서명은 줄을 넘지 않는다.
#: 사고 이력 (2026-09-28 내부 5회차): 5개 제한에 `신용정보의 이용 및 보호에 관한 법률 시행령`
#: (앞 조각 6개)이 `이용 및 보호에 관한 법률 시행령` 으로 잘려 **보유한 시행령을 못 이었다** (173건).
_BARE_BODY = (
    rf"(?:(?:[가-힣A-Za-z0-9·\-]+[ \t]+){{1,8}}{DOC_SUFFIX}"
    rf"|(?:[가-힣A-Za-z0-9·\-]+[ \t]+){{0,8}}"
    rf"[가-힣A-Za-z][가-힣A-Za-z0-9·\-]*{DOC_SUFFIX})"
)
BARE_TAIL_RE = re.compile(rf"({_BARE_BODY}){_TITLE_GAP}")
#: 접미사 하나만 남은 건 문서명이 아니다.
BARE_SUFFIX_ONLY_RE = re.compile(rf"^{DOC_SUFFIX}$")
#: 대용표현 해소용. 앞쪽에서 실제 문서명을 찾을 때 쓴다. 공백 포함.
BARE_ANYWHERE_RE = re.compile(_BARE_BODY)
#: 대용표현이 차지한 구간. 해소할 때 여기서 이름을 주워오면 `법 시행규칙` 처럼 잘린다.
ANAPHOR_SPAN_RE = re.compile(
    rf"(?:{ANAPHOR_HEAD}|{SELF_HEAD})\s*{DOC_SUFFIX}(?:\s*{DOC_SUFFIX})?"
)

#: 조각 끝에 붙으면 문서명의 일부가 아니라 앞 문장의 꼬리다.
#: `란`(`"대주주"란 법 제2조`)도 조사다 — 빠지면 `란 법` 이 문서명이 됐다 (Reviewer 2차 F6).
PARTICLE_TAIL_RE = re.compile(r"(?:은|는|이|가|을|를|에|의|도|만|과|와|로|으로|께서|부터|란)$")
#: 접속사는 문서명의 일부가 아니다. `제54조 및 취업규칙` → `취업규칙`
CONNECTOR_RE = re.compile(r"^(?:및|또는|그리고|내지|혹은|또)$")
#: `…에 관한 법률` 처럼 `에` 가 이름의 일부인 경우. 여기선 자르지 않는다.
NAME_JOINER_RE = re.compile(r"^(?:관한|관하여|대한|대하여|따른|위한)$")
#: 용언 어미로 끝나는 조각은 문서명이 아니라 앞 문장이다.
#: `불구하고 상법시행령` → `상법시행령`.
#: **보수적으로** 잡는다 — 너무 자르면 `근로기준법 시행규칙` 이 `시행규칙` 이 되어 위험하다.
#: 그래서 `복지`(2자, 지로 끝남) 같은 이름 조각은 건드리지 않는다.
PREDICATE_TAIL_RE = re.compile(
    r"(?:하고|하며|하여|되고|되며|되어|않고|않으며|이고|이며|으로서|로서)$"
    r"|^(?:따라|따른|통해|대해|관해|위해|제외하고|포함하여|준용하는|정하는|의한)$"
)

PARAGRAPH_BREAK_RE = re.compile(r"\n\s*\n")
#: 문서명 탐색 창. 30 이면 `특정 금융거래정보의 보고 및 이용 등에 관한 법률 시행령`(31자)이 안 들어간다.
TITLE_LOOKBACK = 48

# ── 위치 토큰 ───────────────────────────────────────────────────────────────

#: 목 기호는 **가나다라…** 14자뿐이다. 가~하 문자 범위로 쓰면 한글 음절 9천 자가 걸려
#: `품목`·`제목`·`종목` 이 전부 조문 참조가 된다 (2026-09-23 Reviewer 실검출).
MOK_LETTERS = "가나다라마바사아자차카타파하"

#: `제` 없는 `N조` 뒤에 이 단위가 오면 금액이다 (`1조원`).
AMOUNT_UNIT_RE = re.compile(r"^\s*(?:원|억|만|천|달러|엔|위안|\d)")

#: 하이픈 조문(`제7-2조`)은 감독규정식 `장-조` 번호다. **가지조문(`제7조의2`)이 아니다.**
#: 이게 없으면 `제7-2조` 의 `2조` 만 맨 조 표기로 잡혀 거부됐다
#: (2026-09-28 내부 실측: `article_no` 없는 조각 5,094건 상당수가 `제7-2조` 헤더).
LOC_RE = re.compile(
    rf"""
    (?P<article_hy>    제\s*(?P<h_pre>\d+)\s*-\s*(?P<h_no>\d+)\s*조
                       (?:\s*의\s*(?P<h_sub>\d+))?           )
  | (?P<article>       제\s*(?P<a_no>\d+)\s*조
                       (?:\s*의\s*(?P<a_sub>\d+))?           )
  | (?P<article_hy_bare> (?<![\d가-힣\-])(?P<hb_pre>\d+)-(?P<hb_no>\d+)\s*조
                       (?:\s*의\s*(?P<hb_sub>\d+))?          )
  | (?P<article_bare>  (?<![\d가-힣])(?P<ab_no>\d+)\s*조
                       (?:\s*의\s*(?P<ab_sub>\d+))?          )
  | (?P<para>          제\s*(?P<p_no>\d+)\s*항               )
  | (?P<item>          제\s*(?P<i_no>\d+)\s*호               )
  | (?P<subitem>       (?<![가-힣])(?P<s_ch>[{MOK_LETTERS}])\s*목
                       (?:(?![가-힣])|(?=[에의를은는이가과와도만]))  )
  | (?P<chapter>       제\s*(?P<c_no>\d+)\s*장               )
  | (?P<section>       제\s*(?P<sc_no>\d+)\s*절              )
  | (?P<subsection>    제\s*(?P<ss_no>\d+)\s*관              )
  | (?P<form_no>       별지\s*제\s*(?P<f_no>\d+)\s*호\s*서식  )
  | (?P<form>          (?:별지)?\s*서식\s*(?P<fo_no>\d+)      )
  | (?P<table>         별표\s*(?P<t_no>\d+(?:\s*-\s*\d+)?)
                       (?:\s*의\s*(?P<t_sub>\d+))?           )
  | (?P<attach>        별첨\s*(?P<at_no>\d+)                 )
  | (?P<addendum>      부칙                                  )
    """,
    re.VERBOSE,
)

#: 상대참조. **양쪽 낱말 경계가 필수다.** 없으면 `안전조치` 의 `전조`, `사전조사`·`기본조건`·
#: `해당 조건`·`이항분포` 가 상대참조가 된다. 오른쪽은 비한글·조사·`제N`(`전조제1항`)만 허용.
#: 사고 이력 (2026-09-28 내부 5회차): `산업안전보건기준에 관한 규칙` 의 `안전조치` 가 `전조` 로 잡혀
#: **바로 앞 조문에 연결**됐다 — LLM 엇갈림 3건 전부. 2026-09-23 에 `SELF_HEAD`·`ANAPHOR_HEAD` 에
#: 경계를 넣으면서 이 정규식을 빠뜨렸다.
RELATIVE_RE = re.compile(
    r"(?<![가-힣])(?:전조|전항|전호|같은\s*[조항호]|본조|본항|해당\s*[조항]|이\s*[조항])"
    r"(?:(?![가-힣])|(?=[의에을를은는이가과와도만로]|까지|부터|제\s*\d))"
)

#: 범위 끝 target 파서. `003조의005` 의 가지 번호, `007-005조` 의 장 번호까지 읽어야 한다.
_RANGE_END_RE = re.compile(
    r"^(?:(?P<pre>\d+)-)?(?P<main>\d+)(?P<unit>[조항호])(?:의(?P<sub>\d+))?$")

#: 범위 연결자. **하이픈과 줄바꿈은 뺀다** — 마크다운 목록 `- 제3조\n- 제9조` 가
#: 범위로 묶여 없는 조문을 창조했다 (2026-09-23 Reviewer 실검출).
RANGE_SEP_RE = re.compile(r"[ \t]*(?:부터|내지|～|~)[ \t]*")
RANGE_TAIL_RE = re.compile(r"\s*까지")

#: 실측(2026-09-23 내부, 엣지 112건) 에서 **59건(53%)이 관계 없음** 이었다.
#: 법령 문체가 목록보다 다양했다 — `해당하는`·`위반한`·`갈음한다`·`본다` 등.
RELATION_RULES: Tuple[Tuple[str, re.Pattern], ...] = (
    ("준용", re.compile(r"준용")),
    ("예외", re.compile(r"불구하고|예외로|아니한다|아니하는|그러하지")),
    ("제외", re.compile(r"제외|해당하지")),
    ("적용", re.compile(
        r"따른다|따른|따르|따라|의한다|의하여|의해|의한|정하는\s*바|적용|"
        r"해당하는|해당하지\s*아니|위반한|위반하여|갈음한다|갈음하여|준한다")),
    ("참조", re.compile(
        r"참조|참고|정한|정하는|규정한|규정하는|규정에|같다|본다|보는|"
        r"열거한|명시한|기재한|의미한다")),
)
RELATION_WINDOW = 25

#: 나열·복합 참조의 이음매. 이 사이에는 문서명이 안 적히지만 **앞 참조와 같은 문서**다.
#: `「근로기준법」 제54조 및 제55조` / `제8조 제2항 제3호 가목` / `제5조·제6조`
#:
#: 사고 이력 (2026-09-23 Reviewer 2차): 전파가 없으면 두 번째 참조가
#: `title_source=none` 이 되는데, 그건 _GUIDE 정의상 **"같은 문서"라는 적극적 주장**이라
#: 없는 엣지가 생긴다. 실물 문단 오탐 10건 중 **5건이 이 원인**이었다.
LIST_GAP_RE = re.compile(r"^[\s·,、/]*(?:및|그리고|또는|내지)?[\s·,、/]*$")

#: 조문 머리글(`제12조(여신한도) …`). 자기 자신으로의 참조가 되면 자기 루프 엣지가 생긴다.
#: 뒤에 조사가 붙으면 머리글이 아니라 **인용**이다 —
#: `제54조(휴게)의 규정에 따라` 를 머리글로 보면 정당한 참조를 잃는다
#: (2026-09-23 Reviewer 2차 실검출).
#: 불릿(`- 제1조(목적)`)도 머리글이다 — 인덱서 자신이 불릿을 조문으로 긁는다(`parse_article_segment`).
#: 사고 이력 (2026-09-28 Reviewer 2차 F5): 불릿 목차 `- 제1조(목적)\n- 제2조(정의)` 가 전부 인용이 됐다.
HEADING_RE = re.compile(
    r"^\s*(?:[-•·*][ \t]*)?제\s*\d+\s*(?:-\s*\d+\s*)?조(?:\s*의\s*\d+)?\s*[(（][^)）\n]{0,60}[)）]"
    r"(?![의을를에와과이가는은도만])",
    re.MULTILINE)

#: 장·절·관 뒤에 이게 오면 **인용**이다. 안 오면 머리글·목차의 제목이다.
#:   인용   `제2장의 규정` · `제2장 및 제3장` · `제2장 제1절` · `(제2장 참조)` · `제3장 각 조`
#:   머리글 `제2장 보고정보 관리` · 목차 줄 · 표 칸 `| 제1장 | 총칙 |`
#: 사고 이력 (2026-09-28 내부 실측): `FIU보고정보보안관리지침` 의 목차 조각이
#: `제1장`~`제7장` 으로 **모든 장 조각에 연결**됐다 (LLM: "목차의 장 제목", 엇갈림 12건 중 10건).
UNIT_CITE_TAIL_RE = re.compile(
    r"(?:[의에을를은는이가과와도만로]|으로|부터|까지)"
    r"|[ \t]*(?:및|또는|그리고|내지|부터|까지|참조|참고|[·,、~～)）」』]|제[ \t]*\d)"
    r"|[ \t]+(?:각|전부|전체|중|이하)(?![가-힣])"
    r"|[ \t]*[(（][^)）\n]{0,40}[)）][ \t]*"
    r"(?:[의에을를은는이가과와도만로]|으로|및|또는)")

#: 괄호 친 별표(`[별표 4] 계정과목별 …`, `<별표6> …`)는 머리글이다.
#: 뒤에 조사·연결어가 붙으면 인용이다 — `[별표 1]과 같다`, `([별표 1] 참조)`.
_APPENDIX_OPEN = ("[", "<", "【", "〈", "《", "〔", "［")
APPENDIX_CLOSE_RE = re.compile(r"[ \t]*[\]>】〉》〕］]")
APPENDIX_CITE_TAIL_RE = re.compile(
    r"(?:[의에을를은는이가과와도만로]|으로|부터|까지)"
    r"|[ \t]*(?:및|또는|그리고|내지|부터|까지|참조|참고|[·,、~～)）」』])")

#: 인덱서는 조각 본문 첫 줄에 **자기 헤더**를 붙인다 (`text = leaf + "\n" + 본문`,
#: `archive/Markdown_RAG_Qdrant_json_2collection_payload_index.py` `split_parents`).
#: 그 줄 맨 앞의 위치 토큰은 이 조각의 이름표지 인용이 아니다.
LEAD_PREFIX_RE = re.compile(r"[\s#>*\-•·|\[<(【〈《〔［]*(?:\d{1,3}[.)][ \t]*)?")
#: 맨 앞 토큰끼리의 이음 (`제2장 제1절 통칙`). **닫는 괄호는 넘지 않는다** — `[별표 4] 제4-1조 관련` 의
#: 제4-1조는 별표가 **관련된** 조문이지 자기 이름표가 아니다 (Reviewer 2차 F12).
LEAD_SEP_RE = re.compile(r"[ \t·/]*")

#: 목차 줄 `제1장 총칙(제1조~제3조)` 의 괄호. 장 머리글 뒤 같은 줄의 첫 괄호만 본다.
TOC_PAREN_RE = re.compile(r"[(（][^)）\n]{1,40}[)）]")
#: 줄 머리 부칙 머리글 `부칙 <제15호,2021. 1. 1.>` · `부칙(2020. 1. 1.)` · `부칙`
ADDENDUM_LINE_TAIL_RE = re.compile(r"[ \t]*(?:[<(（〈]|$)", re.MULTILINE)

#: `부칙 제2조` 의 제2조는 **부칙의** 조문이다. 본칙 제2조로 풀면 엉뚱한 조문이 붙는다.
ADDENDUM_GAP_RE = re.compile(r"^[ \t]*(?:[<(（〈][^>)）〉\n]{0,30}[>)）〉][ \t]*)?$")

#: `전조` 의 기준 조문을 정하는 머리글. 줄 머리의 `제N조(…)` — 불릿(`- 제3조(목적)`)도 받는다
#: (인덱서가 불릿을 조문으로 긁는 것과 같은 기준). **거부용이 아니라 기준 찾기용이다.**
#: 사고 이력 (2026-09-28): 조각 이름표는 `002조` 인데 본문에 `제3조(적용) 전조를 준용한다` 가
#: 더 들어 있으면, 조각 이름표 기준으로 풀어 제3조의 전조(제2조)를 **제1조**로 이었다.
ARTICLE_CONTEXT_RE = re.compile(
    r"^[ \t]*(?:[-•·*][ \t]*)?제\s*(?:(?P<pre>\d+)\s*-\s*)?(?P<no>\d+)\s*조"
    r"(?:\s*의\s*(?P<sub>\d+))?\s*[(（]",
    re.MULTILINE)

REJECT_HEADING = "조문 머리글 — 자기 자신 표시"
REJECT_LEAF_HEADING = "조각 머리글 — 인덱서가 붙인 자기 헤더"
REJECT_UNIT_HEADING = "장·절 머리글·목차 — 인용 아님"
REJECT_APPENDIX_HEADING = "별표·서식 머리글 — 인용 아님"
REJECT_ADDENDUM_ARTICLE = "부칙의 조문 — 본칙 조문이 아님"
REJECT_BARE_ARTICLE = "'제' 없는 조 표기에 문서명도 없음 — 금액·수량일 수 있다"
REJECT_ALIAS = "약칭이 가리키는 문서를 모름"
REJECT_TOC_RANGE = "목차 줄의 조문 범위 — 인용 아님"
REJECT_KNOWN_HEADING = "문서의 실제 제목과 같은 줄 — 제목"
REJECT_ADDENDUM_HEADING = "부칙 머리글 — 인용 아님"

TITLE_NONE = "none"          # 문서명 없음 = 같은 문서
TITLE_EXPLICIT = "explicit"  # 본문에 그대로 적힘
TITLE_INHERITED = "inherited"# '같은 법' 으로 앞에서 물려받음
TITLE_SELF = "self"          # '이 규정' 등 자기 지시
TITLE_PROPAGATED = "propagated"  # 나열·복합 참조가 앞 참조에서 물려받음
TITLE_ALIAS = "alias"        # 약칭 — 문서 안 정의(`이하 "법"`) 또는 제목(시행령→모법)으로 풀림
_ALIAS_UNKNOWN = "alias?"    # 내부 표시. 후보로 나가지 않고 **거부**된다

#: 약칭이 **반드시** 다른 문서를 가리키는 말. 법령 입안 관례상 시행령·시행규칙·감독규정은
#: 모법을 `법`, 시행령을 `영` 으로 부른다. 못 풀면 **같은 문서로 떨어뜨리지 않고 거부한다.**
#: 사고 이력 (2026-09-28 내부 실측): `산업안전보건법 시행령` 의 `법 제57조` 가
#: 시행령 **자기** 제57조로 붙었다 (LLM: "법(산업안전보건법) 조문 참조").
ALIAS_REQUIRED: Tuple[str, ...] = ("법", "영", "시행령", "시행규칙")
#: 위치 토큰 바로 앞의 **단독 낱말**. 약칭(`법`·`영`·`규정`)을 찾는 데 쓴다.
#: 앞에 글자가 붙어 있으면 낱말이 아니다 — `운영 제3조` 의 `영` 은 약칭이 아니다.
LONE_WORD_TAIL_RE = re.compile(rf"(?<![가-힣A-Za-z0-9·\-])([가-힣]+){_TITLE_GAP}")

KIND_ABSOLUTE = "absolute"
KIND_RELATIVE = "relative"
KIND_RANGE = "range"


class NormalizationError(ValueError):
    """오프셋을 지키면서 정규화할 수 없는 입력. **조용히 넘어가지 않는다.**"""


# ── 자료구조 ────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ClauseRef:
    """참조 **후보** 하나. 연결 여부는 아직 정해지지 않았다."""

    raw: str
    start: int
    end: int
    unit: str                        # 조|항|호|목|장|절|관|별표|서식|별첨|부칙
    target: str                      # 정규화 키. 예 '010조의003'
    doc_title: str = ""              # '' 이면 같은 문서
    title_source: str = TITLE_NONE   # none | explicit | inherited | self
    kind: str = KIND_ABSOLUTE
    article: Optional[int] = None
    sub_article: Optional[int] = None
    paragraph: Optional[int] = None
    item: Optional[int] = None
    relation: str = ""               # 못 찾으면 빈 값. 기본값을 채우지 않는다
    range_end: Optional[str] = None
    article_prefix: Optional[int] = None  # 하이픈 조문 `제7-2조` 의 7. 가지조문과 다르다
    context_article: str = ""        # 상대참조가 놓인 조문 (본문 머리글 기준). 없으면 조각 이름표로

    def __post_init__(self) -> None:
        if not self.raw:
            raise ValueError("ClauseRef.raw 는 비어 있을 수 없다 — 증거 없는 후보 금지")
        if self.end <= self.start:
            raise ValueError(f"오프셋이 뒤집혔다: start={self.start} end={self.end}")
        if self.start < 0:
            raise ValueError(f"오프셋이 음수다: start={self.start}")


@dataclass(frozen=True)
class Rejected:
    raw: str
    start: int
    end: int
    reason: str


@dataclass
class ExtractResult:
    refs: List[ClauseRef] = field(default_factory=list)
    rejected: List[Rejected] = field(default_factory=list)


# ── 정규화 ──────────────────────────────────────────────────────────────────

def normalize_for_match(text: str) -> str:
    """
    매칭용 정규화. **길이가 보존된다** — 오프셋이 원문과 1:1 이어야 하기 때문.

    Raises:
        NormalizationError: NFC 가 길이를 바꾸는 입력(조합형 한글 등).
            오프셋 계약과 매칭이 양립하지 않으므로 **호출자에게 알린다.**
            조용히 원문을 돌려주면 `제`·`조` 리터럴이 하나도 안 맞아
            "참조 0건" 으로 보이는데, 참조가 없는 조문과 구분이 안 된다.
    """
    dotted = text.translate(_DOT_TABLE)
    nfc = unicodedata.normalize("NFC", dotted)
    if len(nfc) != len(dotted):
        raise NormalizationError(
            "NFC 정규화가 길이를 바꾼다(조합형 한글 추정). "
            "호출부에서 NFC 로 정규화한 본문을 넘길 것 — "
            f"원본 {len(dotted)}자 → NFC {len(nfc)}자"
        )
    return nfc


def pad3(n: int) -> str:
    """조항 번호 3자리 0패딩. `src/lib/util/decide_regulation.py` 와 같은 규칙."""
    return str(n).zfill(3)


def article_target(no: int, sub: Optional[int] = None, prefix: Optional[int] = None) -> str:
    """
    조 이름표. 색인(`structure.py`)과 추출이 **이 함수 하나**로 같은 형식을 만든다.

      제3조 → `003조` · 제3조의2 → `003조의002` · 제7-2조 → `007-002조` · 제7-2조의3 → `007-002조의003`

    하이픈 조문은 운영 `normalize_location_keyword` 가 인식하면 낼 형식과 같다
    (`제` 떼고 숫자마다 3자리). **`제7-2조` 와 `제7조의2` 는 다른 조문이다.**
    """
    head = f"{pad3(prefix)}-{pad3(no)}" if prefix is not None else pad3(no)
    return f"{head}조의{pad3(sub)}" if sub is not None else f"{head}조"


def _digits(raw: Optional[str]) -> Optional[int]:
    return None if raw is None else int(re.sub(r"\D", "", raw))


def _squeeze(text: str) -> str:
    return re.sub(r"\s+", "", text)


#: `같은 법` 과 `같은 법률` 은 서로 통한다. 나머지는 글자 그대로.
ANAPHOR_EQUIV: Dict[str, Tuple[str, ...]] = {
    "법": ("법", "법률"),
    "법률": ("법", "법률"),
}


def _matches_anaphor(title: str, anchor: str) -> bool:
    """
    `같은 {anchor}` 가 `title` 을 가리킬 수 있는가 — **접미사로 끝나는가**로 본다.

    계열표로 묶으면 `시행규칙` 이 법 계열이라 `같은 규칙` 과 안 맞는다
    (2026-09-23 실검출). 끝 글자를 보는 쪽이 실제 어법에 맞다:
      `같은 법`   + `근로기준법`          → ✅
      `같은 법`   + `취업규칙`            → ❌ (이게 외부 법령을 사내로 붙이던 구멍)
      `같은 규칙` + `근로기준법 시행규칙`  → ✅
    """
    if not anchor:
        return True
    squeezed = _squeeze(title)
    return any(squeezed.endswith(suf) for suf in ANAPHOR_EQUIV.get(anchor, (anchor,)))


def _cut_points(segments: Sequence[str]) -> List[int]:
    """
    문서명 후보 앞에서 **잘라도 되는** 지점(조각 인덱스)들. 앞에서부터.

    잘라도 되는 곳은 앞 조각이 **문장 꼬리**일 때뿐이다 — 위치 토큰·용언 어미·조사로 끝남,
    또는 위치 토큰 뒤의 접속사. 이름 조각(`공무원`)에서는 자르지 않는다.
    """
    def _is_position(seg: str) -> bool:
        """`제54조` 뿐 아니라 `전조`·`같은 항` 같은 상대참조도 위치 토큰이다."""
        return bool(LOC_RE.search(seg) or RELATIVE_RE.search(seg))

    cuts: List[int] = []
    for i, seg in enumerate(segments[:-1]):      # 마지막 조각은 접미사라 검사 안 함
        nxt = segments[i + 1]
        if _is_position(seg) or PREDICATE_TAIL_RE.search(seg):
            cuts.append(i + 1)                   # `불구하고 상법시행령` → `상법시행령`
        elif CONNECTOR_RE.match(seg) and any(_is_position(x) for x in segments[:i]):
            # `제54조 및 취업규칙` → 자른다. `여신 및 채권관리규정` → **안 자른다** —
            # 앞에 위치 토큰이 없으면 `및` 은 문서명의 일부다 (2026-09-23 Reviewer 2차).
            cuts.append(i + 1)
        elif PARTICLE_TAIL_RE.search(seg) and not NAME_JOINER_RE.match(nxt):
            # `…의` 뒤로 `관한`·`대한` 이 이어지면 관형격은 **이름 안**이다 —
            # `신용정보의 이용 및 보호에 관한 법률`, `금융산업의 구조개선에 관한 법률`.
            if seg.endswith("의") and any(NAME_JOINER_RE.match(x) for x in segments[i + 1:]):
                continue
            cuts.append(i + 1)                   # `…에 관한 법률` 은 자르지 않는다
    return cuts


def _trim_particles(candidate: str) -> str:
    """
    문서명 후보 앞에 딸려온 문장 꼬리를 자른다 — **마지막** 절삭점에서.

    `이 규정은 인사규정` → `인사규정`  (`규정은` 이 조사로 끝남)
    `공무원 인사규정`   → 그대로       (`공무원` 은 조사로 안 끝남)

    **접미사로 좁히지 않는다.** 그렇게 하면 `공무원 인사규정` 이 `인사규정` 으로 잘려
    남의 규정이 우리 규정이 된다 (2026-09-23 Reviewer 실검출).
    """
    segments = candidate.split()
    cuts = _cut_points(segments)
    return " ".join(segments[cuts[-1] if cuts else 0:])


# ── 문서명 탐색 ─────────────────────────────────────────────────────────────

def _apply_alias(trimmed: str, aliases: Mapping[str, str]) -> str:
    """`법` → 모법, `법 시행령` → 모법 시행령. 못 풀면 빈 문자열 — 추측하지 않는다."""
    if not trimmed or not aliases:
        return ""
    key = _squeeze(trimmed)
    if key in aliases:
        return aliases[key]
    tokens = trimmed.split()
    if (len(tokens) >= 2 and tokens[0] in aliases
            and BARE_SUFFIX_ONLY_RE.match(_squeeze(" ".join(tokens[1:])))):
        return f"{aliases[tokens[0]]} {' '.join(tokens[1:])}"
    return ""


def _find_title_before(text: str, pos: int, aliases: Optional[Mapping[str, str]] = None,
                       ) -> Tuple[Tuple[str, str], int, str, str]:
    """
    `pos` 바로 앞에서 문서명을 찾는다.

    Returns:
        ((자르기 전 후보, 자른 후보), 시작 오프셋, title_source, 보조값)
        보조값은 대용표현이면 접미사(`같은 법` → `법`), 약칭이면 약칭 자체(`법`).
        못 찾으면 (("", ""), -1, TITLE_NONE, "").

    lookback 창의 **끝에 앵커**를 건다. 문서명은 위치 토큰 바로 앞에 붙어 있을 때만
    문서명이다. 그 사이에 다른 내용이 끼면 붙은 문서명이 아니다.
    """
    aliases = aliases or {}
    window_start = max(0, pos - TITLE_LOOKBACK)
    window = text[window_start:pos]

    m = SELF_TAIL_RE.search(window)              # '이 규정' — 앞을 뒤지면 안 된다
    if m:
        t = m.group(1).strip()
        return (t, t), window_start + m.start(), TITLE_SELF, m.group("anchor")

    m = ANAPHOR_TAIL_RE.search(window)           # '같은 법'
    if m:
        t = m.group(1).strip()
        return (t, t), window_start + m.start(), TITLE_INHERITED, m.group("anchor")

    m = BRACKET_TAIL_RE.search(window)           # 「은행법」
    if m:
        t = m.group(1).strip()
        return (t, t), window_start + m.start(), TITLE_EXPLICIT, ""

    m = BARE_TAIL_RE.search(window)
    if m:
        raw_cand = m.group(1).strip()
        trimmed = _trim_particles(raw_cand)
        offset = m.start() + raw_cand.rindex(trimmed) if trimmed and trimmed in raw_cand \
            else m.start()
        aliased = _apply_alias(trimmed, aliases)
        if aliased:
            return (aliased, aliased), window_start + offset, TITLE_ALIAS, trimmed
        tokens = trimmed.split()
        if len(tokens) >= 2 and tokens[-1] == "법":
            # `이 경우 법 제57조` — 이름은 `…법` 으로 붙여 쓴다. **띄어 쓴 맨 `법`** 은 이름 끝이 아니라
            # 약칭이다. 안 그러면 `경우 법` 이 문서명이 됐다 (Reviewer 2차 F6)
            at = window_start + m.start() + raw_cand.rfind("법")
            if "법" in aliases:
                return (aliases["법"], aliases["법"]), at, TITLE_ALIAS, "법"
            return ("법", "법"), at, _ALIAS_UNKNOWN, "법"
        if trimmed and not BARE_SUFFIX_ONLY_RE.match(_squeeze(trimmed)):
            return (raw_cand, trimmed), window_start + offset, TITLE_EXPLICIT, ""

    # 단독 낱말 약칭. 줄 머리의 `법 제57조` 는 앞 낱말이 없어 위 BARE 가 못 잡는다.
    m = LONE_WORD_TAIL_RE.search(window)
    if m:
        word = m.group(1)
        if word in aliases:
            return (aliases[word], aliases[word]), window_start + m.start(), TITLE_ALIAS, word
        if word in ALIAS_REQUIRED:
            return (word, word), window_start + m.start(), _ALIAS_UNKNOWN, word

    return ("", ""), -1, TITLE_NONE, ""


def _anaphor_tail(anaphor_text: str) -> str:
    """`같은 법 시행규칙` → `시행규칙`. 꼬리가 없으면 빈 문자열."""
    m = re.match(rf"^{ANAPHOR_HEAD}\s*{DOC_SUFFIX}", anaphor_text)
    return anaphor_text[m.end():].strip() if m else ""


def _resolve_anaphora(text: str, anchor: int, anaphor_text: str, anchor_suffix: str,
                      resolved_before: Sequence[Tuple[int, str]] = ()) -> str:
    """
    `같은 법` 이 가리키는 문서명을 **앞에서** 찾는다.

    **접미사가 맞는 제목만 후보다.** `같은 법` 은 `…법/법률/시행령` 으로 끝나는 제목을
    가리키지, 직전에 나온 `취업규칙` 을 가리키지 않는다
    (2026-09-23 Reviewer 실검출 — 외부 법령이 사내 엣지가 됐다).

    꼬리가 붙으면 합성한다 — `같은 법 시행규칙` 은 `A법` 이 아니라 `A법 시행규칙` 이다.
    문단 경계를 넘어가면 다른 맥락이므로 거기서 멈춘다.
    """
    head = text[:anchor]
    breaks = list(PARAGRAPH_BREAK_RE.finditer(head))
    scope = head[breaks[-1].end() if breaks else 0:]

    best: Tuple[int, str] = (-1, "")
    for m in BRACKET_TAIL_RE.finditer(scope):
        cand = m.group(1).strip()
        if _matches_anaphor(cand, anchor_suffix) and m.start() > best[0]:
            best = (m.start(), cand)
    for m in re.finditer(rf"[「『]([^」』\n]{{1,40}})[」』]", scope):
        cand = m.group(1).strip()
        if _matches_anaphor(cand, anchor_suffix) and m.start() > best[0]:
            best = (m.start(), cand)
    anaphor_spans = [(x.start(), x.end()) for x in ANAPHOR_SPAN_RE.finditer(scope)]
    for m in BARE_ANYWHERE_RE.finditer(scope):
        if any(a < m.end() and m.start() < b for a, b in anaphor_spans):
            continue                              # 대용표현 안에서 이름을 줍지 않는다
        cand = _trim_particles(m.group(0).strip())
        if not cand or BARE_SUFFIX_ONLY_RE.match(_squeeze(cand)):
            continue
        if _matches_anaphor(cand, anchor_suffix) and m.start() > best[0]:
            best = (m.start(), cand)

    # 앞서 **해소된** 이름도 후보다 — `같은 법 시행규칙` 다음의 `같은 규칙` 은
    # 본문에 `은행법 시행규칙` 이라고 적혀 있지 않지만 그걸 가리킨다.
    floor = breaks[-1].end() if breaks else 0
    for pos, title in resolved_before:
        if pos >= floor and _matches_anaphor(title, anchor_suffix) and pos - floor > best[0]:
            best = (pos - floor, title)

    if not best[1]:
        return ""
    tail = _anaphor_tail(anaphor_text)
    return f"{best[1]} {tail}" if tail else best[1]


def _expand_abbreviation(candidate: str, abbreviations: Mapping[str, str]) -> str:
    """
    공식 약칭 → 정식 문서명. `신용정보법` → `신용정보의 이용 및 보호에 관한 법률`,
    `신용정보법 시행령` → 그 시행령. 못 찾으면 빈 문자열.
    """
    if not candidate or not abbreviations:
        return ""
    key = _squeeze(candidate)
    if key in abbreviations:
        return abbreviations[key]
    for suffix in ("시행령", "시행규칙"):
        if key.endswith(suffix) and key[:-len(suffix)] in abbreviations:
            return f"{abbreviations[key[:-len(suffix)]]} {suffix}"
    return ""


def _narrow_title(raw_candidate: str, trimmed: str,
                  known_doc_titles, abbreviations: Optional[Mapping[str, str]] = None) -> str:
    """
    후보를 보유 문서명으로 **정확 일치**시킨다.

    **자르기 전 후보를 먼저 대조한다.** `여신 및 채권관리규정` 이 보유 목록에 있으면
    `채권관리규정` 으로 잘린 쪽을 쓰면 안 된다 — 다른 규정의 조문이 붙는다
    (2026-09-23 Reviewer 2차 실검출).
    그다음 **정당한 절삭점마다**(`_cut_points` — 문장 꼬리에서만) 대조한다.
    `이에 따라 신용정보의 … 법률 시행령` 은 `따라` 뒤에서 잘라야 보유 문서와 맞는다.
    각 후보는 보유 문서명 → 공식 약칭 순으로 본다.

    접미사 좁히기(`공무원 인사규정` → `인사규정`)는 **하지 않는다** — 이름 조각에선 안 자른다.

    Args:
        known_doc_titles: 문서명 목록, 또는 `{공백 뺀 이름: 이름}` (호출마다 다시 만들지 않게)
        abbreviations: `{공백 뺀 약칭: 정식 문서명}` (`structure.official_abbreviations`)
    """
    known_map = known_doc_titles if isinstance(known_doc_titles, Mapping) \
        else {_squeeze(k): k for k in known_doc_titles if k}
    segments = raw_candidate.split()
    cands = [raw_candidate, *(" ".join(segments[c:]) for c in _cut_points(segments)), trimmed]
    for cand in cands:
        if not cand:
            continue
        if _squeeze(cand) in known_map:
            return known_map[_squeeze(cand)]
        full = _expand_abbreviation(cand, abbreviations or {})
        if full:
            return known_map.get(_squeeze(full), full)
    return trimmed or raw_candidate


#: 관계 동사 탐색은 **절 경계에서 끊는다**. 안 끊으면 다음 절의 동사를 가져온다 —
#: `제30조에 따르고, 제5조를 준용한다` 에서 제30조가 '준용' 으로 찍혔다 (2026-09-23).
CLAUSE_BREAK_RE = re.compile(r"[,.;\n]")


def _find_relation_after(text: str, pos: int) -> str:
    """참조 뒤 창 안에서 관계 동사를 찾는다. 못 찾으면 빈 문자열 — 추정하지 않는다."""
    window = text[pos:pos + RELATION_WINDOW]
    cut = CLAUSE_BREAK_RE.search(window)
    tail = window[:cut.start()] if cut else window
    for name, pattern in RELATION_RULES:
        if pattern.search(tail):
            return name
    return ""


def _unit_and_target(m: re.Match) -> Tuple[str, str, Dict[str, Optional[int]]]:
    g = m.groupdict()
    nums: Dict[str, Optional[int]] = {
        "article": None, "sub_article": None, "paragraph": None, "item": None,
        "article_prefix": None,
    }

    if g.get("article_hy") or g.get("article_hy_bare"):
        pre = _digits(g.get("h_pre") or g.get("hb_pre"))
        no = _digits(g.get("h_no") or g.get("hb_no"))
        sub = _digits(g.get("h_sub") or g.get("hb_sub"))
        nums["article_prefix"], nums["article"], nums["sub_article"] = pre, no, sub
        return "조", article_target(no, sub, pre), nums
    if g.get("article") or g.get("article_bare"):
        no = _digits(g.get("a_no") or g.get("ab_no"))
        sub = _digits(g.get("a_sub") or g.get("ab_sub"))
        nums["article"], nums["sub_article"] = no, sub
        return "조", article_target(no, sub), nums
    if g.get("para"):
        nums["paragraph"] = _digits(g["p_no"])
        return "항", f"{pad3(nums['paragraph'])}항", nums
    if g.get("item"):
        nums["item"] = _digits(g["i_no"])
        return "호", f"{pad3(nums['item'])}호", nums
    if g.get("subitem"):
        return "목", f"{g['s_ch']}목", nums
    if g.get("chapter"):
        return "장", f"{pad3(_digits(g['c_no']))}장", nums
    if g.get("section"):
        return "절", f"{pad3(_digits(g['sc_no']))}절", nums
    if g.get("subsection"):
        return "관", f"{pad3(_digits(g['ss_no']))}관", nums
    if g.get("form_no"):
        return "서식", f"별지{pad3(_digits(g['f_no']))}호서식", nums
    if g.get("form"):
        return "서식", f"서식{pad3(_digits(g['fo_no']))}", nums
    if g.get("table"):
        parts = [pad3(int(p)) for p in re.sub(r"\s+", "", g["t_no"]).split("-")]
        sub = f"의{pad3(_digits(g['t_sub']))}" if g.get("t_sub") else ""
        return "별표", "별표" + "-".join(parts) + sub, nums
    if g.get("attach"):
        return "별첨", f"별첨{pad3(_digits(g['at_no']))}", nums
    if g.get("addendum"):
        return "부칙", "부칙", nums
    raise AssertionError(f"분류되지 않은 매치: {m.group(0)!r}")


# ── 공개 API ────────────────────────────────────────────────────────────────

def _leaf_heading_spans(norm: str, leaf_header: str) -> List[Tuple[int, int]]:
    """
    본문 첫 줄이 인덱서가 붙인 자기 헤더면, 그 줄 **맨 앞의** 위치 토큰(들) 구간.

    맨 앞만 본다 — 헤더 안의 다른 인용은 살린다:
      `[별표 4] 계정과목별 회계처리기준 (제4-1조관련)` → `별표 4` 는 자기, `제4-1조` 는 인용.
    """
    leaf = (leaf_header or "").strip()
    if not leaf:
        return []
    lh = normalize_for_match(leaf)
    if not norm.startswith(lh):
        return []
    spans: List[Tuple[int, int]] = []
    pos = LEAD_PREFIX_RE.match(norm, 0, len(lh)).end()
    while pos < len(lh):
        m = LOC_RE.match(norm, pos, len(lh))
        if not m:
            break
        spans.append((m.start(), m.end()))
        pos = LEAD_SEP_RE.match(norm, m.end(), len(lh)).end()
    return spans


# ── 문서 제목 목록 ──────────────────────────────────────────────────────────
#
# 글 모양(뒤에 조사가 붙나)으로 제목을 **추측**하기 전에, 그 문서의 **진짜 제목**과 대조한다.
# 진짜 제목 = 문서의 포인트 전부의 `header_path` 조각 (`structure.heading_index`).
# 목차는 진짜 제목을 그대로 옮겨 적은 것이라 여기서 잡힌다 (사용자 제안, 2026-09-28).

#: 제목 대조에서 무시하는 글자 — 공백과 대괄호류. 헤더와 본문의 띄어쓰기·괄호 표기가 달라도 맞춘다.
_HEADING_SKIP = frozenset(" \t[]<>【】〈〉《》〔〕［］")
#: 제목 뒤에 이게 **붙으면** 인용이다 (`제2장 여신 심사에 따른`). 조사 뒤가 또 한글이면 조사가 아니라
#: 낱말이다 — 제목 `제2장 여신` 과 `제2장 여신이자율` 의 `이` 를 조사로 보면 인용으로 **확정**해 버린다.
_HEADING_ATTACHED_CITE_RE = re.compile(
    r"(?:에서의|에서|에게|에는|에도|에의|으로|로서|로써|부터|까지|과의|와의|[의에을를은는이가과와도만로])"
    r"(?![가-힣])")
#: 제목 뒤에 이게 **띄어서** 오면 인용이다 (`제2장 여신 심사 및 제3장`).
_HEADING_SPACED_CITE_RE = re.compile(r"[ \t]*(?:및|또는|그리고|내지|부터|까지|참조|참고|[·,~～])")


def heading_text_key(text: str) -> str:
    """제목 대조 키 — 줄 머리 기호를 떼고 공백·대괄호를 뺀다. `[별표 4] 계정…` → `별표4계정…`."""
    norm = normalize_for_match(text or "")
    body = norm[LEAD_PREFIX_RE.match(norm).end():]
    return "".join(c for c in body if c not in _HEADING_SKIP and c != "\n")


def heading_key(text: str) -> str:
    """제목의 맨 앞 위치 토큰 → 찾기 키 (`012조`·`002장`·`별표004`·`부칙`). 위치 토큰으로 안 시작하면 빈 값."""
    norm = normalize_for_match(text or "")
    m = LOC_RE.match(norm, LEAD_PREFIX_RE.match(norm).end())
    return _unit_and_target(m)[1] if m else ""


def _match_heading(text: str, start: int, key: str) -> int:
    """`text[start:]` 가 공백·대괄호를 무시하고 `key` 로 시작하면 원문에서 끝 위치, 아니면 -1."""
    i, j, n = start, 0, len(text)
    while j < len(key):
        if i >= n or text[i] == "\n":
            return -1
        if text[i] in _HEADING_SKIP:
            i += 1
            continue
        if text[i] != key[j]:
            return -1
        i, j = i + 1, j + 1
    return i


#: 제목 **뒤에 와도 되는 것** — 줄 끝, 목차 점선, 쪽수, 괄호 주석(`(제1조~제3조)`·`<개정 …>`).
#: 다른 낱말이 오면 문장일 수 있다 → 판단을 추측 규칙에 넘긴다.
_HEADING_TAIL_OK_RE = re.compile(r"[ \t]*(?:$|[(（<〈\[]|[.·…‥∙ㆍ\-_=]{2,}|\d{1,4}[ \t]*$)", re.MULTILINE)

HEADING_STATE_HEADING = "heading"
HEADING_STATE_CITE = "cite"


def _heading_state(norm: str, m: re.Match, target: str,
                   known_headings: Mapping[str, Sequence[str]]) -> str:
    """
    줄 머리의 위치 토큰에서 시작하는 글을 **이 문서의 진짜 제목**과 대조한다. **긴 제목부터.**

    · `heading` — 제목과 같고 뒤에 줄 끝·점선·쪽수·괄호 주석만 온다 (목차·본문 속 제목)
    · `cite`    — 제목과 같은데 뒤에 조사·연결어가 붙는다 (`제2장 여신 심사에 따른`).
                  구조가 번호·제목이 진짜임을 보증하므로 **인용으로 확정**한다
    · ``        — 대조 안 됨. 글 모양 규칙이 판단한다

    짧은 제목이 긴 글의 앞부분만 맞는 경우(`제2장 여신` ↔ `제2장 여신 심사에 따른`)를 막으려고
    **긴 제목부터** 보고, 처음 맞은 제목으로 판단을 끝낸다. 뒤에 글자가 이어 붙으면(`여신심사기준`)
    제목 뒤에 와도 되는 것이 아니므로 판단을 추측 규칙에 넘긴다.
    """
    heads = known_headings.get(target) if known_headings else None
    if not heads:
        return ""
    line_start = norm.rfind("\n", 0, m.start()) + 1
    if LEAD_PREFIX_RE.match(norm, line_start, m.start()).end() != m.start():
        return ""                                      # 줄 머리(`#`·`-`·`1.` 뒤)에서만 — 문장 중간은 추측 규칙
    for key in sorted(heads, key=len, reverse=True):
        end = _match_heading(norm, m.start(), key)
        if end < 0:
            continue
        if _HEADING_ATTACHED_CITE_RE.match(norm, end) or _HEADING_SPACED_CITE_RE.match(norm, end):
            return HEADING_STATE_CITE
        return HEADING_STATE_HEADING if _HEADING_TAIL_OK_RE.match(norm, end) else ""
    return ""


def _is_bracketed_heading(norm: str, m: re.Match) -> bool:
    """`[별표 4] 계정과목별 …` 은 머리글, `[별표 1]과 같다` 는 인용."""
    if not norm[:m.start()].rstrip(" \t").endswith(_APPENDIX_OPEN):
        return False
    close = APPENDIX_CLOSE_RE.match(norm, m.end())
    if not close:
        return False
    return not APPENDIX_CITE_TAIL_RE.match(norm, close.end())


def _follows_addendum(norm: str, matches: Sequence[re.Match], idx: int) -> bool:
    """
    `부칙 제2조` · `부칙(2020. 1. 1.) 제2조` · `부칙 <제123호> 제2조` 의 조문인가.

    바로 앞 토큰만 보면 안 된다 — 공포번호 `<제123호>` 가 호 토큰이라 사이에 낀다.
    가까운 앞 토큰 3개 안에서 `부칙` 을 찾고, 그 사이가 공백·괄호 하나뿐인지 본다.
    """
    m = matches[idx]
    for prev in reversed(matches[max(0, idx - 3):idx]):
        if prev.group("addendum"):
            return bool(ADDENDUM_GAP_RE.match(norm[prev.end():m.start()]))
    return False


def extract_refs(
    text: str,
    *,
    self_doc_title: str = "",
    known_doc_titles: Sequence[str] = (),
    skip_headings: bool = True,
    aliases: Optional[Mapping[str, str]] = None,
    leaf_header: str = "",
    abbreviations: Optional[Mapping[str, str]] = None,
    known_headings: Optional[Mapping[str, Sequence[str]]] = None,
) -> ExtractResult:
    """
    본문에서 조문 참조 **후보**를 뽑는다.

    Args:
        text: 조문 본문. **NFC 로 정규화되어 있어야 한다** (아니면 NormalizationError).
        self_doc_title: 이 본문이 속한 규정 이름. `이 규정` 같은 자기 지시를 푼다.
        known_doc_titles: **우리가 보유한 문서명 전체** (사내 규정 + 법령).
            후보를 정확 일치로 다듬는 데만 쓴다. **연결 여부를 정하지 않는다** —
            그 판단은 해소 단계가 실제 색인을 보고 한다.
        skip_headings: 머리글(`제12조(여신한도)`, 목차의 `제2장 총칙`, `[별표 4] …`)을 건너뛴다.
            안 건너뛰면 조문이 자기 자신·목차가 모든 장을 가리키는 엣지가 생긴다.
        aliases: 이 문서의 약칭표 (`build_aliases(...).table`). `법 제57조` 의 `법` 을 푼다.
            없으면 `법`·`영` 단독 표기는 **거부**된다 — 같은 문서로 떨어뜨리지 않는다.
        leaf_header: 인덱서가 본문 첫 줄에 붙인 자기 헤더 (`structure.leaf_header`).
            본문이 이걸로 시작하면 그 줄 맨 앞 위치 토큰은 **자기 이름표**라 인용이 아니다.
        abbreviations: 문서가 **스스로 선언한** 공식 약칭 → 정식 문서명
            (`structure.official_abbreviations`, 제목줄의 `(약칭: 신용정보법)`).
        known_headings: **이 문서의** 진짜 제목 목록 `{맨 앞 토큰 키: [제목 대조 키, …]}`
            (`structure.heading_index`). 줄 머리 글이 여기 있는 제목과 같으면 제목이다.
            글 모양 규칙보다 **먼저** 본다 — 추측이 아니라 대조다.

    Returns:
        ExtractResult(refs=[...], rejected=[...])

    Raises:
        NormalizationError: 오프셋을 지키며 정규화할 수 없는 입력.
    """
    if not text:
        return ExtractResult()

    norm = normalize_for_match(text)
    result = ExtractResult()
    aliases = aliases or {}
    # 후보마다 다시 만들지 않는다. 실행기는 조각마다 같은 걸 넘기므로 미리 만든 맵도 받는다
    known_map = known_doc_titles if isinstance(known_doc_titles, Mapping) \
        else {_squeeze(k): k for k in known_doc_titles if k}
    # 정식 이름 복원표: 공식 약칭 위에 **이 문서의** 약칭 정의를 덮는다 (문서 자기 정의가 우선).
    # `같은 법 시행령` 이 `(이하 '금융실명법')` 을 물어오면 `금융실명법 시행령` 이 되는데,
    # 이걸 정식 이름으로 되돌려야 보유 문서와 맞는다.
    abbr_map = {**{_squeeze(k): v for k, v in (abbreviations or {}).items()},
                **{_squeeze(k): v for k, v in aliases.items()}}

    heading_spans = [(m.start(), m.end()) for m in HEADING_RE.finditer(norm)] if skip_headings else []
    lead_spans = _leaf_heading_spans(norm, leaf_header) if skip_headings else []

    def in_spans(spans: List[Tuple[int, int]], pos: int) -> bool:
        return any(s <= pos < e for s, e in spans)

    def reject(start: int, end: int, reason: str) -> None:
        # 조용히 넘기지 않는다 — 버린 것을 안 세면 재현율을 영영 못 잰다
        result.rejected.append(Rejected(raw=text[start:end], start=start, end=end, reason=reason))

    def mark_toc_paren(m: re.Match) -> None:
        """제목 줄 `제1장 총칙(제1조~제3조)` 의 괄호 범위는 목차 주석이다 — 같은 줄 첫 괄호만."""
        line_end = norm.find("\n", m.end())
        line_end = len(norm) if line_end < 0 else line_end
        paren = TOC_PAREN_RE.search(norm, m.end(), line_end)
        if paren and not LOC_RE.search(norm, m.end(), paren.start()):
            toc_spans.append((paren.start(), paren.end()))

    matches = list(LOC_RE.finditer(norm))
    consumed_until = -1
    claimed: List[Tuple[int, int]] = []
    resolved_titles: List[Tuple[int, str]] = []
    toc_spans: List[Tuple[int, int]] = []
    # 약칭 모름·대용표현 못 찾음·부칙 조문으로 거부된 머리에 **나열·범위로 이어진 꼬리**는 같은
    # 사유를 물려받는다. 안 물려받으면 꼬리가 문서명 없음 = **같은 문서**가 된다 (Reviewer 2차 F3:
    # `영 제3조부터 제5조까지` 의 제5조가 자기 문서로, `부칙 제2조 및 제3조` 의 제3조가 본칙으로).
    blocked: Optional[Tuple[int, str]] = None     # (거부된 머리의 끝, 사유)

    for idx, m in enumerate(matches):
        if m.start() < consumed_until:
            continue
        if in_spans(lead_spans, m.start()):
            reject(m.start(), m.end(), REJECT_LEAF_HEADING)
            continue
        if in_spans(heading_spans, m.start()):
            reject(m.start(), m.end(), REJECT_HEADING)
            continue
        if in_spans(toc_spans, m.start()):
            reject(m.start(), m.end(), REJECT_TOC_RANGE)
            continue

        unit, target, nums = _unit_and_target(m)

        state = _heading_state(norm, m, target, known_headings) \
            if (skip_headings and known_headings) else ""
        if state == HEADING_STATE_HEADING:
            reject(m.start(), m.end(), REJECT_KNOWN_HEADING)
            if unit in ("장", "절", "관"):
                mark_toc_paren(m)
            continue
        if skip_headings and unit in ("장", "절", "관") and state != HEADING_STATE_CITE \
                and not UNIT_CITE_TAIL_RE.match(norm, m.end()):
            reject(m.start(), m.end(), REJECT_UNIT_HEADING)
            mark_toc_paren(m)                                     # `총칙(제1조~제3조)`
            continue
        if skip_headings and unit in ("별표", "서식", "별첨") and state != HEADING_STATE_CITE \
                and _is_bracketed_heading(norm, m):
            reject(m.start(), m.end(), REJECT_APPENDIX_HEADING)
            continue
        if skip_headings and unit == "부칙" \
                and re.fullmatch(r"[ \t#>*\-•·|]*", norm[norm.rfind("\n", 0, m.start()) + 1:m.start()]) \
                and ADDENDUM_LINE_TAIL_RE.match(norm, m.end()):
            reject(m.start(), m.end(), REJECT_ADDENDUM_HEADING)
            continue
        if unit == "조" and _follows_addendum(norm, matches, idx):
            reject(m.start(), m.end(), REJECT_ADDENDUM_ARTICLE)
            blocked = (m.end(), REJECT_ADDENDUM_ARTICLE)
            continue

        (title_raw, title), title_start, source, aux = _find_title_before(norm, m.start(), aliases)

        if blocked is not None:
            gap = norm[blocked[0]:m.start()]
            if source == TITLE_NONE and (LIST_GAP_RE.fullmatch(gap) or RANGE_SEP_RE.fullmatch(gap)):
                reject(m.start(), m.end(), f"{blocked[1]} ← 앞 참조에 이어짐")
                blocked = (m.end(), blocked[1])
                continue
            blocked = None

        # `제` 없는 맨 `N조` 는 **문서명이 붙었을 때만** 조문으로 본다.
        #
        # 사고 이력 (2026-09-23 Reviewer 2차): `1조원` 은 뒤 단위로 걸렀지만
        # `1조 5천억원`·`총자산이 2조에 달하는` 은 안 걸렸다. 금액과 조문을
        # 뒷글자만으로 가르는 건 불가능하다. 한국 법령 작성 관례상 조문 인용은
        # 거의 항상 `제N조` 이므로 `제` 가 없으면 문서명을 요구한다 —
        # **정밀도 쪽으로 기운다.**
        g = m.groupdict()
        if (g.get("article_bare") or g.get("article_hy_bare")) and not title:
            reject(m.start(), m.end(), REJECT_BARE_ARTICLE)
            continue

        if source == _ALIAS_UNKNOWN:
            # `법 제57조` 인데 `법` 이 뭔지 모른다. 같은 문서로 떨어뜨리면 **틀린 엣지**가 된다.
            reason = f"{REJECT_ALIAS}('{aux}')"
            reject(title_start, m.end(), reason)
            blocked = (m.end(), reason)
            continue
        if source == TITLE_INHERITED:
            resolved = _resolve_anaphora(norm, title_start, title, aux, resolved_titles)
            if not resolved:
                reason = f"대용표현('{title}')이 가리킬 같은 계열 문서명을 문단 안에서 못 찾음"
                reject(title_start, m.end(), reason)
                blocked = (m.end(), reason)
                continue
            title = resolved
        elif source == TITLE_SELF:
            title = self_doc_title           # 비어 있으면 '' = 같은 문서. 정상
            if not title:
                source = TITLE_NONE

        title = _narrow_title(title_raw if source == TITLE_EXPLICIT else title,
                              title, known_map, abbr_map)

        kind, range_end, end_pos = KIND_ABSOLUTE, None, m.end()
        if idx + 1 < len(matches):
            nxt = matches[idx + 1]
            if RANGE_SEP_RE.fullmatch(norm[m.end():nxt.start()]):
                nxt_unit, nxt_target, _ = _unit_and_target(nxt)
                if nxt_unit == unit:
                    kind, range_end, end_pos = KIND_RANGE, nxt_target, nxt.end()
                    tail = RANGE_TAIL_RE.match(norm[end_pos:])
                    if tail:
                        end_pos += tail.end()
                    consumed_until = nxt.end()

        # 증거 span: 문서명을 포함하되 **앞 후보와 겹치지 않는 선까지만**
        start_pos = m.start()
        if title_start >= 0:
            floor = max((e for _s, e in claimed), default=0)
            start_pos = max(title_start, floor)
            if start_pos >= m.start():
                start_pos = m.start()

        claimed.append((start_pos, end_pos))
        if title:
            resolved_titles.append((m.start(), title))
        result.refs.append(ClauseRef(
            raw=text[start_pos:end_pos], start=start_pos, end=end_pos,
            unit=unit, target=target, doc_title=title, title_source=source,
            kind=kind, article=nums["article"], sub_article=nums["sub_article"],
            paragraph=nums["paragraph"], item=nums["item"],
            relation=_find_relation_after(norm, end_pos), range_end=range_end,
            article_prefix=nums["article_prefix"],
        ))

    contexts = [(h.start(), article_target(int(h.group("no")),
                                           int(h.group("sub")) if h.group("sub") else None,
                                           int(h.group("pre")) if h.group("pre") else None))
                for h in ARTICLE_CONTEXT_RE.finditer(norm)]

    def context_at(pos: int) -> str:
        """`pos` 앞의 가장 가까운 조문 머리글. 없으면 빈 값 — 조각 이름표로 푼다."""
        before = [t for s, t in contexts if s < pos]
        return before[-1] if before else ""

    for m in RELATIVE_RE.finditer(norm):
        if in_spans(heading_spans, m.start()) or in_spans(lead_spans, m.start()):
            continue
        if any(s <= m.start() < e and e - s <= len(m.group(0)) + 2 for s, e in claimed):
            continue
        if any(r.start <= m.start() and m.end() <= r.end and r.kind != KIND_RELATIVE
               and r.raw.strip().startswith(m.group(0)) for r in result.refs):
            continue
        result.refs.append(ClauseRef(
            raw=text[m.start():m.end()], start=m.start(), end=m.end(),
            unit="조" if "조" in m.group(0) else ("항" if "항" in m.group(0) else "호"),
            target="", kind=KIND_RELATIVE,
            relation=_find_relation_after(norm, m.end()),
            context_article=context_at(m.start()),
        ))

    result.refs.sort(key=lambda r: (r.start, r.end))
    result.refs = _propagate_titles(result.refs, norm)
    return result


def _propagate_titles(refs: List[ClauseRef], text: str) -> List[ClauseRef]:
    """
    문서명이 안 적힌 나열·복합 참조에 **앞 참조의 문서명**을 물려준다.

    이음매(`및`, `·`, 공백)만 사이에 있을 때만 물려준다 —
    `제30조에 따르고, 제5조를 준용한다` 처럼 다른 말이 끼면 물려주지 않는다.
    """
    from dataclasses import replace as _replace

    out: List[ClauseRef] = []
    for ref in refs:
        if (ref.title_source == TITLE_NONE and ref.kind != KIND_RELATIVE and out):
            prev = out[-1]
            if prev.doc_title and LIST_GAP_RE.fullmatch(text[prev.end:ref.start]):
                ref = _replace(ref, doc_title=prev.doc_title,
                               title_source=TITLE_PROPAGATED)
        out.append(ref)
    return out


def expand_ranges(refs: Sequence[ClauseRef]) -> List[ClauseRef]:
    """
    `kind='range'` 후보를 개별 항목으로 편다. 조·항·호 전부 지원한다.

    안 펴는 경우 (원형을 그대로 남긴다):
      · 끝 번호 < 시작 번호
      · 100개 초과
      · 끝 target 에서 번호를 못 읽음
      · 하이픈 조문의 장 번호가 다름 (`제7-9조부터 제8-2조까지` — 사이 조문 수를 모른다)
    """
    unit_field = {"조": "article", "항": "paragraph", "호": "item"}
    out: List[ClauseRef] = []
    for r in refs:
        if r.kind != KIND_RANGE or r.unit not in unit_field:
            out.append(r)
            continue
        end = _RANGE_END_RE.match(r.range_end or "")
        start_no = getattr(r, unit_field[r.unit], None)
        if start_no is None or not end or end.group("unit") != r.unit:
            out.append(r)
            continue

        end_pre = int(end.group("pre")) if end.group("pre") else None
        if end_pre != r.article_prefix:
            out.append(r)
            continue

        end_main, end_sub = int(end.group("main")), end.group("sub")
        # 가지조문 범위(`제3조의2부터 제3조의5까지`)는 **가지 번호**를 편다.
        # 본조 번호만 보면 `003조` 하나로 접혀 회귀 테스트를 우회한다
        # (2026-09-23 Reviewer 2차 실검출).
        if r.sub_article is not None:
            if end_sub is None or end_main != r.article:
                out.append(r)
                continue
            lo, hi, is_sub = r.sub_article, int(end_sub), True
        else:
            if end_sub is not None:
                out.append(r)                      # 본조 → 가지조문 범위는 안 편다
                continue
            lo, hi, is_sub = start_no, end_main, False

        if hi < lo or hi - lo > 100:
            out.append(r)
            continue
        for n in range(lo, hi + 1):
            if is_sub:
                target = article_target(r.article, n, r.article_prefix)
                fields = {"article": r.article, "sub_article": n}
            elif r.unit == "조":
                target = article_target(n, None, r.article_prefix)
                fields = {"article": n}
            else:
                target = f"{pad3(n)}{r.unit}"
                fields = {unit_field[r.unit]: n}
            out.append(ClauseRef(
                raw=r.raw, start=r.start, end=r.end, unit=r.unit,
                target=target, kind=KIND_ABSOLUTE,
                doc_title=r.doc_title, title_source=r.title_source,
                relation=r.relation, article_prefix=r.article_prefix, **fields,
            ))
    return out


# ── 약칭 ────────────────────────────────────────────────────────────────────

#: `산업안전보건법 시행령` → 모법 `산업안전보건법`. `$` 앵커가 `헌법재판소법` 같은 이름을 지킨다.
ENFORCEMENT_TITLE_RE = re.compile(r"^(?P<base>.+?(?:법률|법))\s*(?:시행령|시행규칙)$")
#: `X 시행세칙` 의 모문서 X — 시행세칙은 모문서를 끝말(`규정`·`협약`)로 부른다.
#: 사고 이력 (2026-09-28 내부 6회차 표본 19): `신용회복지원협약 시행세칙 개정전문` 의 `협약 제44조` 가
#: 시행세칙 **자기** 제44조로 붙었다. 시행령의 `법` 과 같은 종류인데 규칙이 시행령·시행규칙에만 있었다.
BYLAW_TITLE_RE = re.compile(rf"^(?P<base>.+?(?P<suf>{DOC_SUFFIX}))\s*시행세칙(?:\s.*)?$")

#: 문서 안 약칭 정의. **범위가 붙은 정의**(`이하 이 조에서 "X"라 한다`)는 문서 전체 약칭이 아니다.
#:   법령     `「상호저축은행법」(이하 "법"이라 한다)` · `같은 법 시행령(이하 "영"이라 한다)`
#:   대법원규칙 `민사집행법(다음부터 "법"이라 한다)`
#:   해설·안내 `(이하 "금융실명법"이라 함)` · `(이하 '법')` — 따옴표만 있고 동사가 없는 꼴
#: 사고 이력 (2026-09-28 내부 5회차): `이하` 만 읽어 `민사집행규칙`(347건)·`민사소송규칙`(133건)의
#: `법 제N조` 를 전부 못 풀었다. 대법원규칙은 `다음부터` 로 정의한다.
_DEF_VERB = r"(?:이?라\s*(?:고\s*)?)(?:한다|함|하며|하고|칭한다|칭함|부른다)"
DEFINITION_RE = re.compile(
    r"[(（]\s*(?:이하|다음부터)\s*(?P<scope>[^\"“'‘()（）\n]{0,15}?에서\s*)?"
    r"(?:[\"“'‘]\s*(?P<q>[가-힣A-Za-z0-9·]{1,20}?)\s*[\"”'’]\s*(?:" + _DEF_VERB + r")?"
    r"|(?P<bare>[가-힣A-Za-z0-9·]{1,20}?)\s*" + _DEF_VERB + r")"
    r"\s*(?:[,，][^)）\n]{0,40})?[)）]")
#: 정의된 **대상**이 문서명인가 — 이걸로 거른다. `신용정보회사(이하 "회사")` 는 문서가 아니다.
#: 약칭 쪽 모양으로 거르지 않는다: `(이하 "특금")` 처럼 접미사 없는 문서 약칭도 있다.
_ENDS_WITH_SUFFIX_RE = re.compile(rf"{DOC_SUFFIX}$")


def default_aliases(doc_title: str) -> Dict[str, str]:
    """
    **제목만으로** 아는 약칭. 법령 입안 관례상 시행령·시행규칙은 모법을 `법`,
    시행령을 `영` 으로 부른다. 제목 뒤 괄호(`(대통령령)(제12345호)`)는 뗀다.

    >>> default_aliases("산업안전보건법 시행령")
    {'법': '산업안전보건법', '영': '산업안전보건법 시행령'}
    >>> default_aliases("여신규정")
    {}
    """
    title = re.sub(r"\s*[(（\[].*$", "", (doc_title or "").strip()).strip()
    m = ENFORCEMENT_TITLE_RE.match(title)
    if m:
        base = m.group("base").strip()
        return {"법": base, "영": f"{base} 시행령"}
    m = BYLAW_TITLE_RE.match(title)
    if m:
        return {m.group("suf"): m.group("base").strip()}
    return {}


def _defined_title(norm: str, pos: int, self_doc_title: str) -> str:
    """정의 괄호 바로 앞의 문서명. 못 찾으면 빈 문자열 — 추측하지 않는다."""
    window_start = max(0, pos - TITLE_LOOKBACK * 2)
    window = norm[window_start:pos]
    if SELF_TAIL_RE.search(window):
        return self_doc_title
    m = ANAPHOR_TAIL_RE.search(window)
    if m:
        return _resolve_anaphora(norm, window_start + m.start(), m.group(1).strip(),
                                 m.group("anchor"))
    m = BRACKET_TAIL_RE.search(window)
    if m:
        return m.group(1).strip()
    m = BARE_TAIL_RE.search(window)
    if m:
        # 정의 대상은 접속사로 시작하지 않는다 — `…특별법(이하 "법") 및 법 시행령(이하 "시행령")` 에서
        # `및 법 시행령` 을 이름으로 읽어 올바른 정의와 **충돌**, `시행령` 약칭이 통째로 버려졌다
        # (2026-09-28 내부 6회차 "약칭 충돌" 줄, 거부 106건). `법 시행령` 은 약칭표가 푼다.
        tokens = _trim_particles(m.group(1).strip()).split()
        while tokens and CONNECTOR_RE.match(tokens[0]):
            tokens = tokens[1:]
        trimmed = " ".join(tokens)
        if trimmed and not BARE_SUFFIX_ONLY_RE.match(_squeeze(trimmed)):
            return trimmed
    return ""


def extract_definitions(text: str, *, self_doc_title: str = "") -> List[Tuple[str, str]]:
    """
    본문의 약칭 정의 `(이하 "X"라 한다)` → `[(약칭, 문서명), …]`.

    정의된 대상이 **문서명**일 때만 받는다(`「A법」`, `같은 법 시행령`, `이 규정`).
    범위 붙은 정의(`이하 이 조에서`)는 버린다.

    Raises:
        NormalizationError: `normalize_for_match` 와 같다.
    """
    if not text:
        return []
    norm = normalize_for_match(text)
    out: List[Tuple[str, str]] = []
    for m in DEFINITION_RE.finditer(norm):
        if m.group("scope"):
            continue
        alias = _squeeze(m.group("q") or m.group("bare") or "")
        if not alias:
            continue
        title = _defined_title(norm, m.start(), self_doc_title)
        if not title:
            continue
        if _squeeze(title) != _squeeze(self_doc_title) \
                and not _ENDS_WITH_SUFFIX_RE.search(_squeeze(title)):
            continue
        out.append((alias, title))
    return out


@dataclass
class AliasTable:
    """한 문서의 약칭표. **충돌한 약칭은 표에서 뺀다** — 둘 중 고르지 않는다."""

    table: Dict[str, str] = field(default_factory=dict)
    from_title: int = 0            # 제목(시행령·시행규칙)에서 온 것
    from_definition: int = 0       # 본문 정의에서 온 것
    conflicts: List[str] = field(default_factory=list)
    conflict_titles: Dict[str, List[str]] = field(default_factory=dict)   # 약칭 → 서로 다른 정의들
    skipped_texts: int = 0         # 정규화 실패로 못 읽은 본문 — 0 이 아니면 정의를 놓쳤을 수 있다


def build_aliases(doc_title: str, texts: Iterable[str]) -> AliasTable:
    """
    문서 하나의 약칭표. 정의는 보통 제1조·제2조에 있고 조각이 다르므로 **문서 전체**를 읽는다.

    우선순위: 본문 정의 > 제목. 같은 약칭이 서로 다른 문서로 정의되면 **표에서 뺀다** —
    그 약칭 인용은 거부된다(틀린 쪽을 고르는 것보다 낫다).

    `법` 을 알면 맨 `시행령`·`시행규칙` 도 안다 — 감독규정이 `법 제25조의9 및 시행령 제24조`
    처럼 쓴다. 이걸 모르면 `시행령 제24조` 가 **감독규정 자기 제24조**로 붙었다 (2026-09-28 5회차).
    """
    out = AliasTable()
    defaults = default_aliases(doc_title)
    found: Dict[str, Dict[str, str]] = {}
    for text in texts:
        try:
            pairs = extract_definitions(text, self_doc_title=doc_title)
        except NormalizationError:
            out.skipped_texts += 1
            continue
        for alias, title in pairs:
            found.setdefault(alias, {})[_squeeze(title)] = title
    # 정의 값에 적힌 약칭(`법 시행령`)을 **충돌을 보기 전에** 푼다. 안 풀면 같은 문서를 가리키는
    # 두 정의(`법 시행령` / `…특별법 시행령`)가 다른 값으로 보여 충돌로 버려진다 (2026-09-28 6회차).
    prelim = dict(defaults)
    prelim.update({a: next(iter(t.values())) for a, t in found.items() if len(t) == 1})
    for alias, titles in list(found.items()):
        others = {_squeeze(k): v for k, v in prelim.items() if k != alias}
        found[alias] = {}
        for title in titles.values():
            full = _expand_abbreviation(title, others) or title
            found[alias][_squeeze(full)] = full
    table = dict(defaults)
    for alias, titles in found.items():
        if len(titles) == 1:
            table[alias] = next(iter(titles.values()))
            out.from_definition += 1
        else:
            out.conflicts.append(alias)
            out.conflict_titles[alias] = sorted(titles.values())
            table.pop(alias, None)
    # 값이 다른 약칭을 가리키면 한 번 푼다 — `영` = `금융실명법 시행령` → `…법률 시행령`
    for alias, title in list(table.items()):
        others = {_squeeze(k): v for k, v in table.items() if k != alias}
        table[alias] = _expand_abbreviation(title, others) or title
    law = table.get("법")
    if law:
        # 충돌로 뺀 약칭은 되살리지 않는다 — 둘 중 고르지 않는다는 원칙
        for alias, value in (("시행령", table.get("영", f"{law} 시행령")), ("시행규칙", f"{law} 시행규칙")):
            if alias not in out.conflicts:
                table.setdefault(alias, value)
    out.from_title = sum(1 for k, v in table.items() if defaults.get(k) == v and k not in found)
    out.table = table
    return out


def audit(result: ExtractResult) -> Dict[str, object]:
    """
    추출 결과 요약. `rejected` 를 **맨 앞에** 세운다 — 0 이면 의심해야 한다.
    """
    by_unit: Dict[str, int] = {}
    by_relation: Dict[str, int] = {}
    by_source: Dict[str, int] = {}
    for r in result.refs:
        by_unit[r.unit] = by_unit.get(r.unit, 0) + 1
        by_relation[r.relation or "(없음)"] = by_relation.get(r.relation or "(없음)", 0) + 1
        by_source[r.title_source] = by_source.get(r.title_source, 0) + 1
    return {
        "total": len(result.refs),
        "rejected": len(result.rejected),
        "rejected_reasons": [x.reason for x in result.rejected],
        "named": sum(1 for r in result.refs if r.doc_title),
        "by_unit": by_unit,
        "by_relation": by_relation,
        "by_title_source": by_source,
        "relative": sum(1 for r in result.refs if r.kind == KIND_RELATIVE),
    }
