# -*- coding: utf-8 -*-
"""
graph_build/pg_store.py

**Postgres 정본** — 스키마와 적재 계획.

이름이 `pg_store` 인 이유: `tools/model_compare/store/` 패키지와 **모듈명이 겹치면**
`tests/conftest.py` 가 model_compare 를 먼저 `sys.path` 에 붙이므로 그쪽이 가려버린다
(2026-09-23 실검출 — `from store import DDL_ALL` 이 model_compare 의 `store` 를 집었다).

이 모듈은 **순수**하다. psycopg 를 import 하지 않는다 — SQL 문자열과 파라미터를 만들 뿐,
실행은 내부망 호출부가 한다. 그래야 여기서 계획 계산을 전부 테스트할 수 있다.

Postgres 가 하는 일은 셋뿐이다:
  ① 행을 넣는다
  ② 규정이 바뀌면 옛 행에 종료일을 찍는다 (**지우지 않는다**)
  ③ 기동 때 현행만 내준다

②가 이 모듈의 핵심이고, RDB 가 아니면 못 하는 일이다.
누적만 하면 **폐지된 조문이 현행처럼 검색된다.**
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

SCHEMA_VERSION = 1

#: 노드. `audience_keys` 는 배열 + GIN — 권한 필터가 이 위에서 돈다.
DDL_NODE = """
-- 노드 = Qdrant 조각(parent) 하나. `node_id` 가 곧 `parent_id` 다.
-- 조번호·장번호는 **이름표**라 개수가 0개일 수도 여러 개일 수도 있다 → 배열.
CREATE TABLE IF NOT EXISTS graph_node (
    node_id        TEXT PRIMARY KEY,
    doc_title      TEXT NOT NULL,
    labels         TEXT[] NOT NULL DEFAULT '{}',
    article_labels TEXT[] NOT NULL DEFAULT '{}',
    title          TEXT NOT NULL DEFAULT '',
    chunk_ids      TEXT[] NOT NULL DEFAULT '{}',
    category_id    TEXT NOT NULL DEFAULT '',
    main_category  TEXT NOT NULL DEFAULT '',
    audience_keys  TEXT[] NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS graph_node_audience_idx ON graph_node USING GIN (audience_keys);
CREATE INDEX IF NOT EXISTS graph_node_label_idx    ON graph_node USING GIN (labels);
"""

#: 엣지. `valid_to IS NULL` 이 현행이다.
#: `src`/`dst` 양방향 인덱스 — 역방향 질의("이 조문을 인용하는 것")가 공짜로 따라온다.
DDL_EDGE = """
CREATE TABLE IF NOT EXISTS graph_edge (
    edge_id          BIGSERIAL PRIMARY KEY,
    src              TEXT NOT NULL REFERENCES graph_node(node_id),
    dst              TEXT NOT NULL REFERENCES graph_node(node_id),
    rel              TEXT NOT NULL,
    subtype          TEXT NOT NULL DEFAULT '',
    raw_text         TEXT NOT NULL,
    src_offset_start INT  NOT NULL DEFAULT 0,
    src_offset_end   INT  NOT NULL DEFAULT 0,
    paragraph        INT,
    item             INT,
    mentions         INT  NOT NULL DEFAULT 1,
    extractor        TEXT NOT NULL,
    confidence       REAL NOT NULL,
    valid_from       DATE NOT NULL,
    valid_to         DATE,
    t_created        TIMESTAMPTZ NOT NULL DEFAULT now(),
    t_expired        TIMESTAMPTZ,
    CHECK (src <> dst),
    CHECK (raw_text <> '')
);
CREATE INDEX IF NOT EXISTS graph_edge_src_idx     ON graph_edge (src, rel) WHERE valid_to IS NULL;
CREATE INDEX IF NOT EXISTS graph_edge_dst_idx     ON graph_edge (dst, rel) WHERE valid_to IS NULL;
CREATE INDEX IF NOT EXISTS graph_edge_current_idx ON graph_edge (valid_to) WHERE valid_to IS NULL;
"""

#: 못 푼 참조. **버리지 않는다** — 재현율을 재려면 필요하다.
DDL_UNRESOLVED = """
CREATE TABLE IF NOT EXISTS graph_unresolved (
    id            BIGSERIAL PRIMARY KEY,
    src           TEXT NOT NULL,
    raw_text      TEXT NOT NULL,
    reason        TEXT NOT NULL,
    doc_title     TEXT NOT NULL DEFAULT '',
    target        TEXT NOT NULL DEFAULT '',
    offset_start  INT NOT NULL DEFAULT 0,
    offset_end    INT NOT NULL DEFAULT 0,
    seen_at       DATE NOT NULL
);
CREATE INDEX IF NOT EXISTS graph_unresolved_reason_idx ON graph_unresolved (reason);
"""

#: 사람이 볼 목록 — 정규식과 LLM 이 엇갈린 건.
DDL_REVIEW = """
CREATE TABLE IF NOT EXISTS graph_review (
    id         BIGSERIAL PRIMARY KEY,
    src        TEXT NOT NULL,
    dst        TEXT NOT NULL,
    raw_text   TEXT NOT NULL,
    reason     TEXT NOT NULL,
    seen_at    DATE NOT NULL,
    resolved   BOOLEAN NOT NULL DEFAULT FALSE
);
"""

DDL_ALL = (DDL_NODE, DDL_EDGE, DDL_UNRESOLVED, DDL_REVIEW)

#: 기동 시 현행 엣지만. 이 한 방이 메모리 그래프의 재료다.
SQL_LOAD_CURRENT_EDGES = """
SELECT src, dst, rel, subtype, confidence
  FROM graph_edge
 WHERE valid_to IS NULL
   AND valid_from <= %(as_of)s
"""

SQL_LOAD_NODES = """
SELECT node_id, doc_title, labels, title, node_id AS parent_id,
       category_id, main_category, audience_keys
  FROM graph_node
"""

#: 역방향 — "이 조문을 인용하는 것들". `graph_edge_dst_idx` 가 받쳐준다.
SQL_INBOUND = """
SELECT src, subtype, raw_text
  FROM graph_edge
 WHERE dst = %(node_id)s AND valid_to IS NULL
"""


@dataclass(frozen=True)
class ExistingEdge:
    """DB 에 이미 있는 현행 엣지 한 줄 (`valid_to IS NULL`)."""

    edge_id: int
    src: str
    dst: str
    rel: str
    subtype: str
    raw_text: str


@dataclass
class SyncPlan:
    """
    적재 계획. **지우는 항목이 없다** — 사라진 연결은 종료일을 찍을 뿐이다.
    """

    insert: List[object] = field(default_factory=list)          # ResolvedEdge
    supersede: List[Tuple[int, str]] = field(default_factory=list)  # (edge_id, 사유)
    unchanged: List[int] = field(default_factory=list)          # edge_id
    changed: List[Tuple[int, object]] = field(default_factory=list)  # (옛 edge_id, 새 edge)
    #: `scope_src` 밖에서 온 incoming. **버리지 않고 알린다** —
    #: 그냥 넣으면 기존 행과 중복되고, `graph_edge` 에 UNIQUE 제약이 없어 안 걸린다.
    out_of_scope: List[object] = field(default_factory=list)

    def summary(self) -> Dict[str, int]:
        return {
            "insert": len(self.insert),
            "supersede": len(self.supersede),
            "unchanged": len(self.unchanged),
            "changed": len(self.changed),
            "out_of_scope": len(self.out_of_scope),
        }


def _key(edge) -> Tuple[str, str, str, str]:
    return (edge.src, edge.dst, edge.rel, edge.subtype)


def plan_sync(
    existing: Sequence[ExistingEdge],
    incoming: Sequence,
    *,
    scope_src: Optional[Sequence[str]] = None,
) -> SyncPlan:
    """
    현행 DB 상태와 새로 뽑은 엣지를 비교해 **무엇을 넣고 무엇을 닫을지** 계산한다.

    Args:
        existing: DB 의 현행 엣지 (`valid_to IS NULL`)
        incoming: 이번에 새로 만든 `ResolvedEdge` 목록
        scope_src: 이번에 **다시 읽은 조문**의 node_id 목록.
            부분 재적재를 할 때 이 범위 밖의 기존 엣지는 건드리지 않는다.
            None 이면 `existing` 전체가 범위다.

    Returns:
        `SyncPlan`.

    왜 `scope_src` 가 필요한가:
      규정 하나만 다시 읽었는데 `existing` 전체와 비교하면, **안 읽은 규정의 엣지가
      전부 "사라진 것" 으로 보여 통째로 닫힌다.** 조용히 그래프가 비는 사고다.
    """
    in_scope = set(scope_src) if scope_src is not None else None

    plan = SyncPlan()

    # 같은 키가 DB 에 두 줄 이상 있을 수 있다 (UNIQUE 제약이 없다).
    # `setdefault` 로 하나만 잡으면 나머지가 **영원히 안 닫힌다** (2026-09-23 Reviewer 🟡).
    existing_map: Dict[Tuple[str, str, str, str], List[ExistingEdge]] = {}
    for e in existing:
        if in_scope is not None and e.src not in in_scope:
            continue                                   # 범위 밖 — 손대지 않는다
        existing_map.setdefault(_key(e), []).append(e)

    seen: set = set()
    for edge in incoming:
        if in_scope is not None and edge.src not in in_scope:
            plan.out_of_scope.append(edge)             # 조용히 중복 insert 하지 않는다
            continue
        key = _key(edge)
        seen.add(key)
        rows = existing_map.get(key) or []
        if not rows:
            plan.insert.append(edge)
            continue
        old, extras = rows[0], rows[1:]
        for dup in extras:                             # 중복 현행 행은 닫는다
            plan.supersede.append((dup.edge_id, "같은 키 중복 행"))
        if old.raw_text != edge.raw_text:
            plan.changed.append((old.edge_id, edge))   # 본문이 바뀌었다 = 새 판
        else:
            plan.unchanged.append(old.edge_id)

    for key, rows in existing_map.items():
        if key not in seen:
            for old in rows:
                plan.supersede.append((old.edge_id, "새 판에 없음"))
    return plan


def node_upsert_statement(node) -> Tuple[str, Dict[str, object]]:
    """`DocNode` → (SQL, 파라미터). 같은 (문서, 조문)이면 덮어쓴다."""
    sql = """
INSERT INTO graph_node (node_id, doc_title, labels, article_labels, title,
                        chunk_ids, category_id, main_category, audience_keys)
VALUES (%(node_id)s, %(doc_title)s, %(labels)s, %(article_labels)s, %(title)s,
        %(chunk_ids)s, %(category_id)s, %(main_category)s, %(audience_keys)s)
ON CONFLICT (node_id) DO UPDATE SET
    labels = EXCLUDED.labels, article_labels = EXCLUDED.article_labels,
    title = EXCLUDED.title, chunk_ids = EXCLUDED.chunk_ids,
    category_id = EXCLUDED.category_id, main_category = EXCLUDED.main_category,
    audience_keys = EXCLUDED.audience_keys
"""
    return sql, {
        "node_id": node.node_id, "doc_title": node.doc_title,
        "labels": list(node.labels), "article_labels": list(node.article_labels),
        "title": node.title, "chunk_ids": list(node.chunk_ids),
        "category_id": node.category_id, "main_category": node.main_category,
        "audience_keys": list(node.audience_keys),
    }


def edge_insert_statement(edge, *, valid_from: date) -> Tuple[str, Dict[str, object]]:
    """`ResolvedEdge` → (SQL, 파라미터)."""
    sql = """
INSERT INTO graph_edge (src, dst, rel, subtype, raw_text,
                        src_offset_start, src_offset_end, paragraph, item,
                        mentions, extractor, confidence, valid_from)
VALUES (%(src)s, %(dst)s, %(rel)s, %(subtype)s, %(raw_text)s,
        %(src_offset_start)s, %(src_offset_end)s, %(paragraph)s, %(item)s,
        %(mentions)s, %(extractor)s, %(confidence)s, %(valid_from)s)
"""
    return sql, {
        "src": edge.src, "dst": edge.dst, "rel": edge.rel, "subtype": edge.subtype,
        "raw_text": edge.raw_text,
        "src_offset_start": edge.src_offset_start, "src_offset_end": edge.src_offset_end,
        "paragraph": edge.paragraph, "item": edge.item,
        "mentions": getattr(edge, "mentions", 1), "extractor": edge.extractor, "confidence": edge.confidence,
        "valid_from": valid_from,
    }


def edge_supersede_statement(edge_ids: Sequence[int], *, valid_to: date
                             ) -> Tuple[str, Dict[str, object]]:
    """
    옛 엣지에 종료일을 찍는다. **DELETE 가 아니다** —
    "2024-01-01 부터 2026-03-01 까지는 유효했다" 가 남아야 시점 질의가 된다.
    """
    if not edge_ids:
        raise ValueError("닫을 엣지가 없다 — 빈 UPDATE 를 보내지 않는다")
    sql = """
UPDATE graph_edge
   SET valid_to = %(valid_to)s, t_expired = now()
 WHERE edge_id = ANY(%(edge_ids)s) AND valid_to IS NULL
"""
    return sql, {"valid_to": valid_to, "edge_ids": list(edge_ids)}


def unresolved_insert_statement(item, *, seen_at: date) -> Tuple[str, Dict[str, object]]:
    sql = """
INSERT INTO graph_unresolved (src, raw_text, reason, doc_title, target,
                              offset_start, offset_end, seen_at)
VALUES (%(src)s, %(raw_text)s, %(reason)s, %(doc_title)s, %(target)s,
        %(offset_start)s, %(offset_end)s, %(seen_at)s)
"""
    return sql, {
        "src": item.src, "raw_text": item.raw_text, "reason": item.reason,
        "doc_title": item.doc_title, "target": item.target,
        "offset_start": item.offset_start, "offset_end": item.offset_end,
        "seen_at": seen_at,
    }
