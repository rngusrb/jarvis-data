SBI 조문 그래프 — 내부망 실행법

1. 이 폴더를 rag_langchain 안에 하위 폴더로 풀고, 그 안에서 실행한다.
   (.env 를 위로 거슬러 찾는다 — QDRANT_URL, PARENTS_COLLECTION_NAME,
    --verify 는 OPENAI_BASE_URL, MODEL_NAME 도)
   Windows 는 python3 대신 python.

2. 챗봇에서 그래프가 하는 일 보기 (데모):
     python3 run_on_qdrant.py --demo                          예시 3개를 스스로 고른다
     python3 run_on_qdrant.py --demo "여신규정 제5조"          그 조문을 검색이 찾았다고 치고
     python3 run_on_qdrant.py --demo "여신규정 제5조" --audience 키   그 권한의 사용자로

   정확도 점검 (한 번이면 된다):
     python3 run_on_qdrant.py --sample 20 --verify --verify-limit 30

3. 한 규정만 보고 싶으면:
     python3 run_on_qdrant.py --doc 대출규정
   구조 진단만 (그래프 안 만듦):
     python3 run_on_qdrant.py --inspect

읽기 전용이다. Qdrant 에 아무것도 쓰지 않는다.
그래프를 저장하지도 않는다 — 숫자를 보는 게 목적이다.

찍어올 것: 맨 끝 "★ 요약" 화면 한 장.
  끝내는 기준 — LLM 확인 정밀도 0.99 이상 + 틀림 예시에 새 종류 오류 없음.
  더 필요하면 그때 특정 부분만 요청한다.
