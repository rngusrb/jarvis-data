# -*- coding: utf-8 -*-
"""
graph_build/resolve.py

**해소** — 참조 후보(`ClauseRef`)를 실제 조각으로 확정한다.

여기가 안전장치다. `clause_ref` 는 글자만 보고 후보를 뽑으므로 헛것을 뽑을 수 있다.
이 단계가 **색인에 실제로 있는지 대조**해서 없으면 연결하지 않는다.

노드는 **조각**이다 (`structure.py` 참조). 그래서:
  · 이름표 하나가 조각 여럿을 가리킬 수 있다 → 연결도 여럿이 된다
  · 같은 조각 안의 조문끼리는 **자기 자신**이라 자동으로 빠진다
    (조문 제목을 인용으로 세던 문제가 여기서 사라진다)

해소되지 않은 것은 **버리지 않는다.** 사유와 함께 `unresolved` 로 나온다.

순수 모듈이다. DB·네트워크를 모른다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from clause_ref import (
    KIND_ABSOLUTE, KIND_RANGE, KIND_RELATIVE, ClauseRef, expand_ranges,
)
from structure import DocNode, StructureIndex, struct_label

#: 연결이 될 수 있는 단위. 장·절은 **계층** 이름표(`struct_label`)로 연결된다.
#: 항·호·목은 조각보다 **작은** 단위라 가리킬 조각이 없다.
#: `부칙` 은 뺐다 — 문서에 부칙이 개정마다 있어 **어느 부칙인지 특정할 수 없다**
#: (2026-09-28 Reviewer 2차 F2: `부칙` 한 단어가 문서의 모든 부칙 조각으로 연결됐다).
LINKABLE_UNITS: Tuple[str, ...] = ("조", "장", "절", "별표", "별첨", "서식")

#: 이름표 하나가 이만큼 넘는 조각을 가리키면 연결하지 않는다.
#: `제2장` 이 조각 50개를 가리키면 그건 연결이 아니라 **문서 전체**다.
MAX_TARGETS_PER_LABEL = 12

REASON_NO_DOC = "보유하지 않은 문서"
REASON_NO_TARGET = "문서는 있으나 해당 조문이 없음"
REASON_SELF = "같은 조각을 가리킴"
REASON_UNIT = "조각보다 작은 단위 (항·호·목)"
REASON_ADDENDUM = "부칙 — 어느 부칙인지 특정할 수 없음"
REASON_TOO_MANY = "이름표가 가리키는 조각이 너무 많음"
REASON_NO_ANCHOR = "상대참조인데 현재 조문 위치를 모름"
REASON_NO_PREV = "전조인데 앞 조문이 없음"
REASON_PREV_GAP = "전조인데 바로 앞 번호가 색인에 없음"
REASON_PREV_AMBIGUOUS = "전조인데 이 조각에 조문이 여럿이라 기준을 모름"
REASON_WITHIN = "같은 조문 안을 가리킴"
REASON_RANGE_NOT_EXPANDED = "범위를 전개하지 않음 (expand=False)"
REASON_RANGE_REVERSED = "범위 끝이 시작보다 앞"
REASON_RANGE_TOO_WIDE = "범위가 100개를 넘음"
REASON_RANGE_MIXED = "본조와 가지조문이 섞인 범위"

#: 조 뒤에 항/호를 합칠 때, 사이에 **공백만** 있어야 한다.
#: 간격만 보면 `제99조와 제1항` 처럼 이음말이 낀 것도 합쳐진다 (2026-09-23 실검출) —
#: 그러면 제1항이 제99조의 항으로 둔갑하고 미해소 집계에서도 사라진다.
SUBUNIT_GAP_RE = re.compile(r"^[ \t]{0,3}$")
_PREV_RE = re.compile(r"^전\s*조")
_SELF_RE = re.compile(r"^(?:같은|본|해당|이)\s*조")
#: 조 이름표 해석. 하이픈 조문(`007-002조`)의 장 번호까지 읽는다 — 장이 다르면 인접이 아니다.
_TARGET_NO_RE = re.compile(r"^(?:(?P<pre>\d+)-)?(?P<main>\d+)조(?:의(?P<sub>\d+))?$")
_RANGE_END_RE = re.compile(r"^(?:(?P<pre>\d+)-)?(?P<main>\d+)(?:조|항|호)(?:의(?P<sub>\d+))?$")

EXTRACTOR_REGEX = "regex_v1"


@dataclass(frozen=True)
class ResolvedEdge:
    """확정된 연결 하나. Postgres `edge` 한 줄이 된다."""

    src: str                            # 출발 조각 id
    dst: str                            # 도착 조각 id
    rel: str = "REFERENCES"
    subtype: str = ""
    raw_text: str = ""
    src_offset_start: int = 0
    src_offset_end: int = 0
    paragraph: Optional[int] = None
    item: Optional[int] = None
    extractor: str = EXTRACTOR_REGEX
    confidence: float = 1.0
    mentions: int = 1                   # 같은 연결이 몇 번 인용됐나
    target: str = ""                    # 어느 이름표로 이었나 (`025조의009`·`별표009`).
                                        # 도착 조각이 이름표를 여럿 가지면 이게 없이는 맞게 이었는지 못 본다

    def __post_init__(self) -> None:
        if not self.src or not self.dst:
            raise ValueError("연결 양 끝이 있어야 한다")
        if self.src == self.dst:
            raise ValueError(f"같은 조각으로 가는 연결은 만들지 않는다: {self.src}")
        if not self.raw_text:
            raise ValueError("근거 없는 연결 금지 — 틀렸을 때 고칠 방법이 없다")


@dataclass(frozen=True)
class Unresolved:
    src: str
    raw_text: str
    reason: str
    offset_start: int = 0
    offset_end: int = 0
    doc_title: str = ""
    target: str = ""
    from_range: bool = False


@dataclass
class ResolveResult:
    edges: List[ResolvedEdge] = field(default_factory=list)
    unresolved: List[Unresolved] = field(default_factory=list)

    #: 구조적으로 연결이 **될 수 없는** 사유. 해소율 분모에서 뺀다.
    STRUCTURAL = (REASON_UNIT, REASON_SELF, REASON_WITHIN, REASON_ADDENDUM)

    @property
    def resolve_rate(self) -> float:
        """전체 해소율. 구조적 비대상까지 실패로 센다 — 낮게 나온다."""
        total = len(self.edges) + len(self.unresolved)
        return round(len(self.edges) / total, 4) if total else 0.0

    @property
    def real_rate(self) -> float:
        """
        **실질 해소율.** 애초에 연결 대상이 아닌 것과 범위 부산물을 분모에서 뺀다.

        항·호·목은 조각보다 작아서 가리킬 데가 없고, 같은 조각·같은 조문 안은
        연결할 이유가 없다. 이것들을 실패로 세면 고칠 수 없는 걸 분모에 넣는 꼴이다.
        """
        real = [u for u in self.unresolved
                if u.reason not in self.STRUCTURAL and not u.from_range]
        total = len(self.edges) + len(real)
        return round(len(self.edges) / total, 4) if total else 0.0


def merge_subunits(refs: Sequence[ClauseRef], text: str = "") -> List[ClauseRef]:
    """
    `제10조의3 제2항` 처럼 조 **바로 뒤에** 붙은 항/호를 조 참조에 합친다.

    사이에 공백 말고 다른 글자가 있으면 합치지 않는다 — `제99조와 제1항` 은 별개다.
    `text` 를 안 주면 간격만 보므로(하위호환) 되도록 넘긴다.
    """
    out: List[ClauseRef] = []
    for ref in refs:
        if ref.unit in ("항", "호") and out and ref.kind == KIND_ABSOLUTE:
            prev = out[-1]
            gap = text[prev.end:ref.start] if text else " " * max(ref.start - prev.end, 0)
            if (prev.unit == "조" and prev.kind == KIND_ABSOLUTE
                    and ref.start >= prev.end and SUBUNIT_GAP_RE.match(gap)):
                from dataclasses import replace as _replace
                out[-1] = _replace(
                    prev,
                    paragraph=ref.paragraph if ref.unit == "항" else prev.paragraph,
                    item=ref.item if ref.unit == "호" else prev.item,
                    relation=prev.relation or ref.relation)
                continue
        out.append(ref)
    return out


_STRUCT_TARGET_RE = re.compile(r"^(?:(?P<chap>\d+)장)?(?:(?P<sec>\d+)절)?$")


def merge_structure(refs: Sequence[ClauseRef], text: str = "") -> List[ClauseRef]:
    """
    `제2장 제1절` 을 **한 참조**로 합친다 (target `002장001절`). 따로 풀면 `제2장` 전체와
    모든 장의 `제1절` 의 **합집합**이 된다 (Reviewer 2차 F1). 증거 구간은 장 참조 그대로 둔다
    (`merge_subunits` 와 같은 계약). 사이에 공백만 있어야 합친다.
    """
    from dataclasses import replace as _replace

    out: List[ClauseRef] = []
    for ref in refs:
        if ref.unit == "절" and ref.kind == KIND_ABSOLUTE and out:
            prev = out[-1]
            gap = text[prev.end:ref.start] if text else " " * max(ref.start - prev.end, 0)
            if (prev.unit == "장" and prev.kind == KIND_ABSOLUTE and prev.doc_title == ref.doc_title
                    and ref.start >= prev.end and SUBUNIT_GAP_RE.match(gap)):
                out[-1] = _replace(prev, unit="절", target=prev.target + ref.target,
                                   relation=prev.relation or ref.relation)
                continue
        out.append(ref)
    return out


def _struct_target(ref: ClauseRef, same_doc: bool,
                   scope: Tuple[Optional[int], Optional[int], Optional[int]]) -> str:
    """
    장·절 인용 → 계층 이름표. **같은 문서면** 빠진 윗단(편·장)을 출발 조각에서 채운다 —
    `제1절` 은 "이 장의 제1절", `제3장` 은 "이 편의 제3장" 이다.
    다른 문서면 채울 근거가 없으므로 적힌 그대로 (편이 있는 문서면 `NO_TARGET` 이 된다 — 안전).
    """
    m = _STRUCT_TARGET_RE.match(ref.target)
    if not m or not (m.group("chap") or m.group("sec")):
        return ref.target
    chap = int(m.group("chap")) if m.group("chap") else None
    sec = int(m.group("sec")) if m.group("sec") else None
    part, src_chap, _src_sec = scope if same_doc else (None, None, None)
    if chap is None and sec is not None:
        chap = src_chap                      # 맨 `제1절` → 이 장의 제1절
    return struct_label(part, chap, sec)


def dedupe(edges: Sequence[ResolvedEdge]) -> List[ResolvedEdge]:
    """
    같은 `(출발, 도착, 관계)` 를 하나로 합치고 **인용 횟수를 센다.**

    버리지 않는 이유: 여러 번 인용했다는 건 관련이 강하다는 신호일 수 있다.
    다만 지금은 세기만 하고 가중치에 넣지 않는다 — 측정 전이다.
    """
    from dataclasses import replace as _replace

    merged: Dict[Tuple[str, str, str, str], ResolvedEdge] = {}
    for e in edges:
        key = (e.src, e.dst, e.rel, e.subtype)
        old = merged.get(key)
        merged[key] = _replace(old, mentions=old.mentions + 1) if old else e
    return list(merged.values())


def _range_reason(ref: ClauseRef, expand: bool) -> str:
    if not expand:
        return REASON_RANGE_NOT_EXPANDED
    end = _RANGE_END_RE.match(ref.range_end or "")
    if not end:
        return REASON_RANGE_MIXED
    end_pre = int(end.group("pre")) if end.group("pre") else None
    if end_pre != ref.article_prefix:
        return REASON_RANGE_MIXED                  # `제7-9조부터 제8-2조까지` — 장이 다르다
    has_sub = ref.sub_article is not None
    if has_sub != (end.group("sub") is not None):
        return REASON_RANGE_MIXED
    lo = ref.sub_article if has_sub else (ref.article or 0)
    hi = int(end.group("sub")) if has_sub else int(end.group("main"))
    if hi < lo:
        return REASON_RANGE_REVERSED
    return REASON_RANGE_TOO_WIDE if hi - lo > 100 else REASON_RANGE_MIXED


def _is_adjacent(prev: str, current: str) -> bool:
    """
    `prev` 가 `current` 의 **바로 앞 번호**인가. 가지조문·하이픈 조문도 본다.

    하이픈 조문은 **장 번호가 같아야** 한다. `제7-1조` 의 전조는 6장 마지막 조인데,
    그게 몇 번인지 색인만 보고는 확인할 수 없다 → 인접 아님(`REASON_PREV_GAP`).
    """
    a, b = _TARGET_NO_RE.match(prev or ""), _TARGET_NO_RE.match(current or "")
    if not a or not b or a.group("pre") != b.group("pre"):
        return False
    a_main, a_sub = int(a.group("main")), a.group("sub")
    b_main, b_sub = int(b.group("main")), b.group("sub")
    if b_sub is not None:
        return a_main == b_main and ((int(a_sub) == int(b_sub) - 1) if a_sub
                                     else int(b_sub) == 1)
    return a_main == b_main - 1


def _resolve_relative(ref: ClauseRef, index: StructureIndex, doc_title: str,
                      current_articles: Sequence[str],
                      use_context: bool = True) -> Tuple[Optional[str], str]:
    """
    상대참조(`전조`·`같은 조`)를 이름표로. 반환 `(이름표, 사유)`.

    `use_context=False` 면 본문 머리글을 기준으로 쓰지 않는다 — 별표·부칙 조각은
    조 번호를 다시 세므로 `부칙 제2조` 의 전조를 **본칙 제1조**로 풀게 된다 (Reviewer 3차 G1).
    """
    if ref.unit != "조":
        return None, REASON_WITHIN
    raw = ref.raw.strip()
    if _SELF_RE.match(raw):
        return None, REASON_SELF
    if not _PREV_RE.match(raw):
        return None, REASON_NO_ANCHOR
    # 기준 조문: 본문 안 가장 가까운 앞 머리글이 우선이다. 조각에 조문이 여럿 든 경우
    # 조각 이름표로 풀면 엉뚱한 조문의 전조가 된다 (`ClauseRef.context_article` 참조).
    anchor = ref.context_article if use_context else ""
    if not anchor:
        if len(current_articles) != 1:
            # 조각에 조문이 여럿이면 `전조` 의 기준이 어느 조문인지 알 수 없다
            return None, (REASON_PREV_AMBIGUOUS if current_articles else REASON_NO_ANCHOR)
        anchor = current_articles[0]
    prev = index.previous_article(doc_title, anchor)
    if not prev:
        return None, REASON_NO_PREV
    if not _is_adjacent(prev, anchor):
        return None, REASON_PREV_GAP
    return prev, ""


def resolve(
    refs: Sequence[ClauseRef],
    index: StructureIndex,
    *,
    src_node_id: str,
    self_doc_title: str,
    current_articles: Sequence[str] = (),
    expand: bool = True,
    text: str = "",
) -> ResolveResult:
    """
    참조 후보를 조각으로 확정한다.

    Args:
        src_node_id: 이 본문이 들어있는 **조각 id** (= parent_id)
        current_articles: 그 조각이 담은 조 번호 목록. `전조` 해소에 필요하다
        text: 원문. 조 뒤 항/호 합치기가 이음말을 구분하는 데 쓴다
    """
    range_spans = {(r.start, r.end) for r in refs if r.kind == KIND_RANGE}
    items = merge_structure(merge_subunits(list(expand_ranges(refs) if expand else refs), text), text)
    result = ResolveResult()
    src_node = index.node(src_node_id)
    src_scope = src_node.scope if src_node is not None else (None, None, None)
    self_key = re.sub(r"\s+", "", self_doc_title or "")

    def reject(ref: ClauseRef, reason: str, doc: str = "", target: str = "") -> None:
        result.unresolved.append(Unresolved(
            src=src_node_id, raw_text=ref.raw, reason=reason,
            offset_start=ref.start, offset_end=ref.end,
            doc_title=doc, target=target,
            from_range=(ref.start, ref.end) in range_spans,
        ))

    for ref in items:
        doc_title = ref.doc_title or self_doc_title
        target = ref.target

        if ref.kind == KIND_RANGE:
            reject(ref, _range_reason(ref, expand), doc_title, target)
            continue

        if ref.kind == KIND_RELATIVE:
            target, reason = _resolve_relative(
                ref, index, self_doc_title, current_articles,
                use_context=not (src_node is not None and src_node.scoped))
            if not target:
                reject(ref, reason, doc_title)
                continue
            doc_title = self_doc_title

        if ref.unit == "부칙":
            reject(ref, REASON_ADDENDUM, doc_title, target)
            continue
        if ref.unit not in LINKABLE_UNITS:
            reject(ref, REASON_UNIT, doc_title, target)
            continue
        if not doc_title or not index.has_doc(doc_title):
            reject(ref, REASON_NO_DOC, doc_title, target)
            continue
        if ref.unit in ("장", "절"):
            target = _struct_target(ref, re.sub(r"\s+", "", doc_title) == self_key, src_scope)

        nodes = index.find(doc_title, target)
        if not nodes:
            reject(ref, REASON_NO_TARGET, index.display_title(doc_title), target)
            continue
        if len(nodes) > MAX_TARGETS_PER_LABEL:
            reject(ref, REASON_TOO_MANY, index.display_title(doc_title), target)
            continue

        hit = False
        for node in nodes:
            if node.node_id == src_node_id:
                continue                             # 같은 조각 — 제목이든 자기참조든
            result.edges.append(ResolvedEdge(
                src=src_node_id, dst=node.node_id, subtype=ref.relation,
                raw_text=ref.raw, src_offset_start=ref.start, src_offset_end=ref.end,
                paragraph=ref.paragraph, item=ref.item, target=target,
            ))
            hit = True
        if not hit:
            reject(ref, REASON_SELF, index.display_title(doc_title), target)

    result.edges = dedupe(result.edges)
    return result


def audit(result: ResolveResult) -> Dict[str, object]:
    """해소 결과 요약. 사유별 분포가 **다음에 뭘 고칠지**를 알려준다."""
    by_reason: Dict[str, int] = {}
    for u in result.unresolved:
        by_reason[u.reason] = by_reason.get(u.reason, 0) + 1
    by_subtype: Dict[str, int] = {}
    for e in result.edges:
        by_subtype[e.subtype or "(없음)"] = by_subtype.get(e.subtype or "(없음)", 0) + 1
    return {
        "edges": len(result.edges),
        "unresolved": len(result.unresolved),
        "resolve_rate": result.resolve_rate,
        "real_rate": result.real_rate,
        "by_reason": by_reason,
        "by_subtype": by_subtype,
        "from_range": sum(1 for u in result.unresolved if u.from_range),
        "repeated": sum(1 for e in result.edges if e.mentions > 1),
        "missing_docs": sorted({u.doc_title for u in result.unresolved
                                if u.reason == REASON_NO_DOC and u.doc_title}),
    }
