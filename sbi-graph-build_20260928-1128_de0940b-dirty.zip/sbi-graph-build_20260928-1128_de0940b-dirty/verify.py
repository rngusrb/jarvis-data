# -*- coding: utf-8 -*-
"""
graph_build/verify.py

**LLM 검증** — 정규식이 뽑고 색인이 대조한 후보를 LLM 에게 **객관식으로** 확인시킨다.

왜 객관식인가:
  LLM 에게 "참조를 뽑아라" 하면 환각이 들어온다 — 없는 조문 번호를 만들어낸다.
  "이거 맞아?" 라고 물으면 **선택지 밖으로 나갈 수 없다.** 후보 목록은 정규식이 정하고
  LLM 은 그중 무엇이 진짜인지만 고른다. 생성이 아니라 판정이다.

이 모듈은 **순수**하다. LLM 을 호출하지 않는다 — 프롬프트를 만들고 응답을 읽을 뿐이다.
호출은 내부망에서 한다 (`src/models/globals.py` 와 같은 서버).

파싱 실패를 조용히 넘기지 않는다:
  LLM 응답은 형식을 벗어난다. 항목 수가 안 맞거나, 번호를 빼먹거나, 설명을 덧붙인다.
  그걸 `모르겠음` 으로 뭉개면 **검증이 돌았는지 아닌지조차 알 수 없다.**
  `VerifyResult.parse_issues` 가 무슨 일이 있었는지 남긴다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

VERDICT_YES = "맞음"
VERDICT_NO = "아님"
VERDICT_UNSURE = "모르겠음"
VALID_VERDICTS = (VERDICT_YES, VERDICT_NO, VERDICT_UNSURE)

#: LLM 이 `모르겠음` 이거나 정규식과 엇갈린 엣지의 신뢰도.
#: 지우지 않고 낮춰서 남긴다 — 확산에 덜 기여하되 사람이 볼 목록에 오른다.
CONFIDENCE_UNSURE = 0.6

EXTRACTOR_LLM_CONFIRMED = "regex_v1+llm_v1"

_VERDICT_LINE_RE = re.compile(
    rf"^\s*[\[\(]?(\d+)[\]\).:\-]?\s*[:：\-]?\s*({'|'.join(VALID_VERDICTS)})\s*(?:[—\-–:]\s*(.*))?$"
)
_FENCE_RE = re.compile(r"^\s*```[a-zA-Z]*\s*$|^\s*```\s*$")


@dataclass(frozen=True)
class VerifyItem:
    """LLM 에게 물을 후보 하나."""

    no: int                      # 1부터. 프롬프트·응답의 짝을 맞추는 유일한 키
    raw: str                     # 원문에 적힌 그대로
    doc_title: str = ""          # '' 이면 같은 문서
    target: str = ""
    relation: str = ""
    dst_title: str = ""          # 해소된 조문 제목. 있으면 LLM 판단에 도움이 된다

    def __post_init__(self) -> None:
        if self.no < 1:
            raise ValueError("VerifyItem.no 는 1부터다 — 0 은 LLM 이 자주 건너뛴다")
        if not self.raw:
            raise ValueError("판정할 원문 조각이 없다")


@dataclass
class VerifyResult:
    verdicts: Dict[int, str] = field(default_factory=dict)
    reasons: Dict[int, str] = field(default_factory=dict)
    parse_issues: List[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """파싱 문제가 없었는가. **False 면 이 회차는 신뢰하지 않는다.**"""
        return not self.parse_issues


PROMPT_HEADER = """당신은 한국 사내규정·법령 문서의 조문 참조를 검수합니다.

아래 문장에서 기계가 뽑은 "다른 조문을 가리키는 표현" 후보들이 있습니다.
각 후보가 **정말로 다른 조문을 가리키는 참조인지** 판정하세요.

판정 기준:
- 맞음: 실제로 다른 조문(또는 별표·서식)을 가리키는 참조다
- 아님: 참조가 아니다. 예 — 금액 단위("1조원"), 일반 명사("품목", "제목"),
        조문 머리글 자기 표시, 문서 제목의 일부
- 모르겠음: 문장만으로는 판단할 수 없다

규칙:
- **후보 목록에 없는 참조를 새로 만들지 마세요.** 주어진 번호만 판정합니다.
- 설명·머리말·마크다운을 붙이지 마세요.
- 반드시 아래 형식으로 **후보 개수만큼** 한 줄씩 출력하세요.

출력 형식:
1: 맞음
2: 아님 — 금액 단위
3: 모르겠음 — 앞 문장이 필요함
"""


def build_prompt(sentence: str, items: Sequence[VerifyItem]) -> str:
    """
    판정 프롬프트를 만든다.

    Args:
        sentence: 후보가 나온 **원문 전체**. 문맥 없이는 `같은 법` 을 판단할 수 없다.
        items: 후보 목록. `no` 는 1부터 연속이어야 한다.

    Raises:
        ValueError: 후보가 비었거나 번호가 1부터 연속이 아닐 때.
            번호가 어긋나면 응답을 후보에 되돌려 붙일 수 없다.
    """
    if not items:
        raise ValueError("판정할 후보가 없다 — 빈 프롬프트를 보내지 않는다")
    expected = list(range(1, len(items) + 1))
    if [i.no for i in items] != expected:
        raise ValueError(f"후보 번호가 1부터 연속이 아니다: {[i.no for i in items]}")

    lines = [PROMPT_HEADER, "", "[문장]", sentence.strip(), "", "[후보]"]
    for item in items:
        where = item.doc_title or "(같은 문서)"
        detail = f"{item.raw}  →  {where} {item.target}".rstrip()
        if item.dst_title:
            detail += f" ({item.dst_title})"
        if item.relation:
            detail += f" / 관계: {item.relation}"
        lines.append(f"{item.no}: {detail}")
    lines.append("")
    lines.append(f"[판정] — {len(items)}줄")
    return "\n".join(lines)


def parse_verdicts(response: str, items: Sequence[VerifyItem]) -> VerifyResult:
    """
    LLM 응답을 판정표로 읽는다.

    형식을 벗어난 것은 **`parse_issues` 에 남긴다.** 조용히 `모르겠음` 으로 뭉개면
    검증이 실제로 돌았는지 알 수 없게 된다.

    미판정 항목은 `모르겠음` 으로 채우되 그 사실을 반드시 기록한다.
    """
    result = VerifyResult()
    valid_nos = {i.no for i in items}

    if not (response or "").strip():
        result.parse_issues.append("응답이 비어 있다")
        for item in items:
            result.verdicts[item.no] = VERDICT_UNSURE
        return result

    for line in response.splitlines():
        if not line.strip() or _FENCE_RE.match(line):
            continue
        m = _VERDICT_LINE_RE.match(line)
        if not m:
            result.parse_issues.append(f"형식을 벗어난 줄: {line.strip()[:60]!r}")
            continue
        no, verdict, reason = int(m.group(1)), m.group(2), (m.group(3) or "").strip()
        if no not in valid_nos:
            result.parse_issues.append(f"후보에 없는 번호: {no}")
            continue
        if no in result.verdicts:
            result.parse_issues.append(f"번호 {no} 가 두 번 나왔다 — 첫 판정을 쓴다")
            continue
        result.verdicts[no] = verdict
        if reason:
            result.reasons[no] = reason

    missing = sorted(valid_nos - set(result.verdicts))
    if missing:
        result.parse_issues.append(f"판정이 없는 후보: {missing} — 모르겠음으로 둔다")
        for no in missing:
            result.verdicts[no] = VERDICT_UNSURE
    return result


@dataclass
class ApplyResult:
    """검증을 엣지에 반영한 결과."""

    kept: List[object] = field(default_factory=list)      # ResolvedEdge
    dropped: List[Tuple[object, str]] = field(default_factory=list)
    review: List[Tuple[object, str]] = field(default_factory=list)

    def summary(self) -> Dict[str, object]:
        return {
            "kept": len(self.kept),
            "dropped": len(self.dropped),
            "review": len(self.review),
            "review_reasons": sorted({r for _e, r in self.review}),
        }


def apply_verdicts(edges: Sequence, items: Sequence[VerifyItem],
                   result: VerifyResult) -> ApplyResult:
    """
    판정을 엣지에 반영한다. `edges[i]` 와 `items[i]` 가 **같은 순서**여야 한다.

    - `맞음`      → 그대로 둔다 (`extractor` 에 llm 확인 표시)
    - `아님`      → 엣지를 만들지 않는다. **정규식과 엇갈렸으므로 검수 목록에 올린다**
    - `모르겠음`  → 엣지는 두되 신뢰도를 낮추고 검수 목록에 올린다

    파싱에 문제가 있었으면(`result.ok` 가 False) **아무것도 떨어뜨리지 않는다** —
    형식이 깨진 응답으로 엣지를 지우면 조용히 그래프가 빈다.
    """
    from dataclasses import replace

    out = ApplyResult()
    if len(edges) != len(items):
        raise ValueError(f"엣지 {len(edges)}개 ↔ 후보 {len(items)}개 — 짝이 안 맞는다")

    for edge, item in zip(edges, items):
        verdict = result.verdicts.get(item.no, VERDICT_UNSURE)
        reason = result.reasons.get(item.no, "")

        if not result.ok:
            out.kept.append(edge)
            out.review.append((edge, f"응답 파싱 실패로 판정 보류: {result.parse_issues[0]}"))
            continue

        if verdict == VERDICT_YES:
            out.kept.append(replace(edge, extractor=EXTRACTOR_LLM_CONFIRMED))
        elif verdict == VERDICT_NO:
            out.dropped.append((edge, reason or "LLM 이 참조가 아니라고 판정"))
            out.review.append((edge, f"정규식↔LLM 엇갈림: {reason or '사유 없음'}"))
        else:
            out.kept.append(replace(edge, confidence=CONFIDENCE_UNSURE))
            out.review.append((edge, f"LLM 모르겠음: {reason or '사유 없음'}"))
    return out


def items_from_edges(edges: Sequence, index=None) -> List[VerifyItem]:
    """
    `ResolvedEdge` 목록 → `VerifyItem` 목록. 번호는 1부터 붙인다.

    `edge.dst` 는 **조각 id** 다. 사람이 읽을 이름은 색인에서 꺼낸다.
    도착 이름은 **연결에 쓰인 이름표**(`edge.target`)다 — 조각의 이름표 전체를 보여주면
    이름표 25개짜리 조각이나 이름표가 조 번호가 아닌 별표·부칙 조각에서 판정 근거가 흐려진다
    (별표·부칙은 예전에 조각 id 문자열이 그대로 나갔다).
    """
    items: List[VerifyItem] = []
    for i, edge in enumerate(edges, start=1):
        node = index.node(edge.dst) if index is not None else None
        fallback = ("/".join(node.labels) if node and node.labels else str(edge.dst))
        items.append(VerifyItem(
            no=i, raw=edge.raw_text,
            doc_title=(node.doc_title if node else ""),
            target=(getattr(edge, "target", "") or fallback),
            relation=edge.subtype,
            dst_title=(node.title if node else ""),
        ))
    return items
