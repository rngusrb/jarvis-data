# -*- coding: utf-8 -*-
"""
graph/expand.py

**검색과 리랭커 사이에 끼는 단계.** Qdrant 가 찾아온 조문에서 출발해
참조로 이어진 조문을 넓히고, 권한을 건다.

권한 규칙은 `vector_store._get_tenant_filter` + `lib/util/qdrant_filter.build_category_filter`
와 **같아야 한다.** 다르면 검색 경로와 확장 경로가 서로 다른 권한으로 돌아,
검색에선 안 나오는 문서가 확장으로 새어 나온다.
`tests/invariants/test_graph_tenant_contract.py` 가 두 곳의 접두사 표를 대조한다.

권한은 **확산 전에** 건다. 뿌리고 나서 거르면 볼 수 없는 조문을 거쳐 온 점수가
이미 다른 조문 순위를 올려놓은 뒤다 — 내용은 안 보여도 존재가 순위에 샌다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from uuid import NAMESPACE_URL, uuid5

from graph.ppr import ClauseGraph, top_scores

#: `dept_info` 키 → `audience_keys` 접두사.
#: **`vector_store._get_tenant_filter` 의 `mapping` 과 같아야 한다.**
DEPT_PREFIX: Dict[str, str] = {
    "headquarter": "HQ",
    "branch": "BR",
    "division": "DIV",
    "department": "DEPT",
    "team": "TEAM",
}

#: 모두에게 열린 키. `_get_tenant_filter` 가 항상 넣는다.
GLOBAL_KEY = "GLOBAL"

#: `main_category` 가 이 값일 때만 `category_id` 제한을 건다.
#: 그 외(법령·공지 등)는 전원 공개 — `build_category_filter` 와 같은 규칙.
CATEGORY_VAL_INTERNAL_REGULATION = "내부규정"

#: 카테고리 제한을 걸지 **않겠다는 명시적 표시**. `None` 은 "목록을 못 받았다" 이고
#: 그때 내부규정은 **막힌다**. 모르면 막는 쪽이 맞다.
ALLOW_ALL_CATEGORIES = "__ALL__"

DEFAULT_TOP_K = 20

#: 점수 하한. **시드 개수로 정규화해서** 쓴다 — PPR reset 이 `1/len(seeds)` 라
#: 시드가 늘면 전체 점수가 그만큼 낮아지기 때문이다.
#:
#: 사고 이력 (2026-09-23 Reviewer): 고정 0.01 이면 시드 1개→4건, 20개→**0건**.
#: `vector_store` 가 top 10~20 을 주므로 운영에서는 **항상 0건**이 된다.
#: 그리고 빈 결과가 "관련 조문 없음" 과 구분되지 않는다.
DEFAULT_MIN_SCORE_PER_SEED = 0.01


@dataclass(frozen=True)
class GraphNode:
    """확장에 필요한 최소 정보. Postgres `graph_node` 한 줄에서 온다."""

    node_id: str
    parent_id: str = ""
    category_id: str = ""
    main_category: str = ""
    audience_keys: Tuple[str, ...] = ()



def to_point_id(parent_id: str) -> str:
    """
    `parent_id` → Qdrant parent 컬렉션의 **point id**.

    색인 스크립트의 `to_point_id` 와 같은 식이다 (`uuid5(NAMESPACE_URL, parent_id)`).
    결정적이라 `client.retrieve(collection_name=parents, ids=[...])` 로
    **스캔 없이** 본문을 가져올 수 있다 — `scroll(filter=…)` 보다 빠르다.
    """
    return str(uuid5(NAMESPACE_URL, parent_id))


def audience_keys_from_dept_info(dept_info: Optional[Mapping]) -> Tuple[str, ...]:
    """
    `dept_info` → 권한 키 목록. `_get_tenant_filter` 와 같은 조립이다.

    `dept_info` 가 비어도 `GLOBAL` 은 항상 들어간다 — 그게 원래 동작이다.
    """
    keys = [GLOBAL_KEY]
    for key, value in (dept_info or {}).items():
        prefix = DEPT_PREFIX.get(key)
        if prefix and value not in (None, ""):
            keys.append(f"{prefix}:{value}")
    return tuple(keys)


class GraphView:
    """메모리 그래프 + 노드 속성. 서비스 기동 시 한 번 만든다."""

    __slots__ = ("graph", "nodes", "_parent_to_node")

    def __init__(self, graph: ClauseGraph, nodes: Mapping[str, GraphNode]) -> None:
        self.graph = graph
        self.nodes = dict(nodes)
        # 노드 id 가 곧 조각 id 다 (`tools/graph_build/structure.py`).
        # 그래서 검색 결과의 `parent_id` 를 그대로 노드로 쓴다 — 변환표가 필요 없다.
        self._parent_to_node: Dict[str, str] = {
            n.parent_id or n.node_id: n.node_id for n in self.nodes.values()
        }

    @property
    def parent_coverage(self) -> float:
        """
        `parent_id` 를 가진 노드의 비율. **0 이면 확장이 절대 안 된다.**
        `coverage` 만 보면 1.0 이라 정상으로 보인다 (2026-09-23 Reviewer 🟠).
        """
        if not self.nodes:
            return 0.0
        have = sum(1 for n in self.nodes.values() if n.parent_id)
        return round(have / len(self.nodes), 4)

    @property
    def coverage(self) -> float:
        """그래프 노드 중 속성을 아는 비율. 낮으면 적재가 어긋난 것이다."""
        if len(self.graph) == 0:
            return 0.0
        known = sum(1 for nid in self.graph.node_ids if nid in self.nodes)
        return round(known / len(self.graph), 4)

    def node_of_parent(self, parent_id: str) -> Optional[str]:
        return self._parent_to_node.get(parent_id)

    # ── 권한 ────────────────────────────────────────────────────────────
    def is_visible(self, node: Optional[GraphNode], audience_keys: Sequence[str],
                   allowed_category_ids) -> bool:
        """
        한 노드가 이 사용자에게 보이는가. **검색 필터를 그대로 옮긴 것이다.**

        `vector_store._get_tenant_filter` 의 실제 결합:
        ```python
        Filter(must=[category_filter, tenant_filter])
        ```
        `tenant_filter`(= `audience_keys` MatchAny)가 **must 안에 있으므로
        모든 문서에 걸린다.** `build_category_filter` 만 `내부규정` 에 한정된다.

        사고 이력 (2026-09-23 Reviewer, 🔴 Critical):
          여기에 `if main_category != '내부규정': return True` 특례가 있었다.
          "법령은 전원 공개" 라는 **틀린 가정**이었다 — 법령은 카테고리 검사만 면제된다.
          60조합 대조에서 **18건 불일치, 전부 유출 방향**(검색=차단/확장=허용).
          `main_category` 가 payload 에 없으면 `""` 라서 **그래프 전체가 공개**되기도 했다.
          그리고 이 저장소의 테스트가 그 유출을 `assert "c9" in got` 로 고정하고 있었다.

        속성을 모르는 노드(`None`)는 **막는다.** 모르면 닫는 쪽이 맞다.
        """
        if node is None:
            return False

        # ① 권한 키 — 모든 문서에 (검색의 must)
        if not (set(node.audience_keys) & set(audience_keys)):
            return False

        # ② 카테고리 — 내부규정에만 (검색의 build_category_filter)
        if node.main_category == CATEGORY_VAL_INTERNAL_REGULATION:
            if allowed_category_ids is ALLOW_ALL_CATEGORIES:
                return True
            if allowed_category_ids is None:
                return False                         # 목록을 못 받았다 → 막는다
            return node.category_id in set(allowed_category_ids)
        return True

    def visible_mask(self, audience_keys: Sequence[str],
                     allowed_category_ids) -> List[bool]:
        return [self.is_visible(self.nodes.get(nid), audience_keys, allowed_category_ids)
                for nid in self.graph.node_ids]

    # ── 확장 ────────────────────────────────────────────────────────────
    def expand(
        self,
        seed_parent_ids: Sequence[str],
        *,
        audience_keys: Sequence[str],
        allowed_category_ids,
        top_k: int = DEFAULT_TOP_K,
        min_score_per_seed: float = DEFAULT_MIN_SCORE_PER_SEED,
        alpha: float = 0.5,
    ) -> List[str]:
        """
        검색 결과에서 출발해 관련 조문의 **chunk_id** 를 돌려준다.

        Args:
            seed_parent_ids: 검색 결과 Document 의 `metadata["parent_id"]` 목록.
            audience_keys: 이 사용자의 권한 키. **필수 인자다** —
                키워드 인자로 강제해서 "권한 거는 걸 깜빡" 할 수 없게 만든다.
            allowed_category_ids: 내부규정 카테고리 제한 목록. **필수 인자다.**
                `None` 은 "목록을 못 받았다" 로 보고 **내부규정을 막는다**.
                제한을 안 걸려면 `ALLOW_ALL_CATEGORIES` 를 명시적으로 넘긴다.
            min_score_per_seed: 점수 하한. **시드 개수로 나눠서** 적용한다.

        Raises:
            ValueError: `audience_keys` 가 비었을 때.
                빈 권한으로 전체를 여는 대신 **닫고 알린다.**

        Returns:
            seed 를 **제외한** `parent_id` 목록, 점수 내림차순.
            호출부는 `to_point_id()` 로 환산해 `retrieve(ids=…)` 하면 된다.
        """
        if not audience_keys:
            raise ValueError(
                "audience_keys 가 비었다 — 권한 없이 확장하지 않는다. "
                "호출부에서 dept_info 를 audience_keys_from_dept_info 로 만들 것")

        seeds = [nid for nid in (self.node_of_parent(p) for p in seed_parent_ids) if nid]
        if not seeds:
            return []

        mask = self.visible_mask(audience_keys, allowed_category_ids)
        scores = self.graph.personalized_pagerank(seeds, visible=mask, alpha=alpha)

        # 시드가 늘면 전체 점수가 `1/len(seeds)` 만큼 낮아진다. 하한을 같이 낮추지 않으면
        # 검색이 20개를 줄 때 확장이 통째로 꺼진다 (2026-09-23 Reviewer 실측).
        floor = min_score_per_seed / max(len(seeds), 1)

        seed_set = set(seed_parent_ids)
        out: List[str] = []
        seen: set = set()
        # parent_id 없는 노드·시드를 **먼저** 걸러낸 뒤 top_k 를 센다 —
        # 나중에 거르면 20개를 뽑아 3개를 돌려준다.
        for node_id, _score in top_scores(scores, top_k=0, min_score=floor):
            node = self.nodes.get(node_id)
            if not (node and node.parent_id):
                continue
            if node.parent_id in seed_set or node.parent_id in seen:
                continue
            seen.add(node.parent_id)
            out.append(node.parent_id)
            if len(out) >= top_k:
                break
        return out


def build_view(edge_rows: Iterable, node_rows: Iterable) -> GraphView:
    """
    Postgres 두 쿼리 결과로 런타임 뷰를 만든다.

    `edge_rows`: `pg_store.SQL_LOAD_CURRENT_EDGES`
    `node_rows`: `pg_store.SQL_LOAD_NODES`
    """
    graph = ClauseGraph.from_rows(edge_rows)
    nodes: Dict[str, GraphNode] = {}
    for row in node_rows:
        data = row if isinstance(row, dict) else {
            "node_id": row[0], "doc_title": row[1], "target": row[2], "title": row[3],
            "parent_id": row[4], "category_id": row[5], "main_category": row[6],
            "audience_keys": row[7],
        }
        audience = data.get("audience_keys") or ()
        if isinstance(audience, str):
            audience = (audience,)
        nodes[data["node_id"]] = GraphNode(
            node_id=data["node_id"],
            parent_id=str(data.get("parent_id") or data["node_id"]),
            category_id=str(data.get("category_id") or ""),
            main_category=str(data.get("main_category") or ""),
            audience_keys=tuple(audience),
        )
    return GraphView(graph, nodes)
