# -*- coding: utf-8 -*-
"""
graph/ppr.py

조문 그래프와 **확산 기반 검색**(Personalized PageRank).

왜 메모리인가:
  조문 그래프는 노드 수만 개 규모다. 이 크기는 통째로 메모리에 올라간다.
  DB 에 물어보면 질의마다 왕복이 붙고, 무엇보다 **확산 계산이 SQL 로는 안 된다.**
  Postgres 는 정본이고, 여기는 계산이다.

왜 새 의존성을 안 쓰는가:
  `numpy` 는 `fastembed` 가 이미 끌고 온다. `igraph`·`scipy` 는 아니다.
  이 폴더는 서비스 저장소로 반출되므로 의존성을 늘리지 않는다.
  numpy 가 없으면 순수 파이썬으로 떨어지되 **조용히 떨어지지 않는다** — 로그를 남긴다.

관계별 가중치는 **전부 1.0 이다.** 차등을 두려면 골든셋으로 측정해야 하는데
아직 없다. 근거 없는 0.8 은 근거 없는 1.0 보다 나을 게 없고, "튜닝했다" 는 착각만 남긴다.
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import numpy as _np
    HAS_NUMPY = True
except ImportError:                                  # pragma: no cover - 환경 의존
    _np = None
    HAS_NUMPY = False
    print("[GRAPH] numpy 없음 — 순수 파이썬 확산으로 동작한다 (느림). "
          "운영에서는 numpy 를 설치할 것")

#: 관계별 가중치. **측정 전까지 전부 1.0.**
#: 바꾸려면 골든셋(질문 → 있어야 할 조문) 30~50건으로 적중률을 재고 나서 바꾼다.
#: 이 값은 DB 에 없다 — 여기만 고치고 서비스를 다시 띄우면 되고, 재적재가 필요 없다.
REL_WEIGHT: Dict[str, float] = {
    "준용": 1.0,
    "적용": 1.0,
    "참조": 1.0,
    "예외": 1.0,
    "제외": 1.0,
    "": 1.0,          # 관계를 못 찾은 엣지
}
DEFAULT_WEIGHT = 1.0

#: 확산 기본값. HippoRAG 2 가 igraph 에 damping=0.5 로 넘기는 것과 같은 뜻 —
#: 매 라운드 점수의 절반이 시작점으로 돌아간다.
DEFAULT_ALPHA = 0.5
DEFAULT_MAX_ITER = 30
DEFAULT_TOL = 1e-6


def weight_of(subtype: str, confidence: float) -> float:
    """엣지 가중치. `confidence`(누가 뽑았나)가 곱해진다 — 그건 근거 있는 숫자다."""
    return REL_WEIGHT.get(subtype or "", DEFAULT_WEIGHT) * float(confidence)


class ClauseGraph:
    """
    조문 그래프. **무방향**으로 다룬다.

    `제8조 → 제10조의3` 준용이면 제10조의3 을 찾았을 때 제8조도 관련 있다.
    방향을 지키면 역방향 질문("이 조문을 인용하는 건?")을 확산으로 못 푼다.
    방향 자체는 Postgres `graph_edge.src/dst` 에 그대로 남아 있으므로 잃지 않는다.
    """

    __slots__ = ("node_ids", "_index", "_src", "_dst", "_w", "_n")

    def __init__(self, node_ids: Sequence[str],
                 edges: Iterable[Tuple[int, int, float]]) -> None:
        self.node_ids: Tuple[str, ...] = tuple(node_ids)
        self._index: Dict[str, int] = {n: i for i, n in enumerate(self.node_ids)}
        self._n = len(self.node_ids)

        src: List[int] = []
        dst: List[int] = []
        w: List[float] = []
        for a, b, weight in edges:
            if a == b or weight <= 0:
                continue                             # 자기 루프·0 가중치는 확산에 무의미
            src.extend((a, b))                       # 무방향 = 양쪽
            dst.extend((b, a))
            w.extend((weight, weight))

        if HAS_NUMPY:
            self._src = _np.asarray(src, dtype=_np.int64)
            self._dst = _np.asarray(dst, dtype=_np.int64)
            self._w = _np.asarray(w, dtype=_np.float64)
        else:
            self._src, self._dst, self._w = src, dst, w

    # ── 구성 ────────────────────────────────────────────────────────────
    @classmethod
    def from_rows(cls, rows: Iterable) -> "ClauseGraph":
        """
        DB 행(`pg_store.SQL_LOAD_CURRENT_EDGES` 결과)으로 그래프를 만든다.

        행은 `(src, dst, rel, subtype, confidence)` 또는 같은 키의 dict 를 받는다.
        **양 끝 노드를 행에서 모은다** — 별도 노드 목록이 없어도 동작한다.
        """
        collected: List[Tuple[str, str, float]] = []
        order: List[str] = []
        seen = set()
        for row in rows:
            if isinstance(row, dict):
                a, b = row["src"], row["dst"]
                subtype, conf = row.get("subtype", ""), row.get("confidence", 1.0)
            else:
                a, b, _rel, subtype, conf = row
            for node in (a, b):
                if node not in seen:
                    seen.add(node)
                    order.append(node)
            collected.append((a, b, weight_of(subtype, conf)))

        index = {n: i for i, n in enumerate(order)}
        return cls(order, ((index[a], index[b], w) for a, b, w in collected))

    # ── 조회 ────────────────────────────────────────────────────────────
    def __len__(self) -> int:
        return self._n

    @property
    def edge_count(self) -> int:
        """무방향 엣지 개수 (양방향 저장분을 되돌린 수)."""
        return len(self._src) // 2

    def index_of(self, node_id: str) -> Optional[int]:
        return self._index.get(node_id)

    def has(self, node_id: str) -> bool:
        return node_id in self._index

    # ── 확산 ────────────────────────────────────────────────────────────
    def personalized_pagerank(
        self,
        seeds: Sequence[str],
        *,
        visible: Optional[Sequence[bool]] = None,
        alpha: float = DEFAULT_ALPHA,
        max_iter: int = DEFAULT_MAX_ITER,
        tol: float = DEFAULT_TOL,
    ) -> Dict[str, float]:
        """
        시작점에서 점수를 뿌린다.

        Args:
            seeds: 시작 노드 id 목록 (Qdrant 가 찾아온 조문).
            visible: 노드별 가시성. **확산 전에 그래프를 깎는다** —
                뿌리고 나서 거르면 볼 수 없는 조문을 거쳐 온 점수가 이미
                다른 조문 순위를 올려놓은 뒤다. 내용은 안 보여도 **존재가 순위에 샌다.**
            alpha: 매 라운드 시작점으로 돌아가는 비율.

        Returns:
            `{node_id: 점수}` — **시작점은 빼고** 점수 0 초과인 것만.
            시작점은 이미 손에 있으므로 결과에 넣을 이유가 없다.
        """
        seed_idx = [i for i in (self._index.get(s) for s in seeds) if i is not None]
        if not seed_idx or self._n == 0:
            return {}
        if visible is not None:
            seed_idx = [i for i in seed_idx if visible[i]]
            if not seed_idx:
                return {}

        scores = (self._ppr_numpy if HAS_NUMPY else self._ppr_python)(
            seed_idx, visible, alpha, max_iter, tol)

        seed_set = set(seed_idx)
        return {self.node_ids[i]: float(s)
                for i, s in enumerate(scores)
                if s > 0 and i not in seed_set}

    def _ppr_numpy(self, seed_idx, visible, alpha, max_iter, tol):
        n = self._n
        src, dst, w = self._src, self._dst, self._w

        if visible is not None:
            mask = _np.asarray(visible, dtype=bool)
            keep = mask[src] & mask[dst]             # 확산 **전에** 깎는다
            src, dst, w = src[keep], dst[keep], w[keep]
        else:
            mask = None

        deg = _np.bincount(src, weights=w, minlength=n)
        deg[deg == 0] = 1.0                          # 고립 노드 — 0 나눗셈 방지

        reset = _np.zeros(n, dtype=_np.float64)
        reset[_np.asarray(seed_idx, dtype=_np.int64)] = 1.0 / len(seed_idx)
        x = reset.copy()

        for _ in range(max_iter):
            flow = _np.bincount(dst, weights=w * (x[src] / deg[src]), minlength=n)
            nxt = (1.0 - alpha) * flow + alpha * reset
            if mask is not None:
                nxt *= mask
            if float(_np.abs(nxt - x).sum()) < tol:
                x = nxt
                break
            x = nxt
        return x

    def _ppr_python(self, seed_idx, visible, alpha, max_iter, tol):  # pragma: no cover
        n = self._n
        pairs = [(a, b, w) for a, b, w in zip(self._src, self._dst, self._w)
                 if visible is None or (visible[a] and visible[b])]
        deg = [0.0] * n
        for a, _b, w in pairs:
            deg[a] += w
        deg = [d if d else 1.0 for d in deg]

        reset = [0.0] * n
        for i in seed_idx:
            reset[i] = 1.0 / len(seed_idx)
        x = list(reset)

        for _ in range(max_iter):
            flow = [0.0] * n
            for a, b, w in pairs:
                flow[b] += w * x[a] / deg[a]
            nxt = [(1.0 - alpha) * flow[i] + alpha * reset[i] for i in range(n)]
            if visible is not None:
                nxt = [v if visible[i] else 0.0 for i, v in enumerate(nxt)]
            if sum(abs(nxt[i] - x[i]) for i in range(n)) < tol:
                return nxt
            x = nxt
        return x


def top_scores(scores: Dict[str, float], *, top_k: int, min_score: float
               ) -> List[Tuple[str, float]]:
    """
    점수로 자른다. **개수로만 자르지 않는다** — 관련 없으면 애초에 점수가 안 붙으므로
    상위 N 개를 억지로 채우면 노이즈가 들어온다.
    """
    ranked = sorted(scores.items(), key=lambda kv: (-kv[1], kv[0]))
    kept = [(n, s) for n, s in ranked if s >= min_score]
    return kept if top_k <= 0 else kept[:top_k]      # top_k=0 이면 자르지 않는다
