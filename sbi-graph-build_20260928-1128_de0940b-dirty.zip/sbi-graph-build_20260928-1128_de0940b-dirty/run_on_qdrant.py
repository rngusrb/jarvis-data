# -*- coding: utf-8 -*-
"""
graph_build/run_on_qdrant.py

**내부망 실행기** — 실제 Qdrant 코퍼스로 그래프를 만들어 보고 리포트를 찍는다.

이 파일은 `tools/graph_build/` 에서 **유일하게 네트워크를 쓴다**
(`evaluators/embed.py` 가 model_compare 에서 그렇듯). 나머지 모듈은 순수하게 둔다.

**읽기 전용이다.** Qdrant 에 쓰지 않는다 — `scroll` 만 한다.
그래프를 저장하지도 않는다. 이 실행기의 목적은 **숫자를 보는 것**이다.

왜 리포트가 짧은가:
  망 분리라 결과를 파일로 못 가져온다. 화면을 찍어 손으로 옮긴다.
  그래서 한두 화면에 들어가게, 판단에 필요한 것만 찍는다.

사용:
    python3 tools/graph_build/run_on_qdrant.py                 # 전량
    python3 tools/graph_build/run_on_qdrant.py --limit 2000    # 일부만
    python3 tools/graph_build/run_on_qdrant.py --sample 20     # 채점용 표본
    python3 tools/graph_build/run_on_qdrant.py --doc 대출규정   # 한 규정만
"""

from __future__ import annotations

import argparse
import os
import re
import random
import sys
from collections import Counter
from typing import Dict, List, Mapping

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# 데모(`--demo`)는 **운영 확산 코드**(`src/graph`)를 그대로 쓴다. 번들에는 `graph/` 로 옆에 들어 있고,
# 저장소에서 돌릴 때는 `src/` 에서 찾는다.
_REPO_SRC = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, os.pardir, "src"))
if os.path.isdir(os.path.join(_REPO_SRC, "graph")):
    sys.path.append(_REPO_SRC)

from clause_ref import (                                           # noqa: E402
    HEADING_RE, REJECT_ALIAS, REJECT_KNOWN_HEADING, build_aliases, extract_refs,
)
from resolve import (                                              # noqa: E402
    REASON_NO_DOC, ResolveResult, audit as res_audit, resolve,
)
from structure import (                                            # noqa: E402
    _ADDENDUM_HEAD_RE, _ARTICLE_HEAD_RE,
    appendix_label, build_index, header_segments, heading_index, leaf_header,
    normalize_chapter_no, official_abbreviations,
)
from verify import (                                               # noqa: E402
    VERDICT_NO, VERDICT_UNSURE, VERDICT_YES,
    apply_verdicts, build_prompt, items_from_edges, parse_verdicts,
)

TAG = "[GRAPH-RUN]"
#: 끝내는 기준 — LLM 확인 정밀도가 이 이상이고 **새 종류** 오류가 없으면 다듬기를 멈춘다 (사용자 합의 2026-09-28)
STOP_PRECISION = 0.99


def _die(msg: str) -> None:
    print(f"{TAG} ❌ {msg}")
    raise SystemExit(2)


def fetch_parents(limit: int = 0, doc: str = "") -> List[Dict]:
    """
    parent 컬렉션을 읽는다. **scroll 만 한다 — 쓰지 않는다.**

    실패를 삼키지 않는다: 연결·컬렉션 오류는 그대로 올린다.
    빈 결과도 **정상 성공으로 세지 않는다** — 0건이면 원인을 찍고 종료한다.
    """
    try:
        from dotenv import load_dotenv
        from qdrant_client import QdrantClient
    except ImportError as e:
        _die(f"의존성 없음: {e}. 운영 venv 에서 실행할 것")

    load_dotenv()
    url = os.getenv("QDRANT_URL")
    collection = os.getenv("PARENTS_COLLECTION_NAME")
    if not url or not collection:
        _die("QDRANT_URL / PARENTS_COLLECTION_NAME 미설정 (.env 확인)")

    print(f"{TAG} parent 컬렉션 읽는 중 — {collection}")
    client = QdrantClient(url=url, prefer_grpc=False)

    rows: List[Dict] = []
    offset = None
    while True:
        batch, offset = client.scroll(
            collection_name=collection, limit=512, offset=offset, with_payload=True)
        for point in batch:
            payload = dict(point.payload or {})
            if doc and doc not in str(payload.get("source_file", "")):
                continue
            rows.append(payload)
        if offset is None or (limit and len(rows) >= limit):
            break
    if not rows:
        _die(f"0건 — 컬렉션이 비었거나 --doc 필터가 안 맞는다 (doc={doc!r})")
    return rows[:limit] if limit else rows


def _kind_of(value) -> str:
    """`article_no` 가 어떤 모양으로 오는지 분류한다."""
    if value is None or value == "":
        return "없음"
    if isinstance(value, (list, tuple)):
        return f"리스트({len(value)}개)" if len(value) <= 2 else f"리스트(3개+)"
    text = str(value)
    if re.fullmatch(r"\d+", text):
        return "숫자문자열" if isinstance(value, str) else "정수"
    if re.search(r"[-의]", text):
        return "가지조문"
    return f"기타({text[:12]})"


def inspect_payloads(rows: List[Dict]) -> None:
    """
    **구조를 고치기 전에 데이터가 실제로 어떤 모양인지 찍는다.**

    추측으로 고치면 또 틀린다 — `chapter_no` 를 별표 번호로 알고 조 번호 폴백에 넣었다가
    실제로는 장 번호인 걸 나중에 알았다 (2026-09-23).
    """
    line = "=" * 70
    kinds, n_articles, chap, sect = Counter(), Counter(), 0, 0
    no_article, appendix_like, header_pat = [], [], Counter()
    chap_kind, addendum, addendum_with_article, hyphen_head = Counter(), 0, 0, 0
    leaf_ok, leaf_total = 0, 0
    body_heads_chunks, body_heads = 0, 0
    fmt, no_sect = Counter(), 0
    perm_by_cat = _permission_counts(rows)        # main_category → 권한 칸 존재

    for row in rows:
        payload = dict(row)
        nested = payload.get("metadata")
        if isinstance(nested, Mapping):
            payload = {**nested, **{k: v for k, v in payload.items() if k != "metadata"}}

        raw = payload.get("article_no")
        kinds[_kind_of(raw)] += 1
        n = len(raw) if isinstance(raw, (list, tuple)) else (0 if raw in (None, "") else 1)
        n_articles[n if n <= 10 else 11] += 1
        if payload.get("chapter_no") not in (None, ""):
            chap += 1
        if payload.get("section_no") not in (None, ""):
            sect += 1

        cno = payload.get("chapter_no")
        if cno not in (None, ""):
            chap_kind["숫자" if normalize_chapter_no(cno, "장") else
                      ("별표·서식" if appendix_label(cno) else f"기타({str(cno)[:8]})")] += 1
        segs = header_segments(payload.get("header_path"))
        if any(_ADDENDUM_HEAD_RE.match(s) for s in segs):
            addendum += 1
            addendum_with_article += 1 if n else 0
        if any(_ARTICLE_HEAD_RE.match(s) and _ARTICLE_HEAD_RE.match(s).group("pre") for s in segs):
            hyphen_head += 1
        fmt[str(payload.get("doc_format") or "(없음)")] += 1
        no_sect += 1 if "NO_SECTION" in segs or "NO_CHAPTER" in segs else 0
        leaf = leaf_header(payload.get("header_path"))
        if leaf:
            leaf_total += 1
            leaf_ok += 1 if str(payload.get("text") or "").startswith(leaf) else 0
        # 첫 줄(자기 헤더) **밖**의 조문 머리글 — 조각 하나에 조문이 여럿 든 경우.
        # 그 조문들은 이름표가 없어 인용이 이 조각을 못 찾는다.
        rest = str(payload.get("text") or "").split("\n", 1)[1:]
        found = len(HEADING_RE.findall(rest[0])) if rest else 0
        if found:
            body_heads_chunks += 1
            body_heads += found

        head = str(payload.get("header_path") or "")
        header_pat[re.sub(r"\d+", "N", head)[:48]] += 1
        if n == 0:
            no_article.append((head, str(payload.get("chapter_no") or ""),
                               str(payload.get("article_title") or "")))
        if re.search(r"별표|별지|서식|별첨", head + str(payload.get("article_title") or "")):
            appendix_like.append((head, raw, str(payload.get("chapter_no") or "")))

    print(f"\n{line}\nⓘ 진단 — article_no 가 어떤 모양으로 오는가")
    for k, v in kinds.most_common():
        print(f"   {k:14s} {v:6d}  ({round(v / max(len(rows), 1) * 100, 1)}%)")

    print(f"\n   조각 하나에 조문 몇 개?")
    for k in sorted(n_articles):
        label = "11개+" if k == 11 else f"{k}개"
        print(f"   {label:8s} {n_articles[k]:6d}")

    print(f"\n   chapter_no 있음 {chap} · section_no 있음 {sect} / 전체 {len(rows)}")
    print(f"   chapter_no 모양: {_top(chap_kind)}  ← 별표·서식도 이 칸에 온다")
    print(f"   부칙 헤더 아래 조각 {addendum} (그중 조 번호 있음 {addendum_with_article})"
          f"  ← 본칙 조 번호와 겹친다")
    print(f"   하이픈 조문 헤더(`제7-2조`) {hyphen_head}")
    print(f"   본문이 자기 헤더로 시작 {leaf_ok} / {leaf_total}  ← 인덱서가 첫 줄에 헤더를 붙인다")
    print(f"   본문에 다른 조문 머리글이 든 조각 {body_heads_chunks} (머리글 {body_heads}개)"
          f"  ← 그 조문들은 이름표가 없다")
    abbr = official_abbreviations(rows)
    print(f"   제목줄 공식 약칭 {len(abbr.table)}개 · 충돌 {len(abbr.conflicts)}"
          f"  예: {list(abbr.table.items())[:3]}")
    print(f"   doc_format: {_top(fmt)} · NO_SECTION/NO_CHAPTER 조각 {no_sect}  ← 법령 JSON 경로")

    print(f"\n{line}\nⓘ 권한 칸 — main_category 별 (확장이 이 값을 그대로 쓴다)")
    for cat, pc in sorted(perm_by_cat.items(), key=lambda kv: -kv[1]["조각"])[:8]:
        rest = " · ".join(f"{k} {v}" for k, v in sorted(pc.items()) if k != "조각")
        print(f"   {_short(cat, 14):14s} 조각 {pc['조각']:6d}  {rest}")

    print(f"\n{line}\nⓘ article_no 가 없는 조각 (앞 15개)  ← 별표·서문이 여기 있다")
    for head, cno, title in no_article[:15]:
        print(f"   header={_short(head, 46)!r}  chapter_no={cno!r}  title={_short(title, 16)!r}")

    print(f"\n{line}\nⓘ 별표·서식으로 보이는 조각 (앞 15개)")
    for head, raw, cno in appendix_like[:15]:
        print(f"   header={_short(head, 40)!r}  article_no={raw!r}  chapter_no={cno!r}")
    if not appendix_like:
        print("   (없음 — 별표가 다른 필드에 있거나 이 표본에 없다)")

    print(f"\n{line}\nⓘ header_path 모양 상위 15 (숫자는 N 으로 묶음)")
    for pat, cnt in header_pat.most_common(15):
        print(f"   {cnt:6d}  {pat}")


def _permission_counts(rows: List[Dict]) -> Dict[str, Counter]:
    """main_category 별 권한 칸 존재. 확장이 이 값을 그대로 쓴다 (Reviewer 2차 F9)."""
    out: Dict[str, Counter] = {}
    for row in rows:
        payload = dict(row)
        nested = payload.get("metadata")
        if isinstance(nested, Mapping):
            payload = {**nested, **{k: v for k, v in payload.items() if k != "metadata"}}
        pc = out.setdefault(str(payload.get("main_category") or "(없음)"), Counter())
        pc["조각"] += 1
        ak = payload.get("audience_keys")
        pc["audience_keys " + ("목록" if isinstance(ak, (list, tuple)) and ak else
                                "문자열" if isinstance(ak, str) and ak else "없음")] += 1
        pc["category_id " + ("있음" if payload.get("category_id") else "없음")] += 1
    return out


def ask_llm(prompt: str, client, model: str) -> str:
    """
    판정 한 번. **실패를 삼키지 않는다** — 빈 문자열을 돌려주면
    `parse_verdicts` 가 "응답이 비어 있다" 로 기록하고, 그 회차는 아무것도 안 떨어뜨린다.
    """
    try:
        resp = client.chat.completions.create(
            model=model, temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content or ""
    except Exception as e:
        print(f"{TAG} ⚠️  LLM 호출 실패: {type(e).__name__} {e}")
        return ""


def run_verify(edges, texts, index, limit: int):
    """
    엣지를 출발 조문끼리 묶어 LLM 에 **객관식**으로 물어본다.

    같은 문장에서 나온 후보들은 문맥을 공유하므로 조문 단위로 묶는다 —
    낱개로 물으면 `같은 법` 이 뭔지 판단할 근거가 사라진다.
    """
    try:
        from openai import OpenAI
    except ImportError:
        _die("openai 미설치 — 운영 venv 에서 실행할 것")

    base = os.getenv("OPENAI_BASE_URL")
    model = os.getenv("MODEL_NAME")
    if not base or not model:
        _die("OPENAI_BASE_URL / MODEL_NAME 미설정 — LLM 검증을 못 한다")
    client = OpenAI(base_url=base, api_key=os.getenv("OPENAI_API_KEY", "EMPTY"))

    by_src: Dict[str, List] = {}
    for e in edges:
        by_src.setdefault(e.src, []).append(e)

    groups = list(by_src.items())[:limit] if limit else list(by_src.items())
    total = sum(len(v) for _k, v in groups)
    print(f"{TAG} LLM 검증 — 조문 {len(groups)}곳 · 엣지 {total}개 · model={model}")

    verdicts = Counter()
    kept, dropped, review, parse_fail = [], [], [], 0
    for i, (src, group) in enumerate(groups, 1):
        items = items_from_edges(group, index)
        answer = ask_llm(build_prompt(texts.get(src, ""), items), client, model)
        res = parse_verdicts(answer, items)
        if not res.ok:
            parse_fail += 1
        for no, v in res.verdicts.items():
            verdicts[v] += 1
        out = apply_verdicts(group, items, res)
        kept += out.kept
        dropped += out.dropped
        review += out.review
        if i % 20 == 0:
            print(f"{TAG}   … {i}/{len(groups)}")
    return kept, dropped, review, verdicts, parse_fail, total


def _short(text: str, n: int = 58) -> str:
    one = " ".join((text or "").split())
    return one if len(one) <= n else one[:n] + "…"


def _top(counter: Counter, n: int = 6) -> str:
    return " · ".join(f"{k} {v}" for k, v in counter.most_common(n)) or "(없음)"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0, help="읽을 parent 수 (0=전량)")
    ap.add_argument("--doc", default="", help="source_file 부분일치 필터")
    ap.add_argument("--sample", type=int, default=15, help="채점용 표본 엣지 수")
    ap.add_argument("--seed", type=int, default=20260923)
    ap.add_argument("--verify", action="store_true",
                    help="LLM 객관식 검증까지 (OPENAI_BASE_URL·MODEL_NAME 필요)")
    ap.add_argument("--verify-limit", type=int, default=0,
                    help="검증할 출발 조문 수 상한 (0=전부)")
    ap.add_argument("--inspect", action="store_true",
                    help="payload 구조만 진단하고 끝낸다 (그래프 안 만듦)")
    ap.add_argument("--demo", nargs="*", default=None, metavar="조문",
                    help="챗봇에서 그래프가 하는 일을 보여준다. 값 없이 주면 예시 3개, "
                         "'여신규정 제5조' 처럼 주면 그 조문 (여러 개 = 검색이 여럿 찾은 경우)")
    ap.add_argument("--audience", nargs="*", default=None, metavar="키",
                    help="데모의 사용자 권한 키 (없으면 데이터에 있는 키 전부 = 모든 문서가 보이는 사람)")
    args = ap.parse_args()

    rows = fetch_parents(args.limit, args.doc)

    if args.inspect:
        inspect_payloads(rows)
        print(f"\n{'=' * 70}\n{TAG} 진단만 하고 끝. 읽기 전용.")
        return 0

    index = build_index(rows)
    known = index.doc_titles

    # ── 약칭표 — 문서마다 한 번. 정의(`이하 "법"`)는 제1조에 있고 인용은 다른 조각에 있다 ──
    doc_texts: Dict[str, List[str]] = {}
    for payload in rows:
        node = index.node(str(payload.get("parent_id") or ""))
        if node is not None and payload.get("text"):
            doc_texts.setdefault(node.doc_title, []).append(payload["text"])
    alias_tables = {doc: build_aliases(doc, ts) for doc, ts in doc_texts.items()}
    abbr = official_abbreviations(rows)          # 제목줄 `(약칭: 신용정보법)` — 문서 사이 줄임말
    headings = heading_index(rows)               # 문서별 진짜 제목 — 본문 속 제목을 추측 없이 가린다
    known_map = {re.sub(r"\s+", "", k): k for k in known}   # 조각마다 다시 만들지 않는다

    # ── 추출 + 해소 ────────────────────────────────────────────────────
    edges, unresolved, rejected = [], [], Counter()
    texts: Dict[str, str] = {}          # LLM 검증이 쓸 원문
    candidates = 0
    norm_errors = 0
    by_source, alias_miss = Counter(), Counter()
    missing_src: Dict[str, Counter] = {}         # 미보유 문서 → 문서명 출처 분포
    missing_from: Dict[str, Counter] = {}        # 미보유 문서 → 그걸 인용한 문서
    for payload in rows:
        text = payload.get("text") or ""
        if not text:
            continue
        src = str(payload.get("parent_id") or "")
        node = index.node(src)
        if node is None:
            continue
        doc_title = node.doc_title
        # 조각 id 는 유일하므로 덮어쓸 일이 없다.
        # (예전엔 조문 단위라 한 조문의 조각 여럿이 서로를 덮어썼다 — 2026-09-23)
        texts[src] = text
        try:
            got = extract_refs(text, self_doc_title=doc_title, known_doc_titles=known_map,
                               aliases=alias_tables[doc_title].table,
                               leaf_header=leaf_header(payload.get("header_path")),
                               abbreviations=abbr.table,
                               known_headings=headings.by_doc.get(doc_title, {}))
        except Exception as e:                      # 정규화 실패 등 — 삼키지 않는다
            norm_errors += 1
            if norm_errors <= 3:
                print(f"{TAG} ⚠️  추출 실패 {src}: {type(e).__name__} {e}")
            continue
        candidates += len(got.refs)
        by_source.update(r.title_source for r in got.refs)
        for r in got.rejected:
            rejected[r.reason] += 1
            if r.reason.startswith(REJECT_ALIAS):
                alias_miss[doc_title] += 1
        res = resolve(got.refs, index, src_node_id=src, self_doc_title=doc_title,
                      current_articles=node.article_labels, text=text)
        edges += res.edges
        unresolved += res.unresolved
        # 미보유 문서명이 **어디서** 왔나 — 약칭 풀이에서 왔으면 약칭표가 틀렸을 수 있다
        src_of = {(r.start, r.end): r.title_source for r in got.refs}
        for u in res.unresolved:
            if u.reason == REASON_NO_DOC and u.doc_title:
                missing_src.setdefault(u.doc_title, Counter())[
                    src_of.get((u.offset_start, u.offset_end), "?")] += 1
                missing_from.setdefault(u.doc_title, Counter())[doc_title] += 1

    if args.demo is not None:
        return run_demo(args, index, edges, texts, known_map, abbr.table)

    result = ResolveResult(edges, unresolved)
    report = res_audit(result)
    stats = index.stats.as_dict()

    # ── 리포트 ─────────────────────────────────────────────────────────
    line = "=" * 70
    print(f"\n{line}\n① 색인")
    print(f"   parent 행 {stats['rows']}  →  조각 노드 {len(index)}  ·  문서 {len(known)}개")
    print(f"   버림: 문서명없음 {stats['skipped_no_doc']} · "
          f"parent_id없음 {stats['skipped_no_parent']} · 중복조각 {stats['duplicate_parents']}")
    print(f"   이름표 없는 조각 {stats['nodes_without_label']}  ← 가리킬 수는 없지만 가리킬 수 있음")
    print(f"   조문 여럿인 조각 {stats['multi_article_nodes']}  (최대 {stats['max_articles_in_node']}개)")
    print(f"   별표·서식 조각 {stats['appendix_nodes']} · 부칙 조각 {stats['addendum_nodes']}"
          f"  (들고 온 조 번호 안 씀 {stats['scoped_articles_dropped']})")
    print(f"   헤더에서 조 번호 읽음 {stats['articles_from_header']}"
          f" · 하이픈 조문 {stats['hyphen_article_nodes']}")
    # 조 이름표 하나에 조각이 몇 개 붙나 — 부칙·편처럼 **번호가 다시 시작하는** 구조가 남았으면 여기서 보인다
    multi = Counter()
    worst = []
    for (doc_key, label), ids in index._by_label.items():
        if label.endswith("조") or "조의" in label:
            k = len(ids)
            multi["1" if k == 1 else "2" if k == 2 else "3~5" if k <= 5 else "6~12" if k <= 12 else "13+"] += 1
            if k >= 3:
                worst.append((k, index.display_title(doc_key), label))
    print(f"   조 이름표당 조각 수: " + " · ".join(f"{b}개 {multi[b]}" for b in ("1", "2", "3~5", "6~12", "13+")))
    for k, d, lab in sorted(worst, reverse=True)[:3]:
        print(f"     {k:3d}개  {_short(d, 26)} {lab}  ← 조문이 길어 쪼개졌거나 번호가 겹친다")
    if stats["unparsed_chapter_no"]:
        print(f"   ⚠️  못 읽은 chapter_no {stats['unparsed_chapter_no']}"
              f"  예: {stats['unparsed_chapter_examples']}")

    tables = list(alias_tables.values())
    print(f"\n{line}\n② 추출")
    print(f"   약칭표: 문서 {sum(1 for t in tables if t.table)}개"
          f"  (제목 근거 {sum(1 for t in tables if t.from_title)}"
          f" · 본문 정의 {sum(1 for t in tables if t.from_definition)})"
          f"  · 충돌 {sum(len(t.conflicts) for t in tables)}"
          f" · 못 읽은 본문 {sum(t.skipped_texts for t in tables)}")
    print(f"   공식 약칭(제목줄) {len(abbr.table)}개 · 충돌 {len(abbr.conflicts)}"
          + (f" {abbr.conflicts[:3]}" if abbr.conflicts else ""))
    clash = [(d, t) for d, t in alias_tables.items() if t.conflicts]
    for d, t in clash[:5]:
        for alias in t.conflicts[:2]:
            print(f"     약칭 충돌  {_short(d, 22)}  '{alias}' → "
                  + " | ".join(_short(x, 18) for x in t.conflict_titles.get(alias, [])[:3]))
    print(f"   후보 {candidates}  ·  거부 {sum(rejected.values())}  ·  추출 실패 {norm_errors}")
    print(f"   문서명 출처: {_top(by_source, 7)}")
    print(f"   거부 사유:")
    for reason, cnt in rejected.most_common(10):
        print(f"     {cnt:6d}  {_short(reason, 52)}")
    if alias_miss:
        print(f"   약칭 못 푼 문서 top 5  ← 정의가 없는 문서다. 제1조 목적 조항을 봐야 한다")
        for name, cnt in alias_miss.most_common(5):
            print(f"     {cnt:4d}  {name}")

    print(f"\n{line}\n③ 해소")
    print(f"   연결 {report['edges']}  ·  미해소 {report['unresolved']}")
    print(f"   해소율 {report['resolve_rate']}   실질 {report['real_rate']}  ← 구조적 비대상 제외")
    print(f"   여러 번 인용된 연결 {report['repeated']}")
    print(f"   관계: {_top(Counter(report['by_subtype']))}")
    print(f"   미해소 사유: {_top(Counter(report['by_reason']))}")
    print(f"   범위 전개 산물 {report['from_range']}  ← 미해소 분모를 부풀린다")

    missing = Counter({name: sum(c.values()) for name, c in missing_src.items()})
    print(f"\n   보유 안 한 문서 top 10  ← 색인 누락인지 외부 법령인지 봐야 한다")
    print(f"   (출처 = 문서명을 어떻게 얻었나 · 인용 = 가장 많이 인용한 문서)")
    for name, cnt in missing.most_common(10):
        how = _top(missing_src[name], 2)
        who, who_n = missing_from[name].most_common(1)[0]
        print(f"     {cnt:4d}  {_short(name, 26)}  출처 {how}  인용 {_short(who, 16)}({who_n})")

    print(f"\n{line}\n④ 그래프")
    deg = Counter()
    for e in edges:
        deg[e.src] += 1
        deg[e.dst] += 1
    linked = len(deg)
    print(f"   연결된 노드 {linked} / {len(index)}  ({round(linked / max(len(index), 1) * 100, 1)}%)")
    print(f"   고립 노드 {len(index) - linked}  ← 참조가 없는 조문")
    if deg:
        print(f"   차수 상위 5 — 정체를 본다 (목차·정의 조항이면 허브가 된다)")
        for nid, d in deg.most_common(5):
            n = index.node(nid)
            out_e = [e for e in edges if e.src == nid]
            raws = Counter(_short(e.raw_text, 14) for e in out_e).most_common(4)
            print(f"   ▸ {nid.split('::')[-1]} {_short(n.doc_title if n else nid, 26)}"
                  f"  이름표 {'/'.join(n.labels[:3]) if n and n.labels else '(없음)'}"
                  f"  나감 {len(out_e)} · 들어옴 {d - len(out_e)}")
            print(f"      본문 앞 {_short(texts.get(nid, ''), 60)!r}")
            if raws:
                print(f"      많이 나온 근거 " + " · ".join(f"{r!r}×{c}" for r, c in raws))

    print(f"\n{line}\n⑤ 채점용 표본 {args.sample}건  ← 이걸 보고 정밀도를 매긴다")
    random.Random(args.seed).shuffle(edges)
    for i, e in enumerate(edges[:args.sample], 1):
        src_node, dst_node = index.node(e.src), index.node(e.dst)
        name = lambda n, i_: (f"{n.doc_title} {'/'.join(n.labels[:3]) or '(이름표없음)'}"
                              if n else i_)
        # 도착은 **이은 이름표**로 — 이름표 여럿인 조각은 앞 3개만 보면 맞게 이었는지 못 본다
        more = f" (조각 이름표 {len(dst_node.labels)}개)" if dst_node and len(dst_node.labels) > 1 else ""
        dst_name = f"{dst_node.doc_title} {e.target}{more}" if dst_node and e.target \
            else name(dst_node, e.dst)
        print(f"  {i:2d}. {name(src_node, e.src)}  ──{e.subtype or '?'}──▶  {dst_name}")
        body = texts.get(e.src, "")
        lo = max(0, e.src_offset_start - 35)
        ctx = body[lo:e.src_offset_end + 35]
        print(f"      근거 {_short(e.raw_text, 30)!r}   인용 {e.mentions}회")
        print(f"      문맥 …{_short(ctx, 76)}…")
    dropped: List = []
    asked = yes = no = unsure = 0
    if args.verify:
        # ── LLM 검증 ───────────────────────────────────────────────────
        print(f"\n{line}\n⑥ LLM 검증")
        kept, dropped, review, verdicts, parse_fail, asked = run_verify(
            edges, texts, index, args.verify_limit)
        yes = verdicts.get(VERDICT_YES, 0)
        no = verdicts.get(VERDICT_NO, 0)
        unsure = verdicts.get(VERDICT_UNSURE, 0)
        print(f"\n   물어본 엣지 {asked}  ·  응답 파싱 실패 {parse_fail}곳")
        print(f"   맞음 {yes} · 아님 {no} · 모르겠음 {unsure}")
        if asked:
            print(f"   → LLM 기준 정밀도 {round(yes / asked, 3)}")
        print(f"   남김 {len(kept)} · 버림 {len(dropped)} · 검수 대기 {len(review)}")

    # 엇갈린 건은 문서별로 묶는다 — 앞 12건만 찍으면 한 문서(목차 하나)가 화면을 다 먹는다 (2026-09-28)
    by_doc, first = Counter(), {}
    for e, why in dropped:
        n = index.node(e.src)
        d = n.doc_title if n else e.src
        by_doc[d] += 1
        first.setdefault(d, (e, why))
    if dropped:
        print(f"\n   정규식↔LLM 엇갈린 건 {len(dropped)} — 출발 문서별 상위 10 (문서마다 예시 1)")
        for d, cnt in by_doc.most_common(10):
            e, why = first[d]
            body = texts.get(e.src, "")
            ctx = body[max(0, e.src_offset_start - 25):e.src_offset_end + 25]
            print(f"   {cnt:3d}  {_short(d, 28)}  근거 {_short(e.raw_text, 18)!r} ─▶ {_dst_label(index, e)}")
            print(f"        LLM  {_short(why, 56)}")
            print(f"        문맥 …{_short(ctx, 56)}…")

    # ── 요약 — 사용자가 이 화면 한 장만 찍으면 되게 (2026-09-28 사용자: 반복이 진이 빠진다) ──
    print(f"\n{line}\n★ 요약 — 이 화면 한 장만 찍으면 됩니다")
    print(f"   조각 {len(index)} · 문서 {len(known)} · 선 {report['edges']} · 선 있는 조각 {linked}"
          f" ({round(linked / max(len(index), 1) * 100, 1)}%)")
    print(f"   실질 해소율 {report['real_rate']} · 추출 실패 {norm_errors}")
    if asked:
        prec = round(yes / asked, 3)
        mark = "✅" if prec >= STOP_PRECISION else "⚠️"
        print(f"   LLM 확인 {asked}개 · 틀림 {no} · 모르겠음 {unsure} → 정밀도 {prec}"
              f"   [끝내는 기준 {STOP_PRECISION}] {mark}")
        for d, cnt in by_doc.most_common(3):
            e, _why = first[d]
            body = texts.get(e.src, "")
            ctx = body[max(0, e.src_offset_start - 20):e.src_offset_end + 20]
            print(f"     틀림 {cnt:3d}  {_short(d, 22)}  {_short(e.raw_text, 14)!r} → {_dst_label(index, e)}"
                  f"  …{_short(ctx, 34)}…")
    else:
        print(f"   LLM 확인 안 함 — `--verify` 로 돌려야 끝낼지 판단할 수 있다")
    miss = " · ".join(f"{_short(nm, 14)} {c}({missing_src[nm].most_common(1)[0][0]})"
                      for nm, c in missing.most_common(3)) or "(없음)"
    print(f"   보유 안 한 문서 top 3: {miss}")
    print(f"   약칭 못 푼 문서 top 3: {_top(alias_miss, 3)}")
    print(f"   제목 목록: 문서 {len(headings.by_doc)} · 제목 {headings.headings} · 못 읽음 {headings.skipped}"
          f" · 제목으로 걸러냄 {rejected.get(REJECT_KNOWN_HEADING, 0)}")
    print(f"   권한 칸 (main_category · 조각 · audience_keys 있음):")
    for cat, pc in sorted(_permission_counts(rows).items(), key=lambda kv: -kv[1]["조각"])[:4]:
        have = pc["audience_keys 목록"] + pc["audience_keys 문자열"]
        print(f"     {_short(cat, 12):12s} {pc['조각']:6d} · {have:6d}"
              + ("   ← 0 이면 확장에서 전부 차단된다" if not have else ""))
    print(f"\n{TAG} 읽기 전용으로 끝. Qdrant 에 아무것도 쓰지 않았다.")
    return 0


def _node_name(n) -> str:
    """사람이 읽는 조각 이름 — `여신규정 005조 (한도)`."""
    if n is None:
        return "(모르는 조각)"
    label = (n.article_labels or n.labels or ("(이름표 없음)",))[0]
    title = n.title if n.title and not n.title.startswith("[") else ""
    return f"{n.doc_title} {label}" + (f" ({_short(title, 14)})" if title else "")


def _pick_demo_seeds(args, index, edges, known_map, abbreviations, visible_ids=None) -> List:
    """데모 시작 조각 — `(설명, [조각 id…])` 목록. 못 찾은 건 이유를 찍고 건너뛴다."""
    if args.demo:
        picked = []
        for text in args.demo:
            got = extract_refs(text, known_doc_titles=known_map, abbreviations=abbreviations,
                               skip_headings=False)
            ref = next((r for r in got.refs if r.doc_title and r.target), None)
            nodes = index.find(ref.doc_title, ref.target) if ref else []
            if not nodes:                                   # 조각 id 일부로도 찾는다 (예: p123)
                nodes = [n for n in index.all_nodes() if n.node_id.endswith(text) or text in n.node_id][:3]
            if nodes:
                picked.append((text, [n.node_id for n in nodes]))
            else:
                print(f"   ⚠️  '{text}' 를 못 찾음 — '문서명 제N조' 로 적거나 조각 id 일부를 적을 것")
        return picked
    # 다른 조문을 **인용한** 조각 중에서 — 그래프가 뭘 더 가져오는지가 제일 잘 보인다
    linked = sorted({e.src for e in edges if visible_ids is None or e.src in visible_ids})
    rnd = random.Random(args.seed)
    return [(_node_name(index.node(nid)), [nid]) for nid in rnd.sample(linked, min(3, len(linked)))]


def run_demo(args, index, edges, texts, known_map, abbreviations) -> int:
    """
    **챗봇에서 그래프가 하는 일**을 그대로 보여준다.

    검색이 어떤 조각을 찾았다고 치고 → 그 조각이 인용한 곳·그 조각을 인용한 곳 →
    운영 확산 코드(`graph.expand.GraphView.expand`)가 **권한으로 거른 뒤** 같이 가져올 조각.
    """
    try:
        from graph.expand import ALLOW_ALL_CATEGORIES, build_view
    except ImportError as e:
        _die(f"운영 확산 코드(graph/)를 못 찾음: {e} — 번들의 graph/ 폴더가 옆에 있어야 한다")

    nodes = index.all_nodes()
    view = build_view(
        [{"src": e.src, "dst": e.dst, "rel": e.rel, "subtype": e.subtype, "confidence": e.confidence}
         for e in edges],
        [{"node_id": n.node_id, "doc_title": n.doc_title, "target": "/".join(n.labels), "title": n.title,
          "parent_id": n.parent_id, "category_id": n.category_id, "main_category": n.main_category,
          "audience_keys": list(n.audience_keys)} for n in nodes])
    audience = args.audience or sorted({k for n in nodes for k in n.audience_keys}) or ["GLOBAL"]
    out_by, in_by = {}, {}
    for e in edges:
        out_by.setdefault(e.src, []).append(e)
        in_by.setdefault(e.dst, []).append(e)

    line = "=" * 70
    who = "모든 문서가 보이는 사람" if not args.audience else f"권한 키 {', '.join(audience)}"
    print(f"\n{line}\n★ 데모 — 챗봇에서 그래프가 하는 일  (사용자: {who})")
    print("   검색이 아래 조각을 찾았다고 치고, 그래프가 연결을 따라 **더 가져오는** 조각을 보여준다.")
    print("   가져오는 순서는 운영 확산 코드 그대로다 — 볼 권한이 없는 조각은 애초에 확산에서 빠진다.")

    mask = view.visible_mask(audience, ALLOW_ALL_CATEGORIES)
    visible_ids = {nid for nid, ok in zip(view.graph.node_ids, mask) if ok}
    seeds = _pick_demo_seeds(args, index, edges, known_map, abbreviations, visible_ids)
    for i, (label, seed_ids) in enumerate(seeds, 1):
        seed = index.node(seed_ids[0])
        print(f"\n[예시 {i}] 검색이 찾은 조각: {_node_name(seed)}"
              + (f"  (같은 조문 조각 {len(seed_ids)}개)" if len(seed_ids) > 1 else ""))
        body = texts.get(seed_ids[0], "").split("\n", 1)
        print(f"   본문: {_short(body[1] if len(body) > 1 else body[0], 70)!r}")
        if not view.is_visible(view.nodes.get(seed_ids[0]), audience, ALLOW_ALL_CATEGORIES):
            print("   ⛔ 이 사용자는 이 조각을 볼 권한이 없다 — 검색에서도 안 나오고, 확산도 여기서 시작하지 않는다")
            continue
        # 같은 조각 쌍이 관계어만 달라 두 줄일 수 있다 — 보여줄 때는 한 번만
        outs = list({(e.dst, e.raw_text): e for sid in seed_ids for e in out_by.get(sid, [])}.values())
        ins = list({(e.src, e.raw_text): e for sid in seed_ids for e in in_by.get(sid, [])}.values())
        print(f"   이 조각이 인용한 곳 ({len(outs)}):")
        for e in outs[:4]:
            print(f"     → {_node_name(index.node(e.dst))}   근거 {_short(e.raw_text, 20)!r}")
        print(f"   이 조각을 인용한 곳 ({len(ins)}):")
        for e in ins[:4]:
            print(f"     ← {_node_name(index.node(e.src))}   근거 {_short(e.raw_text, 20)!r}")
        scores = view.graph.personalized_pagerank(seed_ids, visible=mask)
        picked = view.expand(seed_ids, audience_keys=audience, allowed_category_ids=ALLOW_ALL_CATEGORIES,
                             top_k=5)
        print(f"   ▶ 챗봇이 같이 가져올 조각 (점수 순, 최대 5):")
        if not picked:
            print("     (없음 — 이어진 조각이 없거나, 이 사용자가 볼 수 없다)")
        for k, pid in enumerate(picked, 1):
            print(f"     {k}. {_node_name(index.node(pid))}   점수 {scores.get(pid, 0.0):.3f}")
    if not seeds:
        print("\n   (보여줄 조각이 없다 — 이 사용자가 볼 수 있으면서 연결이 있는 조각이 없다)")

    print(f"\n{TAG} 읽기 전용으로 끝. Qdrant 에 아무것도 쓰지 않았다.")
    return 0


def _dst_label(index, e) -> str:
    """연결 도착을 **이은 이름표**로 — 조각 이름표 전부나 조각 id 는 판단에 안 쓰인다."""
    if e.target:
        return e.target
    dst = index.node(e.dst)
    return dst.labels[0] if dst and dst.labels else e.dst.split("::")[-1]


if __name__ == "__main__":
    raise SystemExit(main())
